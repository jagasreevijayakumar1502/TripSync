"""
Jurisdiction Risk Engine
Flags high-risk countries, offshore routing, and geography-based risk tiers.
"""
import pandas as pd


# FATF-inspired risk tiers
COUNTRY_RISK_TIERS = {
    # Tier 1 - Very High Risk (FATF Blacklist)
    "Iran": 25, "North Korea": 25, "Myanmar": 22,

    # Tier 2 - High Risk (FATF Greylist)
    "Syria": 20, "Afghanistan": 20, "Yemen": 18, "Libya": 18, "Somalia": 18,

    # Tier 3 - Medium-High Risk
    "Russia": 12, "Pakistan": 12, "Nigeria": 10, "Lebanon": 10,

    # Tier 4 - Offshore / Tax Haven
    "Panama": 15, "Cayman Islands": 15, "Bahamas": 12,

    # Tier 5 - Medium Risk
    "China": 6, "UAE": 5,

    # Tier 6 - Low Risk
    "India": 0, "USA": 0, "UK": 0, "Germany": 0, "Japan": 0,
    "Canada": 0, "Australia": 0, "Singapore": 0, "France": 0,
}


class JurisdictionEngine:
    def __init__(self):
        self.country_risk = COUNTRY_RISK_TIERS
        self.high_risk_countries = {k for k, v in COUNTRY_RISK_TIERS.items() if v >= 15}
        self.offshore_countries = {"Panama", "Cayman Islands", "Bahamas"}

    def evaluate(self, account_id, transactions_df, accounts_df):
        """
        Evaluate jurisdiction risk for a given account.
        Returns risk score [0-20] and details.
        """
        risk_score = 0
        details = []
        flags = []

        # Account's home country risk
        acct_info = accounts_df[accounts_df["Account_ID"] == account_id]
        if not acct_info.empty:
            home_country = acct_info.iloc[0].get("Country", "")
            home_risk = self.country_risk.get(home_country, 5)

            if home_risk >= 15:
                penalty = min(10, home_risk // 2)
                risk_score += penalty
                flags.append(f"HIGH-RISK JURISDICTION: Account domiciled in {home_country} (risk: {home_risk})")
                details.append({
                    "rule": "Home country risk",
                    "country": home_country,
                    "country_risk_score": home_risk,
                    "penalty": penalty
                })

        # Transaction country analysis
        acct_txns = transactions_df[
            (transactions_df["Sender_Account_ID"] == account_id) |
            (transactions_df["Receiver_Account_ID"] == account_id)
        ]

        if not acct_txns.empty:
            # Rule 2: Transactions involving high-risk countries
            hr_txns = acct_txns[acct_txns["Country"].isin(self.high_risk_countries)]
            if len(hr_txns) > 0:
                penalty = min(8, len(hr_txns) * 2)
                risk_score += penalty
                countries = hr_txns["Country"].unique().tolist()
                flags.append(f"HIGH-RISK ROUTING: {len(hr_txns)} txns through {', '.join(countries)}")
                details.append({
                    "rule": "High-risk country routing",
                    "countries": countries,
                    "txn_count": len(hr_txns),
                    "penalty": penalty
                })

            # Rule 3: Offshore routing
            offshore_txns = acct_txns[acct_txns["Country"].isin(self.offshore_countries)]
            if len(offshore_txns) > 0:
                penalty = min(5, len(offshore_txns) * 2)
                risk_score += penalty
                flags.append(f"OFFSHORE ROUTING: {len(offshore_txns)} txns through offshore jurisdictions")
                details.append({
                    "rule": "Offshore routing",
                    "txn_count": len(offshore_txns),
                    "penalty": penalty
                })

            # Rule 4: Multi-jurisdiction spread (many different countries)
            unique_countries = acct_txns["Country"].nunique()
            if unique_countries >= 5:
                penalty = min(5, unique_countries - 3)
                risk_score += penalty
                flags.append(f"MULTI-JURISDICTION: Transactions across {unique_countries} countries")
                details.append({
                    "rule": "Multi-jurisdiction spread",
                    "country_count": unique_countries,
                    "penalty": penalty
                })

        return {
            "score": min(risk_score, 20),
            "details": details,
            "flags": flags
        }
