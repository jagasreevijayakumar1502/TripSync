"""
RegShield — Synthetic Dataset Generator
Generates 4 Excel files with embedded AML risk scenarios.
"""
import pandas as pd
import numpy as np
import random
import os
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)))

# --- Constants ---
HIGH_RISK_COUNTRIES = ["Iran", "North Korea", "Myanmar", "Syria", "Afghanistan", "Yemen", "Libya", "Somalia"]
MEDIUM_RISK_COUNTRIES = ["Russia", "China", "Pakistan", "Nigeria", "Lebanon", "Panama", "Cayman Islands", "Bahamas"]
LOW_RISK_COUNTRIES = ["India", "USA", "UK", "Germany", "Japan", "Canada", "Australia", "Singapore", "France", "UAE"]
ALL_COUNTRIES = LOW_RISK_COUNTRIES + MEDIUM_RISK_COUNTRIES + HIGH_RISK_COUNTRIES

CHANNELS = ["Online Banking", "Mobile App", "ATM", "Branch", "Wire Transfer", "SWIFT"]
CURRENCIES = ["INR", "USD", "EUR", "GBP", "AED", "SGD"]
TXN_TYPES = ["Deposit", "Withdrawal", "Transfer", "Wire", "Cash Deposit", "Cash Withdrawal"]
ACCOUNT_TYPES = ["Savings", "Current", "Business", "NRI", "Joint"]
KYC_STATUSES = ["Complete", "Partial", "Pending", "Expired"]
PEP_CATEGORIES = ["Head of State", "Senior Politician", "Military Officer", "Judiciary", "Diplomat", "State Enterprise Executive"]
RISK_CATEGORIES = ["Low", "Medium", "High"]

FIRST_NAMES = ["Arjun", "Priya", "Rahul", "Sneha", "Vikram", "Ananya", "Karan", "Deepa", "Suresh", "Meera",
               "Omar", "Fatima", "Nikolai", "Chen", "Yuki", "James", "Elena", "Mohammed", "Aisha", "Boris",
               "Carlos", "Maria", "Hans", "Sofia", "Ahmed", "Li", "Kim", "Ravi", "Anjali", "David"]
LAST_NAMES = ["Kumar", "Singh", "Patel", "Shah", "Gupta", "Ali", "Khan", "Chen", "Wang", "Tanaka",
              "Smith", "Johnson", "Petrov", "Garcia", "Mueller", "Sato", "Lee", "Park", "Das", "Sharma",
              "Ivanov", "Rodriguez", "Fischer", "Andersson", "Nakamura", "Ibrahim", "Hassan", "Rao", "Nair", "Reddy"]
POLITICAL_POSITIONS = ["Prime Minister", "Finance Minister", "Defence Minister", "Governor", "Senator",
                       "Parliament Member", "Army General", "Supreme Court Judge", "Ambassador", "Central Bank Governor",
                       "Intelligence Chief", "State Governor", "Party President", "Foreign Minister", "Home Minister"]


def generate_ip(country):
    """Generate pseudo-realistic IP based on country."""
    country_ip_prefixes = {
        "India": "103.", "USA": "44.", "UK": "51.", "Germany": "46.", "Japan": "133.",
        "Canada": "24.", "Australia": "1.", "Singapore": "52.", "France": "78.", "UAE": "94.",
        "Russia": "95.", "China": "36.", "Pakistan": "39.", "Nigeria": "105.", "Lebanon": "78.",
        "Panama": "200.", "Cayman Islands": "64.", "Bahamas": "24.",
        "Iran": "5.", "North Korea": "175.", "Myanmar": "43.", "Syria": "5.",
        "Afghanistan": "45.", "Yemen": "5.", "Libya": "41.", "Somalia": "41."
    }
    prefix = country_ip_prefixes.get(country, "192.")
    return f"{prefix}{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"


def generate_accounts(n=200):
    """Generate account master with embedded risk scenarios."""
    accounts = []
    base_date = datetime(2023, 1, 1)

    for i in range(n):
        acct_id = f"ACC{str(i+1).zfill(5)}"
        cust_id = f"CUST{str(i+1).zfill(5)}"

        # --- Embedded scenarios ---
        if i < 10:  # Structuring accounts
            country = random.choice(LOW_RISK_COUNTRIES)
            kyc = "Complete"
            declared_income = random.randint(200000, 500000)
            risk_cat = "Low"
            is_pep = False
            avg_monthly = random.randint(30000, 80000)
            acct_status = "Active"
            creation_date = base_date + timedelta(days=random.randint(0, 365))
        elif i < 20:  # Circular transfer network
            country = random.choice(LOW_RISK_COUNTRIES + MEDIUM_RISK_COUNTRIES[:3])
            kyc = random.choice(["Complete", "Partial"])
            declared_income = random.randint(300000, 800000)
            risk_cat = "Medium"
            is_pep = False
            avg_monthly = random.randint(50000, 200000)
            acct_status = "Active"
            creation_date = base_date + timedelta(days=random.randint(0, 200))
        elif i < 25:  # Dormant accounts (will be reactivated)
            country = random.choice(LOW_RISK_COUNTRIES)
            kyc = random.choice(["Expired", "Partial"])
            declared_income = random.randint(100000, 300000)
            risk_cat = "Low"
            is_pep = False
            avg_monthly = random.randint(0, 5000)
            acct_status = "Dormant"
            creation_date = base_date - timedelta(days=random.randint(365, 730))
        elif i < 35:  # PEP-linked accounts
            country = random.choice(ALL_COUNTRIES)
            kyc = "Complete"
            declared_income = random.randint(1000000, 5000000)
            risk_cat = "High"
            is_pep = True
            avg_monthly = random.randint(200000, 1000000)
            acct_status = "Active"
            creation_date = base_date + timedelta(days=random.randint(0, 300))
        elif i < 45:  # High-risk country accounts
            country = random.choice(HIGH_RISK_COUNTRIES)
            kyc = random.choice(["Partial", "Pending", "Complete"])
            declared_income = random.randint(100000, 2000000)
            risk_cat = "High"
            is_pep = random.random() < 0.3
            avg_monthly = random.randint(100000, 500000)
            acct_status = "Active"
            creation_date = base_date + timedelta(days=random.randint(0, 365))
        elif i < 55:  # KYC-incomplete shell-like accounts
            country = random.choice(MEDIUM_RISK_COUNTRIES + HIGH_RISK_COUNTRIES[:3])
            kyc = random.choice(["Pending", "Partial"])
            declared_income = random.randint(50000, 150000)
            risk_cat = "High"
            is_pep = False
            avg_monthly = random.randint(200000, 800000)  # Income mismatch!
            acct_status = "Active"
            creation_date = base_date + timedelta(days=random.randint(300, 365))
        else:  # Normal accounts
            country = random.choice(LOW_RISK_COUNTRIES * 3 + MEDIUM_RISK_COUNTRIES)
            kyc = random.choice(["Complete"] * 8 + ["Partial", "Pending"])
            declared_income = random.randint(200000, 3000000)
            risk_cat = random.choice(["Low"] * 6 + ["Medium"] * 3 + ["High"])
            is_pep = random.random() < 0.05
            avg_monthly = random.randint(10000, int(declared_income * 0.3))
            acct_status = random.choice(["Active"] * 9 + ["Dormant"])
            creation_date = base_date + timedelta(days=random.randint(0, 700))

        pep_category = random.choice(PEP_CATEGORIES) if is_pep else ""
        acct_type = random.choice(ACCOUNT_TYPES)

        accounts.append({
            "Account_ID": acct_id,
            "Customer_ID": cust_id,
            "KYC_Status": kyc,
            "Account_Type": acct_type,
            "Declared_Income": declared_income,
            "Risk_Category": risk_cat,
            "Account_Creation_Date": creation_date.strftime("%Y-%m-%d"),
            "Country": country,
            "Is_PEP": is_pep,
            "PEP_Category": pep_category,
            "Avg_Monthly_Transaction_Value": avg_monthly,
            "Account_Status": acct_status
        })

    return pd.DataFrame(accounts)


def generate_transactions(accounts_df, n=2500):
    """Generate transaction log with embedded risk patterns."""
    transactions = []
    acct_ids = accounts_df["Account_ID"].tolist()
    acct_countries = dict(zip(accounts_df["Account_ID"], accounts_df["Country"]))
    base_time = datetime(2024, 11, 1, 8, 0, 0)
    txn_counter = 1

    # Device ID simulation - some accounts share devices (suspicious pattern)
    device_pool = [f"DEV{random.randint(1000, 9999)}" for _ in range(50)]  # 50 unique devices
    acct_devices = {}
    for acct in acct_ids:
        # 30% chance of sharing device with another account (suspicious)
        if random.random() < 0.3 and acct_devices:
            acct_devices[acct] = random.choice(list(acct_devices.values()))
        else:
            acct_devices[acct] = random.choice(device_pool)

    # --- Scenario 1: Structuring (accounts 0-9) ---
    structuring_accounts = acct_ids[:10]
    for acct in structuring_accounts:
        # Multiple small deposits just below 50000 threshold within 24 hours
        t = base_time + timedelta(days=random.randint(0, 5))
        num_txns = random.randint(5, 12)
        for j in range(num_txns):
            amt = random.randint(40000, 49500)  # Just below 50k
            receiver = random.choice([a for a in acct_ids[55:] if a != acct])
            transactions.append({
                "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                "Sender_Account_ID": acct,
                "Receiver_Account_ID": receiver,
                "Timestamp": (t + timedelta(minutes=random.randint(10, 300) * j)).strftime("%Y-%m-%d %H:%M:%S"),
                "Amount": amt,
                "Transaction_Type": random.choice(["Cash Deposit", "Deposit", "Transfer"]),
                "Country": acct_countries[acct],
                "Channel": random.choice(["ATM", "Branch", "Mobile App"]),
                "Currency": "INR",
                "IP_Address": generate_ip(acct_countries[acct]),
                "Device_ID": acct_devices[acct]  # Add device_id
            })
            txn_counter += 1

    # --- Scenario 2: Circular Transfers (accounts 10-19) ---
    circular_chains = [
        [acct_ids[10], acct_ids[11], acct_ids[12], acct_ids[10]],  # A->B->C->A
        [acct_ids[13], acct_ids[14], acct_ids[15], acct_ids[16], acct_ids[13]],  # A->B->C->D->A
        [acct_ids[17], acct_ids[18], acct_ids[19], acct_ids[17]],  # Another cycle
    ]
    for chain in circular_chains:
        t = base_time + timedelta(days=random.randint(1, 10))
        base_amt = random.randint(100000, 500000)
        for k in range(len(chain) - 1):
            amt = base_amt + random.randint(-5000, 5000)  # Slight variation
            transactions.append({
                "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                "Sender_Account_ID": chain[k],
                "Receiver_Account_ID": chain[k + 1],
                "Timestamp": (t + timedelta(hours=random.randint(1, 12) * (k + 1))).strftime("%Y-%m-%d %H:%M:%S"),
                "Amount": amt,
                "Transaction_Type": "Wire",
                "Country": acct_countries.get(chain[k], "India"),
                "Channel": random.choice(["SWIFT", "Wire Transfer", "Online Banking"]),
                "Currency": random.choice(["INR", "USD"]),
                "IP_Address": generate_ip(acct_countries.get(chain[k], "India")),
                "Device_ID": acct_devices[chain[k]]  # Add device_id
            })
            txn_counter += 1
        # Repeat the cycle a few times
        for rep in range(2):
            t2 = t + timedelta(days=random.randint(3, 7) * (rep + 1))
            for k in range(len(chain) - 1):
                amt = base_amt + random.randint(-8000, 8000)
                transactions.append({
                    "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                    "Sender_Account_ID": chain[k],
                    "Receiver_Account_ID": chain[k + 1],
                    "Timestamp": (t2 + timedelta(hours=random.randint(1, 8) * (k + 1))).strftime("%Y-%m-%d %H:%M:%S"),
                    "Amount": amt,
                    "Transaction_Type": "Transfer",
                    "Country": acct_countries.get(chain[k], "India"),
                    "Channel": random.choice(["Online Banking", "Wire Transfer"]),
                    "Currency": random.choice(["INR", "USD"]),
                    "IP_Address": generate_ip(acct_countries.get(chain[k], "India")),
                    "Device_ID": acct_devices[chain[k]]  # Add device_id
                })
                txn_counter += 1

    # --- Scenario 3: Dormant Account Reactivation (accounts 20-24) ---
    dormant_accounts = acct_ids[20:25]
    for acct in dormant_accounts:
        t = base_time + timedelta(days=random.randint(15, 25))
        # Sudden burst of high-value transactions
        for j in range(random.randint(8, 15)):
            amt = random.randint(100000, 800000)
            receiver = random.choice([a for a in acct_ids[55:100] if a != acct])
            transactions.append({
                "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                "Sender_Account_ID": acct,
                "Receiver_Account_ID": receiver,
                "Timestamp": (t + timedelta(minutes=random.randint(5, 120) * j)).strftime("%Y-%m-%d %H:%M:%S"),
                "Amount": amt,
                "Transaction_Type": random.choice(["Transfer", "Wire", "Withdrawal"]),
                "Country": acct_countries[acct],
                "Channel": random.choice(CHANNELS),
                "Currency": "INR",
                "IP_Address": generate_ip(acct_countries[acct]),
                "Device_ID": acct_devices[acct]  # Add device_id
            })
            txn_counter += 1

    # --- Scenario 4: PEP High-Value Transactions (accounts 25-34) ---
    pep_accounts = acct_ids[25:35]
    for acct in pep_accounts:
        t = base_time + timedelta(days=random.randint(0, 20))
        for j in range(random.randint(3, 8)):
            amt = random.randint(500000, 5000000)
            receiver = random.choice([a for a in acct_ids if a != acct])
            transactions.append({
                "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                "Sender_Account_ID": acct,
                "Receiver_Account_ID": receiver,
                "Timestamp": (t + timedelta(days=random.randint(0, 5), hours=random.randint(0, 23))).strftime("%Y-%m-%d %H:%M:%S"),
                "Amount": amt,
                "Transaction_Type": random.choice(["Wire", "Transfer", "SWIFT"]),
                "Country": acct_countries[acct],
                "Channel": random.choice(["SWIFT", "Wire Transfer", "Online Banking"]),
                "Currency": random.choice(CURRENCIES),
                "IP_Address": generate_ip(acct_countries[acct]),
                "Device_ID": acct_devices[acct]  # Add device_id
            })
            txn_counter += 1

    # --- Scenario 5: High-Risk Country Routing (accounts 35-44) ---
    hr_accounts = acct_ids[35:45]
    for acct in hr_accounts:
        t = base_time + timedelta(days=random.randint(0, 15))
        for j in range(random.randint(4, 10)):
            amt = random.randint(200000, 2000000)
            # Route through offshore
            offshore_receiver = random.choice([a for a in acct_ids[35:55] if a != acct])
            transactions.append({
                "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                "Sender_Account_ID": acct,
                "Receiver_Account_ID": offshore_receiver,
                "Timestamp": (t + timedelta(hours=random.randint(1, 48) * j)).strftime("%Y-%m-%d %H:%M:%S"),
                "Amount": amt,
                "Transaction_Type": random.choice(["Wire", "SWIFT"]),
                "Country": acct_countries[acct],
                "Channel": random.choice(["SWIFT", "Wire Transfer"]),
                "Currency": random.choice(["USD", "EUR", "GBP"]),
                "IP_Address": generate_ip(acct_countries[acct]),
                "Device_ID": acct_devices[acct]  # Add device_id
            })
            txn_counter += 1

    # --- Scenario 6: Fan-in / Mule Network (many accounts to one) ---
    mule_target = acct_ids[50]
    for src in acct_ids[45:55]:
        if src == mule_target:
            continue
        t = base_time + timedelta(days=random.randint(2, 8))
        for j in range(random.randint(2, 5)):
            amt = random.randint(20000, 90000)
            transactions.append({
                "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
                "Sender_Account_ID": src,
                "Receiver_Account_ID": mule_target,
                "Timestamp": (t + timedelta(hours=random.randint(1, 24) * j)).strftime("%Y-%m-%d %H:%M:%S"),
                "Amount": amt,
                "Transaction_Type": "Transfer",
                "Country": acct_countries.get(src, "India"),
                "Channel": random.choice(CHANNELS),
                "Currency": "INR",
                "IP_Address": generate_ip(acct_countries.get(src, "India")),
                "Device_ID": acct_devices[src]  # Add device_id
            })
            txn_counter += 1

    # --- Normal Transactions (fill up to n) ---
    normal_accounts = acct_ids[55:]
    while txn_counter <= n:
        sender = random.choice(normal_accounts)
        receiver = random.choice([a for a in acct_ids if a != sender])
        t = base_time + timedelta(days=random.randint(0, 30), hours=random.randint(0, 23), minutes=random.randint(0, 59))
        amt = random.randint(500, 500000)
        transactions.append({
            "Transaction_ID": f"TXN{str(txn_counter).zfill(7)}",
            "Sender_Account_ID": sender,
            "Receiver_Account_ID": receiver,
            "Timestamp": t.strftime("%Y-%m-%d %H:%M:%S"),
            "Amount": amt,
            "Transaction_Type": random.choice(TXN_TYPES),
            "Country": acct_countries.get(sender, "India"),
            "Channel": random.choice(CHANNELS),
            "Currency": random.choice(CURRENCIES),
            "IP_Address": generate_ip(acct_countries.get(sender, "India")),
            "Device_ID": acct_devices[sender]  # Add device_id
        })
        txn_counter += 1

    return pd.DataFrame(transactions)


def generate_pep_watchlist(accounts_df):
    """Generate PEP watchlist with entries matching some account holders."""
    watchlist = []
    # Generate 30 PEP entries; some should match account PEPs
    pep_accounts = accounts_df[accounts_df["Is_PEP"] == True]

    for i, (_, row) in enumerate(pep_accounts.iterrows()):
        name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
        watchlist.append({
            "Name": name,
            "Country": row["Country"],
            "Risk_Level": random.choice(["High", "Very High", "Critical"]),
            "Political_Position": random.choice(POLITICAL_POSITIONS),
            "Associated_Account_ID": row["Account_ID"]
        })

    # Add extra PEPs not linked to accounts
    while len(watchlist) < 30:
        watchlist.append({
            "Name": f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}",
            "Country": random.choice(ALL_COUNTRIES),
            "Risk_Level": random.choice(["High", "Very High", "Critical"]),
            "Political_Position": random.choice(POLITICAL_POSITIONS),
            "Associated_Account_ID": ""
        })

    return pd.DataFrame(watchlist)


def generate_weighted_risk_dataset(accounts_df, transactions_df):
    """Generate weighted risk dataset with IP/location data for geographic entropy scoring."""
    records = []
    CITY_COORDS = {
        "India": [(28.6139, 77.2090), (19.0760, 72.8777), (12.9716, 77.5946), (13.0827, 80.2707), (22.5726, 88.3639)],
        "USA": [(40.7128, -74.0060), (34.0522, -118.2437), (41.8781, -87.6298)],
        "UK": [(51.5074, -0.1278), (53.4808, -2.2426)],
        "Germany": [(52.5200, 13.4050), (48.1351, 11.5820)],
        "Japan": [(35.6762, 139.6503), (34.6937, 135.5023)],
        "Russia": [(55.7558, 37.6173), (59.9343, 30.3351)],
        "China": [(39.9042, 116.4074), (31.2304, 121.4737)],
        "Iran": [(35.6892, 51.3890)],
        "North Korea": [(39.0392, 125.7625)],
        "Pakistan": [(24.8607, 67.0011), (33.6844, 73.0479)],
        "Nigeria": [(6.5244, 3.3792), (9.0579, 7.4951)],
        "Panama": [(8.9824, -79.5199)],
        "Cayman Islands": [(19.3133, -81.2546)],
    }

    for _, acct in accounts_df.iterrows():
        acct_txns = transactions_df[
            (transactions_df["Sender_Account_ID"] == acct["Account_ID"]) |
            (transactions_df["Receiver_Account_ID"] == acct["Account_ID"])
        ]

        # Generate location entries from transaction IPs
        for _, txn in acct_txns.head(20).iterrows():
            country = txn["Country"]
            coords = random.choice(CITY_COORDS.get(country, [(0, 0)]))
            lat = coords[0] + random.uniform(-0.5, 0.5)
            lon = coords[1] + random.uniform(-0.5, 0.5)

            records.append({
                "Account_ID": acct["Account_ID"],
                "Transaction_ID": txn["Transaction_ID"],
                "Timestamp": txn["Timestamp"],
                "IP_Address": txn["IP_Address"],
                "Latitude": round(lat, 4),
                "Longitude": round(lon, 4),
                "Country": country,
                "City": f"City_{random.randint(1, 50)}",
                "Is_VPN": random.random() < 0.1,
                "Device_Fingerprint": f"DEV{random.randint(1000, 9999)}"
            })

    return pd.DataFrame(records)


def main():
    print("🔧 Generating RegShield datasets...")

    accounts_df = generate_accounts(200)
    print(f"  ✅ Account Master: {len(accounts_df)} accounts")

    transactions_df = generate_transactions(accounts_df, 2500)
    print(f"  ✅ Transaction Log: {len(transactions_df)} transactions")

    pep_df = generate_pep_watchlist(accounts_df)
    print(f"  ✅ PEP Watchlist: {len(pep_df)} entries")

    weighted_df = generate_weighted_risk_dataset(accounts_df, transactions_df)
    print(f"  ✅ Weighted Risk Dataset: {len(weighted_df)} records")

    # Save
    accounts_df.to_excel(os.path.join(DATA_DIR, "regshield_account_master.xlsx"), index=False)
    transactions_df.to_excel(os.path.join(DATA_DIR, "regshield_transaction_log.xlsx"), index=False)
    pep_df.to_excel(os.path.join(DATA_DIR, "regshield_pep_watchlist.xlsx"), index=False)
    weighted_df.to_excel(os.path.join(DATA_DIR, "weighted_risk_dataset.xlsx"), index=False)

    print("\n📁 All datasets saved to data/ directory.")
    print(f"   Structuring accounts: ACC00001–ACC00010")
    print(f"   Circular chain accounts: ACC00011–ACC00020")
    print(f"   Dormant accounts: ACC00021–ACC00025")
    print(f"   PEP accounts: ACC00026–ACC00035")
    print(f"   High-risk country: ACC00036–ACC00045")
    print(f"   Shell/KYC-gap: ACC00046–ACC00055")


if __name__ == "__main__":
    main()
