"use client"

import { useState, useEffect } from "react"
import { 
  Shield,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Play,
  Pause,
  Edit,
  Copy,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Code,
  Zap,
  Target,
  Clock,
  TrendingUp,
} from "lucide-react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface Rule {
  id: string
  name: string
  description: string
  category: "velocity" | "amount" | "behavior" | "geographic" | "device"
  severity: "critical" | "high" | "medium" | "low"
  isActive: boolean
  condition: string
  action: string
  triggers: number
  lastTriggered: Date | null
  createdAt: Date
  accuracy: number
}

const generateRules = (): Rule[] => {
  const rules = [
    {
      name: "High-Value Transaction Alert",
      description: "Flag transactions exceeding $10,000 threshold",
      category: "amount" as const,
      severity: "high" as const,
      condition: "transaction.amount > 10000",
      action: "FLAG_FOR_REVIEW",
    },
    {
      name: "Velocity Check - 10 Transactions",
      description: "Alert when account exceeds 10 transactions in 1 hour",
      category: "velocity" as const,
      severity: "medium" as const,
      condition: "transactions.count(1h) > 10",
      action: "ALERT_ANALYST",
    },
    {
      name: "Geographic Anomaly",
      description: "Detect transactions from unusual locations",
      category: "geographic" as const,
      severity: "critical" as const,
      condition: "location.distance(last_location) > 1000km AND time_diff < 2h",
      action: "BLOCK_TRANSACTION",
    },
    {
      name: "New Device Login",
      description: "Flag login attempts from unrecognized devices",
      category: "device" as const,
      severity: "medium" as const,
      condition: "device.fingerprint NOT IN trusted_devices",
      action: "REQUIRE_2FA",
    },
    {
      name: "Unusual Time Activity",
      description: "Monitor transactions during atypical hours",
      category: "behavior" as const,
      severity: "low" as const,
      condition: "transaction.time NOT IN account.typical_hours",
      action: "LOG_ACTIVITY",
    },
    {
      name: "Rapid Succession Transfers",
      description: "Block multiple transfers within short timeframe",
      category: "velocity" as const,
      severity: "critical" as const,
      condition: "transfers.count(10m) > 3",
      action: "BLOCK_ACCOUNT",
    },
    {
      name: "Round Amount Detection",
      description: "Flag suspiciously round transaction amounts",
      category: "amount" as const,
      severity: "low" as const,
      condition: "transaction.amount % 1000 == 0 AND amount > 5000",
      action: "FLAG_FOR_REVIEW",
    },
    {
      name: "Cross-Border Transfer",
      description: "Enhanced monitoring for international transfers",
      category: "geographic" as const,
      severity: "high" as const,
      condition: "destination.country != origin.country",
      action: "ENHANCED_REVIEW",
    },
  ]

  return rules.map((rule, i) => ({
    id: `RULE-${String(i + 1).padStart(4, "0")}`,
    ...rule,
    isActive: Math.random() > 0.2,
    triggers: Math.floor(Math.random() * 500) + 10,
    lastTriggered: Math.random() > 0.3 ? new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000) : null,
    createdAt: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000),
    accuracy: Math.floor(Math.random() * 20) + 80,
  }))
}

const categoryStyles = {
  velocity: { badge: "bg-chart-2/10 text-chart-2 border-chart-2/30", icon: Zap },
  amount: { badge: "bg-primary/10 text-primary border-primary/30", icon: Target },
  behavior: { badge: "bg-chart-3/10 text-chart-3 border-chart-3/30", icon: TrendingUp },
  geographic: { badge: "bg-chart-1/10 text-chart-1 border-chart-1/30", icon: Target },
  device: { badge: "bg-destructive/10 text-destructive border-destructive/30", icon: Shield },
}

const severityStyles = {
  critical: "bg-destructive/10 text-destructive border-destructive/30",
  high: "bg-chart-3/10 text-chart-3 border-chart-3/30",
  medium: "bg-chart-2/10 text-chart-2 border-chart-2/30",
  low: "bg-chart-1/10 text-chart-1 border-chart-1/30",
}

export default function RulesPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [rules, setRules] = useState<Rule[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [severityFilter, setSeverityFilter] = useState<string>("all")
  const [selectedRule, setSelectedRule] = useState<Rule | null>(null)
  const [isCreateOpen, setIsCreateOpen] = useState(false)

  useEffect(() => {
    setRules(generateRules())
  }, [])

  const filteredRules = rules.filter(rule => {
    const matchesSearch = rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         rule.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = categoryFilter === "all" || rule.category === categoryFilter
    const matchesSeverity = severityFilter === "all" || rule.severity === severityFilter
    return matchesSearch && matchesCategory && matchesSeverity
  })

  const toggleRule = (ruleId: string) => {
    setRules(prev => prev.map(rule => 
      rule.id === ruleId ? { ...rule, isActive: !rule.isActive } : rule
    ))
  }

  const stats = {
    total: rules.length,
    active: rules.filter(r => r.isActive).length,
    triggers: rules.reduce((sum, r) => sum + r.triggers, 0),
    avgAccuracy: Math.round(rules.reduce((sum, r) => sum + r.accuracy, 0) / rules.length),
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-1 flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Page Header */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Rules Engine</h1>
                <p className="text-sm text-muted-foreground">
                  Configure and manage fraud detection rules
                </p>
              </div>
              <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Rule
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Create New Rule</DialogTitle>
                    <DialogDescription>
                      Define a new fraud detection rule with conditions and actions
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Rule Name</Label>
                      <Input placeholder="e.g., High-Value International Transfer" className="bg-secondary/50" />
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea placeholder="Describe what this rule detects..." className="bg-secondary/50" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <Select>
                          <SelectTrigger className="bg-secondary/50">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="velocity">Velocity</SelectItem>
                            <SelectItem value="amount">Amount</SelectItem>
                            <SelectItem value="behavior">Behavior</SelectItem>
                            <SelectItem value="geographic">Geographic</SelectItem>
                            <SelectItem value="device">Device</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Severity</Label>
                        <Select>
                          <SelectTrigger className="bg-secondary/50">
                            <SelectValue placeholder="Select severity" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="critical">Critical</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Condition (Rule Expression)</Label>
                      <Textarea 
                        placeholder="transaction.amount > 10000 AND location.country != 'US'"
                        className="font-mono text-sm bg-secondary/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Action</Label>
                      <Select>
                        <SelectTrigger className="bg-secondary/50">
                          <SelectValue placeholder="Select action" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="block">Block Transaction</SelectItem>
                          <SelectItem value="flag">Flag for Review</SelectItem>
                          <SelectItem value="alert">Alert Analyst</SelectItem>
                          <SelectItem value="2fa">Require 2FA</SelectItem>
                          <SelectItem value="log">Log Activity</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={() => setIsCreateOpen(false)}>
                      Create Rule
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                    <Shield className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.total}</p>
                    <p className="text-xs text-muted-foreground">Total Rules</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-1/10">
                    <CheckCircle2 className="h-5 w-5 text-chart-1" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-chart-1">{stats.active}</p>
                    <p className="text-xs text-muted-foreground">Active Rules</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-3/10">
                    <Zap className="h-5 w-5 text-chart-3" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-chart-3">{stats.triggers.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Total Triggers</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Target className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">{stats.avgAccuracy}%</p>
                    <p className="text-xs text-muted-foreground">Avg Accuracy</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Rules List */}
              <div className="lg:col-span-2">
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="border-b border-border/50">
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                      <CardTitle>Detection Rules</CardTitle>
                      <div className="flex gap-2">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="Search rules..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-[180px] pl-9 bg-secondary/50"
                          />
                        </div>
                        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                          <SelectTrigger className="w-[130px] bg-secondary/50">
                            <SelectValue placeholder="Category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Categories</SelectItem>
                            <SelectItem value="velocity">Velocity</SelectItem>
                            <SelectItem value="amount">Amount</SelectItem>
                            <SelectItem value="behavior">Behavior</SelectItem>
                            <SelectItem value="geographic">Geographic</SelectItem>
                            <SelectItem value="device">Device</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardHeader>
                  <ScrollArea className="h-[600px]">
                    <div className="divide-y divide-border/50">
                      {filteredRules.map((rule) => {
                        const CategoryIcon = categoryStyles[rule.category].icon
                        return (
                          <div
                            key={rule.id}
                            className={cn(
                              "flex cursor-pointer items-start gap-4 p-4 transition-colors hover:bg-secondary/30",
                              selectedRule?.id === rule.id && "bg-secondary/50"
                            )}
                            onClick={() => setSelectedRule(rule)}
                          >
                            <div className={cn(
                              "mt-1 flex h-10 w-10 items-center justify-center rounded-lg",
                              rule.isActive ? "bg-primary/10" : "bg-secondary"
                            )}>
                              <CategoryIcon className={cn(
                                "h-5 w-5",
                                rule.isActive ? "text-primary" : "text-muted-foreground"
                              )} />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <p className={cn(
                                      "font-medium",
                                      !rule.isActive && "text-muted-foreground"
                                    )}>
                                      {rule.name}
                                    </p>
                                    {!rule.isActive && (
                                      <Badge variant="outline" className="text-xs bg-muted text-muted-foreground">
                                        Disabled
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="mt-1 text-sm text-muted-foreground line-clamp-1">
                                    {rule.description}
                                  </p>
                                </div>
                                <Switch
                                  checked={rule.isActive}
                                  onCheckedChange={() => toggleRule(rule.id)}
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>
                              <div className="mt-2 flex flex-wrap items-center gap-2">
                                <Badge variant="outline" className={cn("text-xs capitalize", categoryStyles[rule.category].badge)}>
                                  {rule.category}
                                </Badge>
                                <Badge variant="outline" className={cn("text-xs capitalize", severityStyles[rule.severity])}>
                                  {rule.severity}
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  {rule.triggers} triggers
                                </span>
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </ScrollArea>
                </Card>
              </div>

              {/* Rule Details */}
              <div>
                <Card className="border-border/50 bg-card/50 backdrop-blur sticky top-6">
                  {selectedRule ? (
                    <>
                      <CardHeader className="border-b border-border/50">
                        <div className="flex items-start justify-between">
                          <div>
                            <Badge variant="outline" className={cn("mb-2 capitalize", severityStyles[selectedRule.severity])}>
                              {selectedRule.severity} Severity
                            </Badge>
                            <CardTitle className="text-lg">{selectedRule.name}</CardTitle>
                            <CardDescription className="mt-1">{selectedRule.description}</CardDescription>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit Rule
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Copy className="mr-2 h-4 w-4" />
                                Duplicate
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Play className="mr-2 h-4 w-4" />
                                Test Rule
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6 pt-6">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Status</p>
                            <div className="mt-1 flex items-center gap-2">
                              {selectedRule.isActive ? (
                                <>
                                  <CheckCircle2 className="h-4 w-4 text-chart-1" />
                                  <span className="font-medium text-chart-1">Active</span>
                                </>
                              ) : (
                                <>
                                  <XCircle className="h-4 w-4 text-muted-foreground" />
                                  <span className="font-medium text-muted-foreground">Disabled</span>
                                </>
                              )}
                            </div>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Category</p>
                            <Badge variant="outline" className={cn("mt-1 capitalize", categoryStyles[selectedRule.category].badge)}>
                              {selectedRule.category}
                            </Badge>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Total Triggers</p>
                            <p className="mt-1 font-mono font-bold">{selectedRule.triggers}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Accuracy</p>
                            <p className={cn(
                              "mt-1 font-mono font-bold",
                              selectedRule.accuracy >= 90 ? "text-chart-1" :
                              selectedRule.accuracy >= 80 ? "text-chart-2" : "text-chart-3"
                            )}>
                              {selectedRule.accuracy}%
                            </p>
                          </div>
                        </div>

                        <div>
                          <p className="mb-2 text-sm text-muted-foreground">Condition</p>
                          <div className="rounded-lg bg-secondary/50 p-3">
                            <code className="text-sm text-primary">{selectedRule.condition}</code>
                          </div>
                        </div>

                        <div>
                          <p className="mb-2 text-sm text-muted-foreground">Action</p>
                          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                            {selectedRule.action}
                          </Badge>
                        </div>

                        <div className="text-sm text-muted-foreground">
                          <p>Last triggered: {selectedRule.lastTriggered ? selectedRule.lastTriggered.toLocaleString() : "Never"}</p>
                          <p>Created: {selectedRule.createdAt.toLocaleDateString()}</p>
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button className="flex-1" size="sm">
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Rule
                          </Button>
                          <Button variant="outline" size="sm">
                            <Play className="mr-2 h-4 w-4" />
                            Test
                          </Button>
                        </div>
                      </CardContent>
                    </>
                  ) : (
                    <CardContent className="flex h-[400px] items-center justify-center">
                      <div className="text-center">
                        <Shield className="mx-auto h-12 w-12 text-muted-foreground/30" />
                        <p className="mt-4 text-sm text-muted-foreground">
                          Select a rule to view details
                        </p>
                      </div>
                    </CardContent>
                  )}
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
