"""
PEP Screening Engine
Checks accounts against Politically Exposed Person watchlist.
"""
import pandas as pd


class PEPEngine:
    def __init__(self, pep_watchlist_df=None):
        self.pep_watchlist = pep_watchlist_df
        self._pep_accounts = set()
        if pep_watchlist_df is not None:
            self._index_pep_accounts()

    def _index_pep_accounts(self):
        """Build set of PEP-linked account IDs."""
        if self.pep_watchlist is not None and "Associated_Account_ID" in self.pep_watchlist.columns:
            self._pep_accounts = set(
                self.pep_watchlist[self.pep_watchlist["Associated_Account_ID"] != ""]["Associated_Account_ID"].tolist()
            )

    def load_watchlist(self, pep_watchlist_df):
        self.pep_watchlist = pep_watchlist_df
        self._index_pep_accounts()

    def evaluate(self, account_id, transactions_df, accounts_df):
        """
        Evaluate PEP risk for a given account.
        Returns risk score [0-20] and details.
        """
        risk_score = 0
        details = []
        flags = []

        acct_info = accounts_df[accounts_df["Account_ID"] == account_id]
        if acct_info.empty:
            return {"score": 0, "details": [], "flags": []}

        acct = acct_info.iloc[0]
        is_pep = acct.get("Is_PEP", False)
        pep_category = acct.get("PEP_Category", "")

        # Rule 1: Account holder is PEP
        if is_pep or account_id in self._pep_accounts:
            penalty = 10
            risk_score += penalty
            flags.append(f"PEP ACCOUNT: {account_id} ({pep_category})")
            details.append({
                "rule": "PEP account holder",
                "category": pep_category,
                "penalty": penalty
            })

            # Rule 2: High-value transactions by PEP
            pep_txns = transactions_df[
                transactions_df["Sender_Account_ID"] == account_id
            ]
            high_value_pep = pep_txns[pep_txns["Amount"] >= 500000]
            if len(high_value_pep) > 0:
                total_high = high_value_pep["Amount"].sum()
                penalty = min(10, len(high_value_pep) * 2)
                risk_score += penalty
                flags.append(
                    f"PEP HIGH-VALUE: {len(high_value_pep)} txns ≥ ₹500,000 "
                    f"(total: ₹{total_high:,.0f})"
                )
                details.append({
                    "rule": "PEP high-value transactions",
                    "count": len(high_value_pep),
                    "total": total_high,
                    "penalty": penalty
                })

        # Rule 3: Transacting with PEP accounts
        sent_to_pep = transactions_df[
            (transactions_df["Sender_Account_ID"] == account_id) &
            (transactions_df["Receiver_Account_ID"].isin(self._pep_accounts))
        ]
        recv_from_pep = transactions_df[
            (transactions_df["Receiver_Account_ID"] == account_id) &
            (transactions_df["Sender_Account_ID"].isin(self._pep_accounts))
        ]

        pep_interactions = len(sent_to_pep) + len(recv_from_pep)
        if pep_interactions > 0 and not is_pep:
            penalty = min(8, pep_interactions * 2)
            risk_score += penalty
            flags.append(f"PEP INTERACTION: {pep_interactions} transactions with PEP accounts")
            details.append({
                "rule": "PEP interaction",
                "interactions": pep_interactions,
                "penalty": penalty
            })

        return {
            "score": min(risk_score, 20),
            "details": details,
            "flags": flags
        }
