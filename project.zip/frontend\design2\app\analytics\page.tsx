"use client"

import { useState, useEffect } from "react"
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign,
  AlertTriangle,
  Shield,
  Users,
  Activity,
  Calendar,
} from "lucide-react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts"
import { cn } from "@/lib/utils"

// Generate time series data
const generateTimeSeriesData = () => {
  const now = new Date()
  return Array.from({ length: 30 }, (_, i) => {
    const date = new Date(now)
    date.setDate(date.getDate() - (29 - i))
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      transactions: Math.floor(Math.random() * 5000) + 8000,
      flagged: Math.floor(Math.random() * 100) + 50,
      blocked: Math.floor(Math.random() * 30) + 10,
      amount: Math.floor(Math.random() * 500000) + 200000,
    }
  })
}

const generateCategoryData = () => [
  { name: "Transaction", value: 35, color: "hsl(var(--chart-1))" },
  { name: "Authentication", value: 25, color: "hsl(var(--chart-2))" },
  { name: "Account", value: 20, color: "hsl(var(--chart-3))" },
  { name: "Network", value: 12, color: "hsl(var(--chart-4))" },
  { name: "Compliance", value: 8, color: "hsl(var(--chart-5))" },
]

const generateHourlyData = () => {
  return Array.from({ length: 24 }, (_, i) => ({
    hour: `${i.toString().padStart(2, '0')}:00`,
    normal: Math.floor(Math.random() * 400) + 200,
    suspicious: Math.floor(Math.random() * 50) + 10,
    blocked: Math.floor(Math.random() * 15) + 2,
  }))
}

const generateRiskDistribution = () => [
  { range: "0-20", count: 45000, fill: "hsl(var(--chart-1))" },
  { range: "21-40", count: 28000, fill: "hsl(var(--chart-2))" },
  { range: "41-60", count: 15000, fill: "hsl(var(--chart-3))" },
  { range: "61-80", count: 8000, fill: "hsl(var(--chart-3))" },
  { range: "81-100", count: 4000, fill: "hsl(var(--destructive))" },
]

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-lg border border-border/50 bg-card p-3 shadow-xl">
        <p className="mb-2 text-sm font-medium text-foreground">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {entry.value.toLocaleString()}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export default function AnalyticsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [timeSeriesData, setTimeSeriesData] = useState<ReturnType<typeof generateTimeSeriesData>>([])
  const [categoryData, setCategoryData] = useState<ReturnType<typeof generateCategoryData>>([])
  const [hourlyData, setHourlyData] = useState<ReturnType<typeof generateHourlyData>>([])
  const [riskDistribution, setRiskDistribution] = useState<ReturnType<typeof generateRiskDistribution>>([])
  const [timeRange, setTimeRange] = useState("30d")

  useEffect(() => {
    setTimeSeriesData(generateTimeSeriesData())
    setCategoryData(generateCategoryData())
    setHourlyData(generateHourlyData())
    setRiskDistribution(generateRiskDistribution())
  }, [])

  const stats = [
    {
      title: "Total Transactions",
      value: "1.2M",
      change: "+12.5%",
      trend: "up",
      icon: Activity,
      description: "Last 30 days",
    },
    {
      title: "Fraud Detected",
      value: "2,847",
      change: "-8.3%",
      trend: "down",
      icon: AlertTriangle,
      description: "Blocked attempts",
    },
    {
      title: "Amount Protected",
      value: "$4.8M",
      change: "+15.2%",
      trend: "up",
      icon: Shield,
      description: "Potential loss prevented",
    },
    {
      title: "Detection Rate",
      value: "99.7%",
      change: "+0.2%",
      trend: "up",
      icon: TrendingUp,
      description: "True positive rate",
    },
  ]

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-1 flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Page Header */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Analytics Dashboard</h1>
                <p className="text-sm text-muted-foreground">
                  Comprehensive fraud detection metrics and trends
                </p>
              </div>
              <div className="flex gap-2">
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-[140px] bg-secondary/50">
                    <Calendar className="mr-2 h-4 w-4" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d">Last 7 days</SelectItem>
                    <SelectItem value="30d">Last 30 days</SelectItem>
                    <SelectItem value="90d">Last 90 days</SelectItem>
                    <SelectItem value="1y">Last year</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">Export Report</Button>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-4">
              {stats.map((stat, index) => {
                const Icon = stat.icon
                return (
                  <Card key={index} className="border-border/50 bg-card/50 backdrop-blur">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        {stat.title}
                      </CardTitle>
                      <Icon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{stat.value}</div>
                      <div className="flex items-center gap-1 text-xs">
                        {stat.trend === "up" ? (
                          <TrendingUp className="h-3 w-3 text-chart-1" />
                        ) : (
                          <TrendingDown className="h-3 w-3 text-chart-1" />
                        )}
                        <span className={stat.trend === "up" ? "text-chart-1" : "text-chart-1"}>
                          {stat.change}
                        </span>
                        <span className="text-muted-foreground">{stat.description}</span>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Main Charts Row */}
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Transaction Volume Chart */}
              <Card className="border-border/50 bg-card/50 backdrop-blur lg:col-span-2">
                <CardHeader>
                  <CardTitle>Transaction Volume</CardTitle>
                  <CardDescription>Daily transaction count with flagged and blocked</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={timeSeriesData}>
                        <defs>
                          <linearGradient id="transactionsGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                          </linearGradient>
                          <linearGradient id="flaggedGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--chart-3))" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="hsl(var(--chart-3))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                        <XAxis 
                          dataKey="date" 
                          stroke="hsl(var(--muted-foreground))" 
                          fontSize={12}
                          tickLine={false}
                          axisLine={false}
                        />
                        <YAxis 
                          stroke="hsl(var(--muted-foreground))" 
                          fontSize={12}
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Area
                          type="monotone"
                          dataKey="transactions"
                          stroke="hsl(var(--chart-1))"
                          fill="url(#transactionsGradient)"
                          strokeWidth={2}
                          name="Transactions"
                        />
                        <Area
                          type="monotone"
                          dataKey="flagged"
                          stroke="hsl(var(--chart-3))"
                          fill="url(#flaggedGradient)"
                          strokeWidth={2}
                          name="Flagged"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Alert Categories Pie Chart */}
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader>
                  <CardTitle>Alert Categories</CardTitle>
                  <CardDescription>Distribution by type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value: number) => [`${value}%`, '']}
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    {categoryData.map((item, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <div 
                          className="h-3 w-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-muted-foreground">{item.name}</span>
                        <span className="ml-auto font-medium">{item.value}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Second Row Charts */}
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Hourly Activity */}
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader>
                  <CardTitle>Hourly Activity Pattern</CardTitle>
                  <CardDescription>Transaction distribution by hour</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[280px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={hourlyData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                        <XAxis 
                          dataKey="hour" 
                          stroke="hsl(var(--muted-foreground))" 
                          fontSize={10}
                          tickLine={false}
                          axisLine={false}
                          interval={3}
                        />
                        <YAxis 
                          stroke="hsl(var(--muted-foreground))" 
                          fontSize={12}
                          tickLine={false}
                          axisLine={false}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar dataKey="normal" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} name="Normal" />
                        <Bar dataKey="suspicious" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} name="Suspicious" />
                        <Bar dataKey="blocked" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} name="Blocked" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Score Distribution */}
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader>
                  <CardTitle>Risk Score Distribution</CardTitle>
                  <CardDescription>Account distribution by PAMRS score</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[280px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={riskDistribution} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} horizontal />
                        <XAxis 
                          type="number"
                          stroke="hsl(var(--muted-foreground))" 
                          fontSize={12}
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                        />
                        <YAxis 
                          type="category"
                          dataKey="range" 
                          stroke="hsl(var(--muted-foreground))" 
                          fontSize={12}
                          tickLine={false}
                          axisLine={false}
                          width={60}
                        />
                        <Tooltip 
                          formatter={(value: number) => [value.toLocaleString(), 'Accounts']}
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                          }}
                        />
                        <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                          {riskDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Financial Impact Chart */}
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Financial Impact Analysis</CardTitle>
                <CardDescription>Protected funds vs potential losses over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                      <XAxis 
                        dataKey="date" 
                        stroke="hsl(var(--muted-foreground))" 
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis 
                        stroke="hsl(var(--muted-foreground))" 
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                      />
                      <Tooltip 
                        formatter={(value: number) => [`$${value.toLocaleString()}`, '']}
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="hsl(var(--chart-1))" 
                        strokeWidth={2}
                        dot={false}
                        name="Protected Amount"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
