"""
Structuring Detection Engine
Detects smurfing: multiple small transactions below reporting threshold within 24h.
Supports adaptive threshold (Secret Reveal #1).
"""
import pandas as pd
from datetime import timedelta


class StructuringEngine:
    def __init__(self, base_threshold=50000, reduction_pct=0.0):
        """
        base_threshold: regulatory reporting threshold (INR)
        reduction_pct: dynamic reduction (0.3 = 30% reduction for Secret Reveal #1)
        """
        self.base_threshold = base_threshold
        self.reduction_pct = reduction_pct
        self.effective_threshold = base_threshold * (1 - reduction_pct)
        # Aggregate limit: if total in 24h exceeds this, flag
        self.aggregate_limit = self.effective_threshold * 5

    def update_threshold(self, reduction_pct):
        """Apply adaptive regulatory threshold shift (Secret Reveal #1)."""
        self.reduction_pct = reduction_pct
        self.effective_threshold = self.base_threshold * (1 - reduction_pct)
        self.aggregate_limit = self.effective_threshold * 5

    def evaluate(self, account_id, transactions_df):
        """
        Evaluate structuring risk for a given account.
        Returns risk score [0-30] and details.
        """
        # Filter sent transactions for this account
        acct_txns = transactions_df[
            transactions_df["Sender_Account_ID"] == account_id
        ].copy()

        if acct_txns.empty:
            return {"score": 0, "details": [], "flags": []}

        acct_txns["Timestamp"] = pd.to_datetime(acct_txns["Timestamp"])
        acct_txns = acct_txns.sort_values("Timestamp")

        risk_score = 0
        details = []
        flags = []

        # Rule 1: Count near-threshold transactions
        near_threshold = acct_txns[
            (acct_txns["Amount"] >= self.effective_threshold * 0.7) &
            (acct_txns["Amount"] < self.effective_threshold)
        ]
        if len(near_threshold) >= 3:
            penalty = min(15, len(near_threshold) * 3)
            risk_score += penalty
            flags.append(f"STRUCTURING: {len(near_threshold)} near-threshold txns (< ₹{self.effective_threshold:,.0f})")
            details.append({
                "rule": "Near-threshold deposits",
                "count": len(near_threshold),
                "threshold": self.effective_threshold,
                "penalty": penalty
            })

        # Rule 2: 24-hour rolling window aggregate
        if len(acct_txns) >= 2:
            min_time = acct_txns["Timestamp"].min()
            max_time = acct_txns["Timestamp"].max()
            window_start = min_time

            while window_start <= max_time:
                window_end = window_start + timedelta(hours=24)
                window_txns = acct_txns[
                    (acct_txns["Timestamp"] >= window_start) &
                    (acct_txns["Timestamp"] < window_end)
                ]
                total = window_txns["Amount"].sum()
                count = len(window_txns)

                if count >= 3 and total > self.aggregate_limit:
                    penalty = min(15, 5 + int((total / self.aggregate_limit) * 5))
                    risk_score += penalty
                    flags.append(
                        f"AGGREGATE BREACH: {count} txns totaling ₹{total:,.0f} in 24h window "
                        f"(limit: ₹{self.aggregate_limit:,.0f})"
                    )
                    details.append({
                        "rule": "24h aggregate breach",
                        "window_start": str(window_start),
                        "window_end": str(window_end),
                        "count": count,
                        "total": total,
                        "limit": self.aggregate_limit,
                        "penalty": penalty
                    })
                    break  # one breach is enough

                window_start += timedelta(hours=6)

        # Rule 3: Repeated small deposits (cash-based)
        cash_deposits = acct_txns[
            (acct_txns["Transaction_Type"].isin(["Cash Deposit", "Deposit"])) &
            (acct_txns["Amount"] < self.effective_threshold * 0.5)
        ]
        if len(cash_deposits) >= 5:
            penalty = min(10, len(cash_deposits))
            risk_score += penalty
            flags.append(f"REPEATED SMALL DEPOSITS: {len(cash_deposits)} cash deposits below ₹{self.effective_threshold*0.5:,.0f}")
            details.append({
                "rule": "Repeated small cash deposits",
                "count": len(cash_deposits),
                "penalty": penalty
            })

        return {
            "score": min(risk_score, 30),  # Cap at 30
            "details": details,
            "flags": flags,
            "effective_threshold": self.effective_threshold
        }
