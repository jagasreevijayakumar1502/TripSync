"use client"

import { useState, useEffect } from "react"
import { 
  Search, 
  Filter, 
  Download, 
  MoreHorizontal,
  Eye,
  Flag,
  Ban,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  ChevronLeft,
  ChevronRight,
  Building2,
  User,
  CreditCard,
} from "lucide-react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"

interface Account {
  id: string
  accountNumber: string
  holderName: string
  type: "individual" | "business" | "corporate"
  status: "active" | "flagged" | "frozen" | "closed"
  balance: number
  riskScore: number
  lastActivity: string
  openDate: string
  transactions: number
}

const generateAccounts = (): Account[] => {
  const names = [
    "Alice Johnson", "Bob Williams", "Carol Davis", "David Miller", "Eva Martinez",
    "Frank Garcia", "Grace Lee", "Henry Wilson", "Ivy Chen", "Jack Thompson",
    "Karen Brown", "Leo Rodriguez", "Maria Gonzalez", "Nathan Kim", "Olivia Taylor",
    "Apex Industries", "Global Trade Co", "Tech Solutions Inc", "Finance Partners LLC",
    "Blue Ocean Ventures", "Metro Holdings", "Summit Capital", "Digital Services Corp"
  ]
  
  const types: Account["type"][] = ["individual", "business", "corporate"]
  const statuses: Account["status"][] = ["active", "flagged", "frozen", "closed"]
  
  return Array.from({ length: 50 }, (_, i) => ({
    id: `ACC-${String(i + 1).padStart(6, "0")}`,
    accountNumber: `****${String(Math.floor(Math.random() * 10000)).padStart(4, "0")}`,
    holderName: names[Math.floor(Math.random() * names.length)],
    type: types[Math.floor(Math.random() * types.length)],
    status: statuses[Math.floor(Math.random() * statuses.length)],
    balance: Math.floor(Math.random() * 1000000) + 1000,
    riskScore: Math.floor(Math.random() * 100),
    lastActivity: `${Math.floor(Math.random() * 24)}h ago`,
    openDate: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000 * 3).toLocaleDateString(),
    transactions: Math.floor(Math.random() * 500) + 10,
  }))
}

const statusStyles = {
  active: { badge: "bg-chart-1/10 text-chart-1 border-chart-1/30", label: "Active" },
  flagged: { badge: "bg-chart-3/10 text-chart-3 border-chart-3/30", label: "Flagged" },
  frozen: { badge: "bg-destructive/10 text-destructive border-destructive/30", label: "Frozen" },
  closed: { badge: "bg-muted text-muted-foreground border-muted", label: "Closed" },
}

const typeIcons = {
  individual: User,
  business: Building2,
  corporate: CreditCard,
}

export default function AccountsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [accounts, setAccounts] = useState<Account[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  useEffect(() => {
    setAccounts(generateAccounts())
  }, [])

  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = account.holderName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         account.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || account.status === statusFilter
    const matchesType = typeFilter === "all" || account.type === typeFilter
    return matchesSearch && matchesStatus && matchesType
  })

  const totalPages = Math.ceil(filteredAccounts.length / itemsPerPage)
  const paginatedAccounts = filteredAccounts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const stats = {
    total: accounts.length,
    active: accounts.filter(a => a.status === "active").length,
    flagged: accounts.filter(a => a.status === "flagged").length,
    frozen: accounts.filter(a => a.status === "frozen").length,
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-1 flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Page Header */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Account Management</h1>
                <p className="text-sm text-muted-foreground">
                  Monitor and manage all customer accounts
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
                <Button size="sm">
                  Add Account
                </Button>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Total Accounts
                  </CardTitle>
                  <User className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.total.toLocaleString()}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Active
                  </CardTitle>
                  <CheckCircle className="h-4 w-4 text-chart-1" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-chart-1">{stats.active}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Flagged
                  </CardTitle>
                  <AlertTriangle className="h-4 w-4 text-chart-3" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-chart-3">{stats.flagged}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Frozen
                  </CardTitle>
                  <Ban className="h-4 w-4 text-destructive" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-destructive">{stats.frozen}</div>
                </CardContent>
              </Card>
            </div>

            {/* Filters */}
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardContent className="p-4">
                <div className="flex flex-col gap-4 md:flex-row md:items-center">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Search accounts..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9 bg-secondary/50"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[140px] bg-secondary/50">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="flagged">Flagged</SelectItem>
                        <SelectItem value="frozen">Frozen</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={typeFilter} onValueChange={setTypeFilter}>
                      <SelectTrigger className="w-[140px] bg-secondary/50">
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="individual">Individual</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="corporate">Corporate</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="icon">
                      <Filter className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Accounts Table */}
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border/50 hover:bg-transparent">
                      <TableHead className="text-muted-foreground">Account</TableHead>
                      <TableHead className="text-muted-foreground">Holder</TableHead>
                      <TableHead className="text-muted-foreground">Type</TableHead>
                      <TableHead className="text-muted-foreground">Status</TableHead>
                      <TableHead className="text-right text-muted-foreground">Balance</TableHead>
                      <TableHead className="text-muted-foreground">Risk Score</TableHead>
                      <TableHead className="text-muted-foreground">Last Activity</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAccounts.map((account) => {
                      const TypeIcon = typeIcons[account.type]
                      const statusStyle = statusStyles[account.status]
                      return (
                        <TableRow 
                          key={account.id} 
                          className="border-border/50 transition-colors hover:bg-secondary/30"
                        >
                          <TableCell className="font-mono text-sm">{account.id}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary">
                                <TypeIcon className="h-4 w-4 text-muted-foreground" />
                              </div>
                              <span className="font-medium">{account.holderName}</span>
                            </div>
                          </TableCell>
                          <TableCell className="capitalize">{account.type}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={cn("font-medium", statusStyle.badge)}>
                              {statusStyle.label}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            ${account.balance.toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-16 overflow-hidden rounded-full bg-secondary">
                                <div
                                  className={cn(
                                    "h-full transition-all",
                                    account.riskScore >= 80
                                      ? "bg-destructive"
                                      : account.riskScore >= 60
                                        ? "bg-chart-3"
                                        : account.riskScore >= 40
                                          ? "bg-chart-2"
                                          : "bg-chart-1"
                                  )}
                                  style={{ width: `${account.riskScore}%` }}
                                />
                              </div>
                              <span className={cn(
                                "font-mono text-sm",
                                account.riskScore >= 80 ? "text-destructive" :
                                account.riskScore >= 60 ? "text-chart-3" :
                                account.riskScore >= 40 ? "text-chart-2" : "text-chart-1"
                              )}>
                                {account.riskScore}
                              </span>
                              {account.riskScore > 70 ? (
                                <TrendingUp className="h-3 w-3 text-destructive" />
                              ) : (
                                <TrendingDown className="h-3 w-3 text-chart-1" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground">{account.lastActivity}</TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Flag className="mr-2 h-4 w-4" />
                                  Flag Account
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-destructive">
                                  <Ban className="mr-2 h-4 w-4" />
                                  Freeze Account
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>

              {/* Pagination */}
              <div className="flex items-center justify-between border-t border-border/50 px-4 py-3">
                <p className="text-sm text-muted-foreground">
                  Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                  {Math.min(currentPage * itemsPerPage, filteredAccounts.length)} of{" "}
                  {filteredAccounts.length} accounts
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
