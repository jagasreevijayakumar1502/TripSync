"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { MetricsPanel } from "@/components/dashboard/metrics-panel"
import { AlertsPanel } from "@/components/dashboard/alerts-panel"
import { RiskTable } from "@/components/dashboard/risk-table"
import { NetworkGraph } from "@/components/dashboard/network-graph"
import { ActivityChart } from "@/components/dashboard/activity-chart"
import { StreamStatus } from "@/components/dashboard/stream-status"
import { RecentTransactions } from "@/components/dashboard/recent-transactions"
import { SimulationButton } from "@/components/dashboard/simulation-button"
import { useLiveData, getTimeAgo } from "@/hooks/use-live-data"
import { Badge } from "@/components/ui/badge"
import { Wifi } from "lucide-react"

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  
  // Use the live data hook with 3-second update interval
  const liveData = useLiveData(3000)

  // Transform live alerts for the AlertsPanel
  const alertsForPanel = liveData.alerts.map(alert => ({
    ...alert,
    timestamp: alert.timestamp instanceof Date ? alert.timestamp : new Date(),
  }))

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <div className="flex flex-1">
        {/* Sidebar */}
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto space-y-6 p-4 pb-8 md:p-6 lg:p-8">
            {/* Page Header */}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
                    Fraud Detection Dashboard
                  </h1>
                  {liveData.isConnected && (
                    <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30">
                      <span className="relative mr-1.5 flex h-2 w-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-chart-1 opacity-75" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-chart-1" />
                      </span>
                      <Wifi className="mr-1 h-3 w-3" />
                      LIVE
                    </Badge>
                  )}
                </div>
                <p className="text-muted-foreground">
                  Real-time monitoring and risk assessment
                  {liveData.lastUpdate && (
                    <span className="ml-2 text-xs">
                      • Last updated: {getTimeAgo(liveData.lastUpdate)}
                    </span>
                  )}
                </p>
              </div>
              <SimulationButton />
            </div>

            {/* Metrics - Now with 6 cards */}
            <MetricsPanel metrics={liveData.metrics} />

            {/* Activity Chart - Full Width */}
            <ActivityChart />

            {/* Main Grid - Alerts + Network Graph */}
            <div className="grid gap-6 lg:grid-cols-2">
              <AlertsPanel 
                alerts={alertsForPanel} 
                isLive={liveData.isConnected} 
              />
              <NetworkGraph 
                nodes={liveData.networkNodes}
                links={liveData.networkLinks}
                isLive={liveData.isConnected}
              />
            </div>

            {/* Risk Table */}
            <RiskTable 
              accounts={liveData.accounts}
              isLive={liveData.isConnected}
            />

            {/* Recent Transactions */}
            <RecentTransactions 
              transactions={liveData.transactions}
              isLive={liveData.isConnected}
            />
          </div>
        </main>
      </div>

      {/* Stream Status Footer */}
      <StreamStatus isConnected={liveData.isConnected} />
    </div>
  )
}
