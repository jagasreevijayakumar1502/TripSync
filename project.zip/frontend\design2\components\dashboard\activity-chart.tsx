"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Wifi } from "lucide-react"
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

interface DataPoint {
  time: string
  transactions: number
  alerts: number
  flagged: number
}

// Generate initial data
function generateInitialData(): DataPoint[] {
  const now = new Date()
  return Array.from({ length: 24 }, (_, i) => {
    const hour = new Date(now.getTime() - (23 - i) * 60 * 60 * 1000)
    const hourStr = hour.getHours().toString().padStart(2, "0") + ":00"
    const baseTransactions = 1000 + Math.sin((i / 24) * Math.PI * 2) * 500 + Math.random() * 500
    return {
      time: hourStr,
      transactions: Math.floor(baseTransactions + (i > 8 && i < 20 ? 1500 : 0)),
      alerts: Math.floor(10 + Math.random() * 20),
      flagged: Math.floor(2 + Math.random() * 8),
    }
  })
}

interface ActivityChartProps {
  className?: string
}

export function ActivityChart({ className }: ActivityChartProps) {
  const [data, setData] = useState<DataPoint[]>(generateInitialData())
  const [isLive, setIsLive] = useState(true)

  // Update the last data point in real-time
  useEffect(() => {
    if (!isLive) return

    const interval = setInterval(() => {
      setData(prev => {
        const newData = [...prev]
        const lastIndex = newData.length - 1
        const last = newData[lastIndex]
        
        // Update the current hour with fluctuating values
        newData[lastIndex] = {
          ...last,
          transactions: Math.max(500, last.transactions + Math.floor(Math.random() * 200 - 100)),
          alerts: Math.max(5, last.alerts + Math.floor(Math.random() * 4 - 2)),
          flagged: Math.max(1, last.flagged + Math.floor(Math.random() * 2 - 1)),
        }
        
        return newData
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [isLive])

  const totalTransactions = data.reduce((acc, d) => acc + d.transactions, 0)
  const totalAlerts = data.reduce((acc, d) => acc + d.alerts, 0)
  const totalFlagged = data.reduce((acc, d) => acc + d.flagged, 0)

  return (
    <Card className={`border-border/50 bg-card/50 backdrop-blur-sm ${className}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">Transaction Activity</CardTitle>
            {isLive && (
              <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30 text-xs">
                <span className="relative mr-1 flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-chart-1 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-chart-1" />
                </span>
                <Wifi className="mr-1 h-3 w-3" />
                LIVE
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            Real-time transaction monitoring
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={isLive ? "default" : "outline"} 
            size="sm" 
            className="text-xs"
            onClick={() => setIsLive(true)}
          >
            Live
          </Button>
          <Button 
            variant={!isLive ? "default" : "outline"} 
            size="sm" 
            className="text-xs"
            onClick={() => setIsLive(false)}
          >
            24h
          </Button>
          <Button variant="ghost" size="sm" className="text-xs">
            7 Days
          </Button>
          <Button variant="ghost" size="sm" className="text-xs">
            30 Days
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary badges */}
        <div className="flex flex-wrap gap-3">
          <Badge variant="secondary" className="gap-2 px-3 py-1.5">
            <span className="h-2 w-2 rounded-full bg-primary" />
            <span className="text-muted-foreground">Transactions:</span>
            <span className="font-semibold">{totalTransactions.toLocaleString()}</span>
          </Badge>
          <Badge variant="secondary" className="gap-2 px-3 py-1.5">
            <span className="h-2 w-2 rounded-full bg-chart-3" />
            <span className="text-muted-foreground">Alerts:</span>
            <span className="font-semibold">{totalAlerts}</span>
          </Badge>
          <Badge variant="secondary" className="gap-2 px-3 py-1.5">
            <span className="h-2 w-2 rounded-full bg-destructive" />
            <span className="text-muted-foreground">Flagged:</span>
            <span className="font-semibold">{totalFlagged}</span>
          </Badge>
          <Badge variant="secondary" className="gap-2 px-3 py-1.5">
            <span className="text-muted-foreground">Avg/Hour:</span>
            <span className="font-semibold">{Math.floor(totalTransactions / 24).toLocaleString()}</span>
          </Badge>
        </div>

        {/* Chart */}
        <div className="h-[280px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={data}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="transactionGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.72 0.19 160)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="oklch(0.72 0.19 160)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="alertGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.7 0.22 50)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="oklch(0.7 0.22 50)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 260)" vertical={false} />
              <XAxis
                dataKey="time"
                tick={{ fill: "oklch(0.6 0 0)", fontSize: 12 }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                tick={{ fill: "oklch(0.6 0 0)", fontSize: 12 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.13 0.008 260)",
                  border: "1px solid oklch(0.22 0.01 260)",
                  borderRadius: "8px",
                  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
                }}
                labelStyle={{ color: "oklch(0.95 0 0)", fontWeight: 600 }}
                itemStyle={{ color: "oklch(0.6 0 0)" }}
              />
              <Area
                type="monotone"
                dataKey="transactions"
                stroke="oklch(0.72 0.19 160)"
                strokeWidth={2}
                fill="url(#transactionGradient)"
                name="Transactions"
                animationDuration={500}
              />
              <Area
                type="monotone"
                dataKey="alerts"
                stroke="oklch(0.7 0.22 50)"
                strokeWidth={2}
                fill="url(#alertGradient)"
                name="Alerts"
                animationDuration={500}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
