"use client"

import { useEffect, useRef, useState } from "react"
import { MoreHorizontal, ArrowUpDown, Eye, Flag, ShieldCheck, Wifi, Search } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { type LiveAccount, formatCurrency } from "@/hooks/use-live-data"

interface RiskTableProps {
  accounts?: LiveAccount[]
  isLive?: boolean
}

const riskLevelStyles = {
  critical: {
    badge: "bg-destructive/10 text-destructive border-destructive/30",
    label: "Critical",
  },
  high: {
    badge: "bg-chart-3/10 text-chart-3 border-chart-3/30",
    label: "High",
  },
  medium: {
    badge: "bg-chart-2/10 text-chart-2 border-chart-2/30",
    label: "Medium",
  },
  low: {
    badge: "bg-chart-1/10 text-chart-1 border-chart-1/30",
    label: "Low",
  },
}

// Generate default accounts for initial render
const defaultAccounts: LiveAccount[] = [
  {
    id: "ACC-4521",
    name: "Marcus Chen",
    accountNumber: "****4521",
    pamrsScore: 95,
    riskLevel: "critical",
    balance: 142500,
    lastActivity: "2 min ago",
    flagged: true,
    transactions: 87,
  },
  {
    id: "ACC-7823",
    name: "Sarah Williams",
    accountNumber: "****7823",
    pamrsScore: 87,
    riskLevel: "high",
    balance: 89200,
    lastActivity: "5 min ago",
    flagged: true,
    transactions: 45,
  },
  {
    id: "ACC-3156",
    name: "David Kumar",
    accountNumber: "****3156",
    pamrsScore: 78,
    riskLevel: "high",
    balance: 234100,
    lastActivity: "12 min ago",
    flagged: true,
    transactions: 62,
  },
  {
    id: "ACC-9234",
    name: "Emily Rodriguez",
    accountNumber: "****9234",
    pamrsScore: 65,
    riskLevel: "medium",
    balance: 56800,
    lastActivity: "18 min ago",
    flagged: false,
    transactions: 34,
  },
  {
    id: "ACC-1847",
    name: "James Thompson",
    accountNumber: "****1847",
    pamrsScore: 58,
    riskLevel: "medium",
    balance: 178300,
    lastActivity: "25 min ago",
    flagged: false,
    transactions: 28,
  },
  {
    id: "ACC-5672",
    name: "Lisa Park",
    accountNumber: "****5672",
    pamrsScore: 42,
    riskLevel: "low",
    balance: 34600,
    lastActivity: "32 min ago",
    flagged: false,
    transactions: 15,
  },
]

export function RiskTable({ accounts = defaultAccounts, isLive = false }: RiskTableProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [updatedIds, setUpdatedIds] = useState<Set<string>>(new Set())
  const prevAccountsRef = useRef<Map<string, number>>(new Map())

  // Detect PAMRS score changes
  useEffect(() => {
    const updated = new Set<string>()
    accounts.forEach(acc => {
      const prevScore = prevAccountsRef.current.get(acc.id)
      if (prevScore !== undefined && prevScore !== acc.pamrsScore) {
        updated.add(acc.id)
      }
    })
    
    if (updated.size > 0) {
      setUpdatedIds(updated)
      const timer = setTimeout(() => setUpdatedIds(new Set()), 1000)
      
      // Update ref
      accounts.forEach(acc => {
        prevAccountsRef.current.set(acc.id, acc.pamrsScore)
      })
      
      return () => clearTimeout(timer)
    }
    
    // Initialize ref
    accounts.forEach(acc => {
      prevAccountsRef.current.set(acc.id, acc.pamrsScore)
    })
  }, [accounts])

  const filteredAccounts = accounts
    .filter(acc => 
      acc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.id.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => b.pamrsScore - a.pamrsScore)
  
  const pickBalance = (a: LiveAccount) => a.balance ?? 0
  const pickTxns = (a: LiveAccount) => a.transactionCount ?? a.transactions ?? 0
  const kycBadge = (status?: string) => status === "VERIFIED"
    ? <Badge className="bg-chart-1/10 text-chart-1 border-chart-1/30">✔ Verified</Badge>
    : <Badge className="bg-destructive/10 text-destructive border-destructive/30">✖ Not Verified</Badge>
  const cibilChip = (c?: number) => {
    if (c === undefined || c === null) return <span>—</span>
    const color = c > 750 ? "text-chart-1" : c > 600 ? "text-chart-3" : "text-destructive"
    return <span className={`${color} font-semibold`}>{c}</span>
  }

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader className="flex flex-col gap-4 space-y-0 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">High Risk Accounts</CardTitle>
            {isLive && (
              <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30 text-xs">
                <Wifi className="mr-1 h-3 w-3" />
                LIVE
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            {filteredAccounts.length} accounts sorted by PAMRS score
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search accounts..."
              className="h-9 w-[200px] pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="sm" className="gap-2">
            <ArrowUpDown className="h-4 w-4" />
            Sort
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 hover:bg-transparent">
                <TableHead className="pl-6">Account</TableHead>
                <TableHead>PAMRS Score</TableHead>
                <TableHead>Risk Level</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>KYC</TableHead>
                <TableHead>CIBIL</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Transactions</TableHead>
                <TableHead>Last Activity</TableHead>
                <TableHead className="w-[50px] pr-6"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAccounts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                    No accounts found
                  </TableCell>
                </TableRow>
              ) : (
                filteredAccounts.map((account) => {
                  const riskStyles = riskLevelStyles[account.riskLevel]
                  const isUpdated = updatedIds.has(account.id)
                  const status = account.flagged ? "flagged" : account.pamrsScore >= 60 ? "monitoring" : "cleared"
                  const StatusIcon = status === "flagged" ? Flag : status === "monitoring" ? Eye : ShieldCheck
                  const statusStyle = status === "flagged" 
                    ? "bg-destructive/10 text-destructive" 
                    : status === "monitoring"
                      ? "bg-chart-3/10 text-chart-3"
                      : "bg-chart-1/10 text-chart-1"

                  return (
                    <TableRow
                      key={account.id}
                      className={cn(
                        "group border-border/50 transition-all hover:bg-secondary/30",
                        isUpdated && "bg-primary/5 ring-1 ring-primary/30"
                      )}
                    >
                      <TableCell className="pl-6">
                        <div className="flex flex-col">
                          <span className="font-medium">{account.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {account.id}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-24">
                            <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                              <div
                                className={cn(
                                  "h-full transition-all duration-500",
                                  account.pamrsScore >= 80
                                    ? "bg-destructive"
                                    : account.pamrsScore >= 60
                                      ? "bg-chart-3"
                                      : account.pamrsScore >= 40
                                        ? "bg-chart-2"
                                        : "bg-chart-1"
                                )}
                                style={{ width: `${account.pamrsScore}%` }}
                              />
                            </div>
                          </div>
                          <span
                            className={cn(
                              "min-w-[2ch] font-mono text-sm font-bold transition-all duration-300",
                              account.pamrsScore >= 80
                                ? "text-destructive"
                                : account.pamrsScore >= 60
                                  ? "text-chart-3"
                                  : account.pamrsScore >= 40
                                    ? "text-chart-2"
                                    : "text-chart-1",
                              isUpdated && "scale-110"
                            )}
                          >
                            {account.pamrsScore}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn("font-medium", riskStyles.badge)}>
                          {riskStyles.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{formatCurrency(pickBalance(account))}</TableCell>
                      <TableCell>{kycBadge(account.kycStatus)}</TableCell>
                      <TableCell>{cibilChip(account.cibilScore)}</TableCell>
                      <TableCell>
                        <Badge className={cn("gap-1 font-normal", statusStyle)}>
                          <StatusIcon className="h-3 w-3" />
                          {status.charAt(0).toUpperCase() + status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{pickTxns(account)}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {account.lastActivity}
                      </TableCell>
                      <TableCell className="pr-6">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 opacity-0 transition-opacity group-hover:opacity-100"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>View Details</DropdownMenuItem>
                            <DropdownMenuItem>View Transactions</DropdownMenuItem>
                            <DropdownMenuItem>Mark as Reviewed</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              Freeze Account
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
