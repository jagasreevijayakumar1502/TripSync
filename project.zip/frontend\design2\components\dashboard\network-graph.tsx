"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Maximize2, ZoomIn, ZoomOut, RefreshCcw, Wifi, Pause, Play } from "lucide-react"
import { cn } from "@/lib/utils"
import { type NetworkNode, type NetworkLink } from "@/hooks/use-live-data"

interface NetworkGraphProps {
  nodes?: NetworkNode[]
  links?: NetworkLink[]
  isLive?: boolean
  className?: string
}

interface SimulatedNode extends NetworkNode {
  x: number
  y: number
  vx: number
  vy: number
}

const riskColors = {
  high: "#ef4444",
  medium: "#f59e0b",
  low: "#22c55e",
}

export function NetworkGraph({ nodes = [], links = [], isLive = false, className }: NetworkGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [simulatedNodes, setSimulatedNodes] = useState<SimulatedNode[]>([])
  const [zoom, setZoom] = useState(1)
  const [isPaused, setIsPaused] = useState(false)
  const animationRef = useRef<number>()
  const dimensionsRef = useRef({ width: 0, height: 0 })

  // Initialize simulation when nodes change
  useEffect(() => {
    if (nodes.length === 0) return

    const canvas = canvasRef.current
    if (!canvas) return

    const width = canvas.offsetWidth || 400
    const height = canvas.offsetHeight || 300
    dimensionsRef.current = { width, height }

    // Initialize or update nodes with positions
    setSimulatedNodes(prev => {
      const existingMap = new Map(prev.map(n => [n.id, n]))
      
      return nodes.map((node, i) => {
        const existing = existingMap.get(node.id)
        if (existing) {
          // Update risk level but keep position
          return { ...existing, risk: node.risk, pamrsScore: node.pamrsScore }
        }
        // New node - position in circle
        return {
          ...node,
          x: width / 2 + Math.cos((i * 2 * Math.PI) / nodes.length) * Math.min(width, height) * 0.35,
          y: height / 2 + Math.sin((i * 2 * Math.PI) / nodes.length) * Math.min(width, height) * 0.35,
          vx: 0,
          vy: 0,
        }
      })
    })
  }, [nodes])

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || simulatedNodes.length === 0) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const { width, height } = dimensionsRef.current
    canvas.width = width * 2
    canvas.height = height * 2
    ctx.scale(2, 2)

    const simulate = () => {
      if (!isPaused) {
        const centerX = width / 2
        const centerY = height / 2

        // Apply forces
        simulatedNodes.forEach((node) => {
          // Center gravity
          node.vx += (centerX - node.x) * 0.0008
          node.vy += (centerY - node.y) * 0.0008

          // Repulsion between nodes
          simulatedNodes.forEach((other) => {
            if (node.id !== other.id) {
              const dx = node.x - other.x
              const dy = node.y - other.y
              const dist = Math.sqrt(dx * dx + dy * dy) || 1
              if (dist < 80) {
                const force = ((80 - dist) / dist) * 0.3
                node.vx += dx * force * 0.01
                node.vy += dy * force * 0.01
              }
            }
          })

          // Link attraction
          links.forEach((link) => {
            if (link.source === node.id || link.target === node.id) {
              const other = simulatedNodes.find(
                (n) => n.id === (link.source === node.id ? link.target : link.source)
              )
              if (other) {
                const dx = other.x - node.x
                const dy = other.y - node.y
                node.vx += dx * 0.001
                node.vy += dy * 0.001
              }
            }
          })

          // Apply velocity with damping
          node.vx *= 0.92
          node.vy *= 0.92
          node.x += node.vx
          node.y += node.vy

          // Keep within bounds
          const padding = 40
          node.x = Math.max(padding, Math.min(width - padding, node.x))
          node.y = Math.max(padding, Math.min(height - padding, node.y))
        })
      }

      // Clear and draw
      ctx.clearRect(0, 0, width, height)

      // Draw links with gradient
      links.forEach((link) => {
        const source = simulatedNodes.find((n) => n.id === link.source)
        const target = simulatedNodes.find((n) => n.id === link.target)
        if (source && target) {
          ctx.beginPath()
          ctx.moveTo(source.x, source.y)
          ctx.lineTo(target.x, target.y)
          ctx.strokeStyle = "rgba(100, 116, 139, 0.3)"
          ctx.lineWidth = Math.max(1, link.value * 0.5)
          ctx.stroke()

          // Animated particles on links for live mode
          if (isLive && !isPaused) {
            const t = (Date.now() % 2000) / 2000
            const px = source.x + (target.x - source.x) * t
            const py = source.y + (target.y - source.y) * t
            ctx.beginPath()
            ctx.arc(px, py, 2, 0, Math.PI * 2)
            ctx.fillStyle = "rgba(45, 212, 191, 0.8)"
            ctx.fill()
          }
        }
      })

      // Draw nodes
      simulatedNodes.forEach((node) => {
        const color = riskColors[node.risk]
        const radius = node.risk === "high" ? 14 : node.risk === "medium" ? 12 : 10

        // Glow effect for high risk nodes
        if (node.risk === "high") {
          const gradient = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, radius * 2)
          gradient.addColorStop(0, `${color}40`)
          gradient.addColorStop(1, `${color}00`)
          ctx.beginPath()
          ctx.arc(node.x, node.y, radius * 2, 0, Math.PI * 2)
          ctx.fillStyle = gradient
          ctx.fill()
        }

        // Node circle
        ctx.beginPath()
        ctx.arc(node.x, node.y, radius, 0, Math.PI * 2)
        ctx.fillStyle = color
        ctx.fill()

        // Node border
        ctx.beginPath()
        ctx.arc(node.x, node.y, radius, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(255, 255, 255, 0.2)"
        ctx.lineWidth = 2
        ctx.stroke()

        // Label
        ctx.font = "10px Inter, sans-serif"
        ctx.fillStyle = "rgba(203, 213, 225, 0.8)"
        ctx.textAlign = "center"
        ctx.fillText(node.id, node.x, node.y + radius + 14)
      })

      animationRef.current = requestAnimationFrame(simulate)
    }

    simulate()

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [simulatedNodes, links, zoom, isPaused, isLive])

  const handleRefresh = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const { width, height } = dimensionsRef.current
    setSimulatedNodes(prev => prev.map((node, i) => ({
      ...node,
      x: width / 2 + Math.cos((i * 2 * Math.PI) / prev.length) * Math.min(width, height) * 0.35,
      y: height / 2 + Math.sin((i * 2 * Math.PI) / prev.length) * Math.min(width, height) * 0.35,
      vx: 0,
      vy: 0,
    })))
  }, [])

  const stats = {
    total: nodes.length,
    high: nodes.filter((n) => n.risk === "high").length,
    medium: nodes.filter((n) => n.risk === "medium").length,
    low: nodes.filter((n) => n.risk === "low").length,
    edges: links.length,
  }

  return (
    <Card className={cn("flex h-full flex-col border-border/50 bg-card/50 backdrop-blur-sm", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">Network Analysis</CardTitle>
            {isLive && (
              <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30 text-xs">
                <Wifi className="mr-1 h-3 w-3" />
                LIVE
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            Account relationship graph
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            className="h-8 w-8" 
            onClick={() => setIsPaused(!isPaused)}
            title={isPaused ? "Resume" : "Pause"}
          >
            {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom((z) => Math.max(0.5, z - 0.1))}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom((z) => Math.min(2, z + 0.1))}>
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={handleRefresh}>
            <RefreshCcw className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8">
            <Maximize2 className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-4 pt-0">
        {/* Stats row */}
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-1.5">
            <span className="text-xs text-muted-foreground">Nodes:</span>
            <span className="text-sm font-semibold">{stats.total}</span>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-1.5">
            <span className="text-xs text-muted-foreground">Edges:</span>
            <span className="text-sm font-semibold">{stats.edges}</span>
          </div>
          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/30">
            <span className="mr-1.5 h-2 w-2 rounded-full bg-destructive" />
            {stats.high} High
          </Badge>
          <Badge variant="outline" className="bg-chart-3/10 text-chart-3 border-chart-3/30">
            <span className="mr-1.5 h-2 w-2 rounded-full bg-chart-3" />
            {stats.medium} Medium
          </Badge>
          <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30">
            <span className="mr-1.5 h-2 w-2 rounded-full bg-chart-1" />
            {stats.low} Low
          </Badge>
        </div>

        {/* Canvas */}
        <div className="relative flex-1 overflow-hidden rounded-xl border border-border/50 bg-background/50 min-h-[300px]">
          {nodes.length === 0 ? (
            <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
              Waiting for live data...
            </div>
          ) : (
            <canvas
              ref={canvasRef}
              className="h-full w-full"
              style={{ transform: `scale(${zoom})`, transformOrigin: "center" }}
            />
          )}
          {/* Legend */}
          <div className="absolute bottom-3 left-3 flex flex-col gap-1.5 rounded-lg bg-card/80 p-2 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-[#ef4444]" />
              <span className="text-xs text-muted-foreground">High Risk</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-[#f59e0b]" />
              <span className="text-xs text-muted-foreground">Medium Risk</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-[#22c55e]" />
              <span className="text-xs text-muted-foreground">Low Risk</span>
            </div>
          </div>
          {/* Live indicator */}
          {isLive && !isPaused && (
            <div className="absolute right-3 top-3 flex items-center gap-2 rounded-lg bg-card/80 px-2 py-1 backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-chart-1 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-chart-1" />
              </span>
              <span className="text-xs text-chart-1">Live</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
