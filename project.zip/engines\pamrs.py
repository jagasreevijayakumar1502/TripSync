"""
PAMRS (Pre-Activation Mule Risk Scoring System)
Phase 2: AML Pre-Activation Risk Assessment Engine

Assesses account risk at creation time before any transactions occur.
Uses multiple risk factors to prevent mule account creation.
"""

from typing import Dict, Any


class PAMRSEngine:
    """
    Pre-Activation Mule Risk Scoring Engine

    Evaluates account risk at creation time using multiple factors:
    - Device sharing patterns
    - Geographic risk (pincode-based)
    - Network connectivity risk
    - Behavioral risk (account age)

    Weights: Device(35%) + Location(25%) + Network(20%) + Behavior(20%)
    """

    def __init__(self, graph_engine):
        """
        Initialize PAMRS Engine with shared GraphEngine instance.

        Args:
            graph_engine: The singleton GraphEngine instance (do not create new)
        """
        self.graph_engine = graph_engine

        # Predefined risky pincodes (can be moved to config later)
        self.RISKY_PINCODES = ["600001", "500081", "560001"]

    def device_risk(self, account: Dict[str, Any]) -> float:
        """
        Assess device sharing risk.

        Higher risk if device is shared across multiple accounts,
        indicating potential mule account network.

        Args:
            account: Account dict with device information

        Returns:
            Risk score 0.0-1.0 (higher = more suspicious)
        """
        # Handle different field name formats
        device_id = account.get('device_id') or account.get('Device_ID')
        if not device_id:
            return 0.0  # No device info = neutral risk

        # Get device clusters from graph engine
        device_clusters = self.graph_engine.detect_device_clusters()

        # Check if this device is shared
        if device_id in device_clusters:
            accounts_on_device = len(device_clusters[device_id])

            # Normalize: 1 account = 0 risk, 2+ accounts = increasing risk
            if accounts_on_device <= 1:
                return 0.0
            elif accounts_on_device == 2:
                return 0.3
            elif accounts_on_device == 3:
                return 0.6
            else:  # 4+ accounts
                return min(1.0, 0.6 + (accounts_on_device - 3) * 0.1)

        return 0.0  # Device not found in clusters

    def location_risk(self, account: Dict[str, Any]) -> float:
        """
        Assess geographic risk based on pincode.

        Certain pincodes are pre-identified as high-risk areas.

        Args:
            account: Account dict with pincode information

        Returns:
            Risk score 0.0-1.0 (higher = more suspicious)
        """
        # Handle different field name formats
        pincode = account.get('pincode') or account.get('Pincode')
        if not pincode:
            # For existing accounts without pincode, use country-based risk
            country = account.get('Country')
            if country and country.upper() in ['INDIA', 'CHINA', 'RUSSIA']:
                return 0.4  # Moderate risk for certain countries
            return 0.2  # Unknown location = moderate risk

        # Convert to string if needed
        pincode = str(pincode)

        # Check if pincode is in risky list
        if pincode in self.RISKY_PINCODES:
            return 0.9  # High risk area
        else:
            return 0.1  # Normal area

    def network_risk(self, account: Dict[str, Any]) -> float:
        """
        Assess network connectivity risk.

        Uses existing graph analysis from Phase 1 to check
        if account is connected to suspicious networks.

        Args:
            account: Account dict with account ID

        Returns:
            Risk score 0.0-1.0 (higher = more suspicious)
        """
        # Handle different field name formats
        account_id = account.get('account_id') or account.get('Account_ID')
        if not account_id:
            return 0.0  # No account ID = no network risk

        # Use existing network risk calculation
        return self.graph_engine.calculate_network_risk(account_id)

    def behavior_risk(self, account: Dict[str, Any]) -> float:
        """
        Assess behavioral risk based on account age.

        Very new accounts are higher risk for mule activity.

        Args:
            account: Account dict with age information

        Returns:
            Risk score 0.0-1.0 (higher = more suspicious)
        """
        from datetime import datetime

        # Handle different field name formats
        age_days = account.get('account_age_days')

        if age_days is None:
            # Calculate age from creation date
            creation_date_str = account.get('Account_Creation_Date')
            if creation_date_str:
                try:
                    # Parse creation date
                    if isinstance(creation_date_str, str):
                        creation_date = datetime.strptime(creation_date_str, '%Y-%m-%d')
                    else:
                        creation_date = creation_date_str

                    # Calculate age in days
                    today = datetime.now()
                    age_days = (today - creation_date).days
                except (ValueError, TypeError):
                    age_days = 30  # Default to 30 days if parsing fails
            else:
                age_days = 30  # Default if no date available

        age_days = int(age_days)

        if age_days < 1:
            return 0.9  # Brand new account = very high risk
        elif age_days < 7:
            return 0.6  # Very new account = high risk
        elif age_days < 30:
            return 0.3  # Recent account = moderate risk
        else:
            return 0.1  # Established account = low risk

    def calculate_pamrs(self, account: Dict[str, Any]) -> float:
        """
        Calculate final PAMRS score using weighted formula.

        Formula:
        score = 0.35*device + 0.25*location + 0.20*network + 0.20*behavior

        Args:
            account: Account data dictionary

        Returns:
            PAMRS score 0-100 (rounded to 2 decimals)
        """
        # Calculate component risks (normalized 0.0-1.0)
        device = self.device_risk(account)
        location = self.location_risk(account)
        network = self.network_risk(account)
        behavior = self.behavior_risk(account)

        # Store component scores for explain() method
        self._last_components = {
            "device_risk": device,
            "location_risk": location,
            "network_risk": network,
            "behavior_risk": behavior
        }

        # Weighted formula (all components already 0.0-1.0)
        raw_score = (
            0.35 * device +
            0.25 * location +
            0.20 * network +
            0.20 * behavior
        )

        # Scale to 0-100 and round
        final_score = round(raw_score * 100, 2)

        return final_score

    def explain(self, account: Dict[str, Any]) -> Dict[str, float]:
        """
        Provide explainability breakdown of PAMRS components.

        Uses cached component scores from last calculate_pamrs() call,
        or recalculates if not available.

        Args:
            account: Account data dictionary

        Returns:
            Dict with individual risk component scores (0.0-1.0)
        """
        # Use cached components if available (from last calculate_pamrs call)
        if hasattr(self, '_last_components') and self._last_components is not None:
            return self._last_components.copy()

        # Fallback: recalculate if no cache available
        return {
            "device_risk": self.device_risk(account),
            "location_risk": self.location_risk(account),
            "network_risk": self.network_risk(account),
            "behavior_risk": self.behavior_risk(account)
        }

    def get_risk_level(self, pamrs_score: float) -> str:
        """
        Convert PAMRS score to risk level.

        Args:
            pamrs_score: PAMRS score (0-100)

        Returns:
            Risk level: "LOW", "MEDIUM", "HIGH"
        """
        if pamrs_score > 70:
            return "HIGH"
        elif pamrs_score > 40:
            return "MEDIUM"
        else:
            return "LOW"

    def get_recommended_action(self, pamrs_score: float) -> str:
        """
        Get recommended action based on PAMRS score.

        Args:
            pamrs_score: PAMRS score (0-100)

        Returns:
            Recommended action string
        """
        if pamrs_score > 80:
            return "PREVENTIVE_FREEZE"
        elif pamrs_score > 60:
            return "MONITOR"
        else:
            return "ALLOW"

    def risk_label(self, pamrs_score: float) -> str:
        """Alias for risk level naming used by live engine."""
        return self.get_risk_level(pamrs_score)
