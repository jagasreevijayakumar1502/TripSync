"""
Velocity Monitoring Engine
Detects unusually high transaction frequency and dormant account reactivation.
"""
import pandas as pd
from datetime import timedelta


class VelocityEngine:
    def __init__(self):
        self.hourly_threshold = 5       # max normal txns per hour
        self.daily_threshold = 20       # max normal txns per day
        self.dormant_days = 90          # days of inactivity to consider dormant
        self.burst_threshold = 3        # txns in 1 hour after dormancy = suspicious

    def evaluate(self, account_id, transactions_df, accounts_df):
        """
        Evaluate velocity risk for a given account.
        Returns risk score [0-25] and details.
        """
        acct_txns = transactions_df[
            (transactions_df["Sender_Account_ID"] == account_id) |
            (transactions_df["Receiver_Account_ID"] == account_id)
        ].copy()

        if acct_txns.empty:
            return {"score": 0, "details": [], "flags": []}

        acct_txns["Timestamp"] = pd.to_datetime(acct_txns["Timestamp"])
        acct_txns = acct_txns.sort_values("Timestamp")

        risk_score = 0
        details = []
        flags = []

        # Rule 1: Transactions per hour spike
        acct_txns["hour_bucket"] = acct_txns["Timestamp"].dt.floor("h")
        hourly_counts = acct_txns.groupby("hour_bucket").size()
        max_hourly = hourly_counts.max()

        if max_hourly > self.hourly_threshold:
            penalty = min(10, (max_hourly - self.hourly_threshold) * 2)
            risk_score += penalty
            peak_hour = hourly_counts.idxmax()
            flags.append(f"VELOCITY SPIKE: {max_hourly} txns in 1 hour (threshold: {self.hourly_threshold})")
            details.append({
                "rule": "Hourly velocity spike",
                "max_hourly": int(max_hourly),
                "peak_hour": str(peak_hour),
                "threshold": self.hourly_threshold,
                "penalty": penalty
            })

        # Rule 2: Daily transaction count
        acct_txns["day_bucket"] = acct_txns["Timestamp"].dt.date
        daily_counts = acct_txns.groupby("day_bucket").size()
        max_daily = daily_counts.max()

        if max_daily > self.daily_threshold:
            penalty = min(8, (max_daily - self.daily_threshold))
            risk_score += penalty
            flags.append(f"HIGH DAILY VOLUME: {max_daily} txns in single day (threshold: {self.daily_threshold})")
            details.append({
                "rule": "Daily volume spike",
                "max_daily": int(max_daily),
                "threshold": self.daily_threshold,
                "penalty": penalty
            })

        # Rule 3: Historical baseline comparison
        acct_info = accounts_df[accounts_df["Account_ID"] == account_id]
        if not acct_info.empty:
            avg_monthly = acct_info.iloc[0].get("Avg_Monthly_Transaction_Value", 0)
            total_value = acct_txns[acct_txns["Sender_Account_ID"] == account_id]["Amount"].sum()
            # Compare current period total vs avg monthly
            if avg_monthly > 0 and total_value > avg_monthly * 3:
                ratio = total_value / avg_monthly
                penalty = min(7, int(ratio))
                risk_score += penalty
                flags.append(
                    f"BASELINE BREACH: Current volume ₹{total_value:,.0f} is {ratio:.1f}x "
                    f"avg monthly ₹{avg_monthly:,.0f}"
                )
                details.append({
                    "rule": "Historical baseline breach",
                    "current_volume": total_value,
                    "avg_monthly": avg_monthly,
                    "ratio": round(ratio, 2),
                    "penalty": penalty
                })

        # Rule 4: Dormant account reactivation
        if not acct_info.empty:
            acct_status = acct_info.iloc[0].get("Account_Status", "Active")
            if acct_status == "Dormant" and len(acct_txns) >= self.burst_threshold:
                penalty = 10
                risk_score += penalty
                flags.append(
                    f"DORMANT REACTIVATION: {len(acct_txns)} txns on dormant account"
                )
                details.append({
                    "rule": "Dormant account reactivation",
                    "txn_count": len(acct_txns),
                    "penalty": penalty
                })

        return {
            "score": min(risk_score, 25),
            "details": details,
            "flags": flags
        }
