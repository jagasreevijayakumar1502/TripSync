"use client"

import { useEffect, useState } from "react"
import { Activity, Cpu, Database, Wifi, Signal } from "lucide-react"
import { cn } from "@/lib/utils"

interface StreamIndicator {
  id: string
  name: string
  status: "online" | "offline" | "syncing"
  latency: number
  icon: React.ElementType
}

interface StreamStatusProps {
  isConnected?: boolean
}

const statusStyles = {
  online: {
    dot: "bg-chart-1",
    text: "text-chart-1",
    label: "Online",
  },
  offline: {
    dot: "bg-destructive",
    text: "text-destructive",
    label: "Offline",
  },
  syncing: {
    dot: "bg-chart-3 animate-pulse",
    text: "text-chart-3",
    label: "Syncing",
  },
}

export function StreamStatus({ isConnected = false }: StreamStatusProps) {
  const [indicators, setIndicators] = useState<StreamIndicator[]>([
    { id: "api", name: "API", status: "syncing", latency: 0, icon: Activity },
    { id: "websocket", name: "WebSocket", status: "syncing", latency: 0, icon: Wifi },
    { id: "database", name: "Database", status: "syncing", latency: 0, icon: Database },
    { id: "ml-engine", name: "ML Engine", status: "syncing", latency: 0, icon: Cpu },
  ])

  const [lastUpdateTime, setLastUpdateTime] = useState<string>("")
  const [dataRate, setDataRate] = useState(0)
  const [isMounted, setIsMounted] = useState(false)

  // Handle client-side mounting to avoid hydration mismatch
  useEffect(() => {
    setIsMounted(true)
    setLastUpdateTime(new Date().toLocaleTimeString())
  }, [])

  // Simulate realistic latency fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setIndicators(prev => prev.map(indicator => {
        const baseLatency = indicator.id === "ml-engine" ? 120 : indicator.id === "api" ? 20 : indicator.id === "database" ? 8 : 10
        const fluctuation = Math.floor(Math.random() * 20) - 10
        const newLatency = Math.max(1, baseLatency + fluctuation)
        
        // Determine status based on connection and latency
        let status: "online" | "offline" | "syncing" = "offline"
        if (isConnected) {
          status = newLatency > 200 ? "syncing" : "online"
        }
        
        return {
          ...indicator,
          status,
          latency: newLatency,
        }
      }))
      
      setLastUpdateTime(new Date().toLocaleTimeString())
      setDataRate(Math.floor(Math.random() * 500) + 800) // 800-1300 events/sec
    }, 2000)

    return () => clearInterval(interval)
  }, [isConnected])

  return (
    <footer className="border-t border-border/50 bg-card/30 backdrop-blur-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 px-4 py-3 md:px-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Signal className={cn(
              "h-4 w-4",
              isConnected ? "text-chart-1" : "text-destructive"
            )} />
            <span className="text-xs font-medium text-muted-foreground">
              System Status:
            </span>
            <span className={cn(
              "text-xs font-semibold",
              isConnected ? "text-chart-1" : "text-destructive"
            )}>
              {isConnected ? "Connected" : "Disconnected"}
            </span>
          </div>
          {isMounted && (
            <>
              <span className="hidden text-xs text-muted-foreground md:inline">|</span>
              <span className="hidden text-xs text-muted-foreground md:inline">
                Last sync: {lastUpdateTime}
              </span>
            </>
          )}
          {isConnected && (
            <>
              <span className="hidden text-xs text-muted-foreground md:inline">|</span>
              <span className="hidden text-xs text-muted-foreground md:inline">
                <span className="text-chart-1 font-medium">{dataRate}</span> events/sec
              </span>
            </>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {indicators.map((indicator) => {
            const Icon = indicator.icon
            const styles = statusStyles[indicator.status]
            return (
              <div
                key={indicator.id}
                className="flex items-center gap-2 rounded-lg bg-secondary/30 px-3 py-1.5 transition-all duration-300"
              >
                <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-xs font-medium">{indicator.name}</span>
                <span className="relative flex h-2 w-2">
                  {indicator.status === "online" && (
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-chart-1 opacity-75" />
                  )}
                  <span className={cn("relative inline-flex h-2 w-2 rounded-full", styles.dot)} />
                </span>
                <span className={cn(
                  "text-xs tabular-nums",
                  indicator.status === "online" 
                    ? "text-muted-foreground" 
                    : indicator.status === "syncing"
                      ? "text-chart-3"
                      : "text-destructive"
                )}>
                  {indicator.latency}ms
                </span>
              </div>
            )
          })}
        </div>
      </div>
    </footer>
  )
}
