"""
Weighted Risk Aggregator (Secret Reveal #2)
Mathematical scoring engine computing real-time risk [0-100].
Signals: Velocity, Geographic Entropy, Entity Proximity.
Auto-gates accounts scoring >75.
"""
import os
import math
import hashlib
import pandas as pd
import networkx as nx
from collections import Counter
from datetime import timedelta

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# Known blacklisted account IDs (from high-risk scenarios)
BLACKLISTED_NODES = set()


class WeightedRiskAggregator:
    def __init__(self):
        self.velocity_weight = 0.35
        self.geo_entropy_weight = 0.35
        self.entity_proximity_weight = 0.30
        self.gate_threshold = 75
        self.gate_limit = 5000  # INR
        self.transactions_df = None
        self.weighted_df = None
        self.accounts_df = None
        self.graph = None
        self._loaded = False

    @staticmethod
    def _generate_cibil(account_id: str) -> int:
        """Deterministically derive a pseudo CIBIL score (500-900)."""
        import hashlib
        base = int(hashlib.sha256(account_id.encode()).hexdigest(), 16)
        return 500 + (base % 401)

    def load_data(self):
        """Load datasets."""
        self.transactions_df = pd.read_excel(os.path.join(DATA_DIR, "regshield_transaction_log.xlsx"))
        self.weighted_df = pd.read_excel(os.path.join(DATA_DIR, "weighted_risk_dataset.xlsx"))
        self.accounts_df = pd.read_excel(os.path.join(DATA_DIR, "regshield_account_master.xlsx"))

        # Ensure CIBIL score exists for UI/alert enrichment
        if "CIBIL_Score" not in self.accounts_df.columns:
            self.accounts_df["CIBIL_Score"] = self.accounts_df["Account_ID"].apply(self._generate_cibil)
        else:
            self.accounts_df["CIBIL_Score"] = self.accounts_df.apply(
                lambda row: row["CIBIL_Score"]
                if pd.notnull(row["CIBIL_Score"])
                else self._generate_cibil(str(row.get("Account_ID", ""))),
                axis=1
            )

        # Build transaction graph for entity proximity
        self.graph = nx.DiGraph()
        for _, txn in self.transactions_df.iterrows():
            self.graph.add_edge(txn["Sender_Account_ID"], txn["Receiver_Account_ID"])

        # Identify blacklisted nodes (high-risk accounts from dataset)
        global BLACKLISTED_NODES
        hr_accounts = self.accounts_df[
            (self.accounts_df["Risk_Category"] == "High") &
            (self.accounts_df["Country"].isin([
                "Iran", "North Korea", "Myanmar", "Syria", "Afghanistan"
            ]))
        ]
        BLACKLISTED_NODES = set(hr_accounts["Account_ID"].tolist())

        # Enrich with deterministic balance / txn count / KYC / CIBIL
        def _rand_from_hash(key: str, low: int, high: int):
            base = int(hashlib.sha256(key.encode()).hexdigest(), 16)
            return low + (base % (high - low + 1))

        if "Balance" not in self.accounts_df.columns or self.accounts_df["Balance"].isnull().any():
            balances = []
            txn_counts = []
            cibil_scores = []
            kyc_statuses = []
            for _, acct in self.accounts_df.iterrows():
                aid = str(acct.get("Account_ID"))
                balances.append(_rand_from_hash(f"bal-{aid}", 1000, 1_000_000))
                txn_counts.append(_rand_from_hash(f"txn-{aid}", 1, 200))
                if str(acct.get("KYC_Status", "pending")).lower() in ["complete", "verified"]:
                    kyc_statuses.append("VERIFIED")
                    cibil_scores.append(_rand_from_hash(f"cibil-{aid}", 650, 900))
                else:
                    kyc_statuses.append("NOT_VERIFIED")
                    cibil_scores.append(_rand_from_hash(f"cibil-{aid}", 300, 650))
            self.accounts_df["Balance"] = balances
            self.accounts_df["Total_Transactions"] = txn_counts
            self.accounts_df["CIBIL_Score"] = cibil_scores
            self.accounts_df["KYC_Status"] = kyc_statuses

        self._loaded = True

    def _compute_velocity_signal(self, account_id):
        """
        Velocity Signal: transactions per hour.
        Normalized to [0-100].
        """
        acct_txns = self.transactions_df[
            (self.transactions_df["Sender_Account_ID"] == account_id) |
            (self.transactions_df["Receiver_Account_ID"] == account_id)
        ].copy()

        if acct_txns.empty:
            return 0

        acct_txns["Timestamp"] = pd.to_datetime(acct_txns["Timestamp"])
        acct_txns["hour_bucket"] = acct_txns["Timestamp"].dt.floor("h")
        hourly_counts = acct_txns.groupby("hour_bucket").size()

        if hourly_counts.empty:
            return 0

        max_per_hour = hourly_counts.max()
        avg_per_hour = hourly_counts.mean()

        # Normalize: 1 txn/hr = 0, 10+ txn/hr = 100
        score = min(100, (max_per_hour / 10) * 100)

        # Spike factor: how much does peak deviate from average
        if avg_per_hour > 0:
            spike_factor = max_per_hour / avg_per_hour
            score = min(100, score * (1 + (spike_factor - 1) * 0.3))

        return round(score, 2)

    def _compute_geographic_entropy(self, account_id):
        """
        Geographic Entropy: distance between origin IPs/locations.
        High entropy = transactions from many distant locations = suspicious.
        Normalized to [0-100].
        """
        acct_records = self.weighted_df[self.weighted_df["Account_ID"] == account_id]

        if acct_records.empty or len(acct_records) < 2:
            return 0

        lats = acct_records["Latitude"].tolist()
        lons = acct_records["Longitude"].tolist()

        # Calculate pairwise distances (Haversine simplified)
        distances = []
        for i in range(len(lats)):
            for j in range(i + 1, min(len(lats), i + 10)):
                lat1, lon1 = math.radians(lats[i]), math.radians(lons[i])
                lat2, lon2 = math.radians(lats[j]), math.radians(lons[j])
                dlat = lat2 - lat1
                dlon = lon2 - lon1
                a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
                c = 2 * math.asin(min(1, math.sqrt(a)))
                dist_km = 6371 * c
                distances.append(dist_km)

        if not distances:
            return 0

        avg_distance = sum(distances) / len(distances)
        max_distance = max(distances)

        # Count unique countries
        unique_countries = acct_records["Country"].nunique()

        # Check VPN usage
        vpn_ratio = acct_records["Is_VPN"].sum() / len(acct_records) if len(acct_records) > 0 else 0

        # Entropy-based scoring
        # > 5000km avg distance = very suspicious
        distance_score = min(60, (avg_distance / 5000) * 60)
        country_score = min(25, unique_countries * 8)
        vpn_score = vpn_ratio * 15

        total = distance_score + country_score + vpn_score
        return round(min(100, total), 2)

    def _compute_entity_proximity(self, account_id):
        """
        Entity Proximity: minimum hops from a blacklisted node.
        Fewer hops = higher risk.
        Normalized to [0-100].
        """
        if not self.graph.has_node(account_id):
            return 0

        if account_id in BLACKLISTED_NODES:
            return 100

        min_hops = float('inf')
        for bl_node in BLACKLISTED_NODES:
            if not self.graph.has_node(bl_node):
                continue
            try:
                # Check both directions
                try:
                    path_len = nx.shortest_path_length(self.graph, account_id, bl_node)
                    min_hops = min(min_hops, path_len)
                except nx.NetworkXNoPath:
                    pass
                try:
                    path_len = nx.shortest_path_length(self.graph, bl_node, account_id)
                    min_hops = min(min_hops, path_len)
                except nx.NetworkXNoPath:
                    pass
            except Exception:
                continue

        if min_hops == float('inf'):
            return 0

        # Score: 1 hop = 100, 2 hops = 80, 3 = 60, 4 = 40, 5 = 20, 6+ = 10
        if min_hops <= 1:
            return 100
        elif min_hops == 2:
            return 80
        elif min_hops == 3:
            return 60
        elif min_hops == 4:
            return 40
        elif min_hops == 5:
            return 20
        else:
            return 10

    def evaluate_account(self, account_id):
        """Compute weighted risk score for a single account."""
        if not self._loaded:
            self.load_data()

        velocity = self._compute_velocity_signal(account_id)
        geo_entropy = self._compute_geographic_entropy(account_id)
        entity_proximity = self._compute_entity_proximity(account_id)

        weighted_score = (
            velocity * self.velocity_weight +
            geo_entropy * self.geo_entropy_weight +
            entity_proximity * self.entity_proximity_weight
        )
        weighted_score = round(min(100, weighted_score), 2)

        is_gated = weighted_score > self.gate_threshold

        return {
            "account_id": account_id,
            "velocity_signal": velocity,
            "geographic_entropy": geo_entropy,
            "entity_proximity": entity_proximity,
            "weighted_risk_score": weighted_score,
            "is_gated": is_gated,
            "gate_limit": self.gate_limit if is_gated else None,
            "gate_reason": f"Score {weighted_score} > threshold {self.gate_threshold}" if is_gated else None
        }

    def evaluate_all(self):
        """Evaluate all accounts."""
        if not self._loaded:
            self.load_data()

        results = []
        for _, acct in self.accounts_df.iterrows():
            result = self.evaluate_account(acct["Account_ID"])
            results.append(result)

        return results
