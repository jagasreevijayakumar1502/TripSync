"use client"

import { useEffect, useRef, useState } from "react"
import { AlertTriangle, Clock, ChevronRight, ExternalLink, Wifi } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import { type LiveAlert, getTimeAgo } from "@/hooks/use-live-data"

interface AlertsPanelProps {
  alerts?: LiveAlert[]
  isLive?: boolean
}

const levelStyles = {
  critical: {
    badge: "bg-destructive/10 text-destructive border-destructive/30",
    dot: "bg-destructive",
    label: "Critical",
    ring: "ring-destructive/30",
  },
  high: {
    badge: "bg-chart-3/10 text-chart-3 border-chart-3/30",
    dot: "bg-chart-3",
    label: "High",
    ring: "ring-chart-3/30",
  },
  medium: {
    badge: "bg-chart-2/10 text-chart-2 border-chart-2/30",
    dot: "bg-chart-2",
    label: "Medium",
    ring: "ring-chart-2/30",
  },
  low: {
    badge: "bg-muted text-muted-foreground border-border",
    dot: "bg-muted-foreground",
    label: "Low",
    ring: "ring-muted/30",
  },
}

export function AlertsPanel({ alerts = [], isLive = false }: AlertsPanelProps) {
  const [newAlertIds, setNewAlertIds] = useState<Set<string>>(new Set())
  const prevAlertsRef = useRef<LiveAlert[]>([])
  const scrollRef = useRef<HTMLDivElement>(null)

  // Detect new alerts and trigger animation
  useEffect(() => {
    if (prevAlertsRef.current.length > 0) {
      const prevIds = new Set(prevAlertsRef.current.map(a => a.id))
      const newIds = alerts.filter(a => !prevIds.has(a.id)).map(a => a.id)
      
      if (newIds.length > 0) {
        setNewAlertIds(new Set(newIds))
        // Clear animation after 2 seconds
        const timer = setTimeout(() => setNewAlertIds(new Set()), 2000)
        return () => clearTimeout(timer)
      }
    }
    prevAlertsRef.current = alerts
  }, [alerts])

  const sortedAlerts = [...alerts].sort((a, b) => b.riskScore - a.riskScore)

  return (
    <Card className="flex h-full flex-col border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            {isLive && (
              <span className="absolute -right-1 -top-1 flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
                <span className="relative inline-flex h-3 w-3 rounded-full bg-destructive" />
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg">Active Alerts</CardTitle>
              {isLive && (
                <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30 text-xs">
                  <Wifi className="mr-1 h-3 w-3" />
                  LIVE
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              {alerts.length} alerts requiring attention
            </p>
          </div>
        </div>
        <Button variant="ghost" size="sm" className="gap-1 text-primary">
          View All
          <ExternalLink className="h-3.5 w-3.5" />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <ScrollArea className="h-[400px] px-6 pb-6" ref={scrollRef}>
          <div className="space-y-3">
            {sortedAlerts.length === 0 ? (
              <div className="flex h-32 items-center justify-center text-muted-foreground">
                No active alerts
              </div>
            ) : (
              sortedAlerts.map((alert) => {
                const styles = levelStyles[alert.level]
                const isNew = newAlertIds.has(alert.id)
                
                return (
                  <div
                    key={alert.id}
                    className={cn(
                      "group cursor-pointer rounded-xl border border-border/50 bg-secondary/30 p-4 transition-all duration-300 hover:border-primary/30 hover:bg-secondary/50",
                      isNew && "animate-pulse ring-2",
                      isNew && styles.ring
                    )}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge
                            variant="outline"
                            className={cn("font-medium", styles.badge)}
                          >
                            <span className={cn("mr-1.5 h-1.5 w-1.5 rounded-full", styles.dot)} />
                            {styles.label}
                          </Badge>
                          <span className="text-sm font-semibold text-foreground">
                            {alert.accountId}
                          </span>
                          <Badge variant="secondary" className="font-normal">
                            {alert.type}
                          </Badge>
                          {isNew && (
                            <Badge className="bg-primary text-primary-foreground text-xs">
                              NEW
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {alert.description}
                        </p>
                        {alert.action && (
                          <p className="text-xs text-primary font-medium">
                            Action: {alert.action}
                          </p>
                        )}
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {alert.timestamp instanceof Date ? getTimeAgo(alert.timestamp) : alert.timestamp}
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="font-medium">Risk Score:</span>
                            <span
                              className={cn(
                                "font-bold",
                                alert.riskScore >= 80
                                  ? "text-destructive"
                                  : alert.riskScore >= 60
                                    ? "text-chart-3"
                                    : "text-chart-2"
                              )}
                            >
                              {alert.riskScore}
                            </span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground transition-transform duration-200 group-hover:translate-x-1 group-hover:text-primary" />
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
