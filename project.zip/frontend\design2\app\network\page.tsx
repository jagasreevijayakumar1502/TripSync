"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { 
  ZoomIn,
  ZoomOut,
  Maximize2,
  RefreshCw,
  Filter,
  Download,
  Play,
  Pause,
  Settings2,
  Users,
  Link2,
  AlertTriangle,
  Eye,
} from "lucide-react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

interface NetworkNode {
  id: string
  x: number
  y: number
  vx: number
  vy: number
  type: "account" | "transaction" | "entity"
  risk: number
  label: string
  connections: number
}

interface NetworkLink {
  source: string
  target: string
  strength: number
  type: "transfer" | "relationship" | "suspicious"
}

const generateNetworkData = (nodeCount: number = 50) => {
  const nodes: NetworkNode[] = Array.from({ length: nodeCount }, (_, i) => ({
    id: `node-${i}`,
    x: Math.random() * 800,
    y: Math.random() * 600,
    vx: 0,
    vy: 0,
    type: ["account", "transaction", "entity"][Math.floor(Math.random() * 3)] as NetworkNode["type"],
    risk: Math.floor(Math.random() * 100),
    label: `${["ACC", "TXN", "ENT"][Math.floor(Math.random() * 3)]}-${String(Math.floor(Math.random() * 10000)).padStart(4, "0")}`,
    connections: 0,
  }))

  const links: NetworkLink[] = []
  const linkTypes: NetworkLink["type"][] = ["transfer", "relationship", "suspicious"]
  
  // Create connections
  for (let i = 0; i < nodeCount * 1.5; i++) {
    const source = Math.floor(Math.random() * nodeCount)
    const target = Math.floor(Math.random() * nodeCount)
    if (source !== target) {
      links.push({
        source: `node-${source}`,
        target: `node-${target}`,
        strength: Math.random() * 0.5 + 0.1,
        type: linkTypes[Math.floor(Math.random() * linkTypes.length)],
      })
      nodes[source].connections++
      nodes[target].connections++
    }
  }

  return { nodes, links }
}

export default function NetworkPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [networkData, setNetworkData] = useState<{ nodes: NetworkNode[]; links: NetworkLink[] }>({ nodes: [], links: [] })
  const [selectedNode, setSelectedNode] = useState<NetworkNode | null>(null)
  const [isPlaying, setIsPlaying] = useState(true)
  const [zoom, setZoom] = useState(1)
  const [filterRisk, setFilterRisk] = useState([0])
  const [showLabels, setShowLabels] = useState(true)
  const [linkType, setLinkType] = useState<string>("all")
  
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number | null>(null)

  useEffect(() => {
    setNetworkData(generateNetworkData(60))
  }, [])

  // Force simulation
  const simulate = useCallback(() => {
    if (!isPlaying) return

    setNetworkData(prev => {
      const { nodes, links } = prev
      const width = 800
      const height = 600
      const centerX = width / 2
      const centerY = height / 2

      // Apply forces
      const newNodes = nodes.map(node => {
        let fx = 0
        let fy = 0

        // Center gravity
        fx += (centerX - node.x) * 0.001
        fy += (centerY - node.y) * 0.001

        // Repulsion from other nodes
        nodes.forEach(other => {
          if (node.id !== other.id) {
            const dx = node.x - other.x
            const dy = node.y - other.y
            const dist = Math.sqrt(dx * dx + dy * dy) || 1
            const force = 500 / (dist * dist)
            fx += (dx / dist) * force
            fy += (dy / dist) * force
          }
        })

        // Attraction from links
        links.forEach(link => {
          if (link.source === node.id || link.target === node.id) {
            const otherId = link.source === node.id ? link.target : link.source
            const other = nodes.find(n => n.id === otherId)
            if (other) {
              const dx = other.x - node.x
              const dy = other.y - node.y
              const dist = Math.sqrt(dx * dx + dy * dy) || 1
              fx += dx * link.strength * 0.01
              fy += dy * link.strength * 0.01
            }
          }
        })

        // Update velocity with damping
        const vx = (node.vx + fx) * 0.9
        const vy = (node.vy + fy) * 0.9

        // Update position
        const x = Math.max(30, Math.min(width - 30, node.x + vx))
        const y = Math.max(30, Math.min(height - 30, node.y + vy))

        return { ...node, x, y, vx, vy }
      })

      return { nodes: newNodes, links }
    })

    animationRef.current = requestAnimationFrame(simulate)
  }, [isPlaying])

  useEffect(() => {
    if (isPlaying) {
      animationRef.current = requestAnimationFrame(simulate)
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isPlaying, simulate])

  // Canvas rendering
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    canvas.width = 800 * dpr
    canvas.height = 600 * dpr
    ctx.scale(dpr, dpr)

    // Clear canvas
    ctx.fillStyle = "hsl(240 10% 4%)"
    ctx.fillRect(0, 0, 800, 600)

    // Apply zoom transform
    ctx.save()
    ctx.translate(400, 300)
    ctx.scale(zoom, zoom)
    ctx.translate(-400, -300)

    // Filter links
    const filteredLinks = networkData.links.filter(link => 
      linkType === "all" || link.type === linkType
    )

    // Draw links
    filteredLinks.forEach(link => {
      const source = networkData.nodes.find(n => n.id === link.source)
      const target = networkData.nodes.find(n => n.id === link.target)
      if (source && target) {
        if (source.risk < filterRisk[0] && target.risk < filterRisk[0]) return

        ctx.beginPath()
        ctx.moveTo(source.x, source.y)
        ctx.lineTo(target.x, target.y)
        
        if (link.type === "suspicious") {
          ctx.strokeStyle = "hsla(25, 100%, 50%, 0.4)"
          ctx.lineWidth = 2
        } else if (link.type === "transfer") {
          ctx.strokeStyle = "hsla(160, 60%, 45%, 0.3)"
          ctx.lineWidth = 1.5
        } else {
          ctx.strokeStyle = "hsla(220, 15%, 40%, 0.2)"
          ctx.lineWidth = 1
        }
        ctx.stroke()
      }
    })

    // Draw nodes
    networkData.nodes.forEach(node => {
      if (node.risk < filterRisk[0]) return

      const radius = Math.min(8 + node.connections * 0.5, 20)
      
      // Node glow for high risk
      if (node.risk >= 70) {
        ctx.beginPath()
        ctx.arc(node.x, node.y, radius + 6, 0, Math.PI * 2)
        const gradient = ctx.createRadialGradient(node.x, node.y, radius, node.x, node.y, radius + 8)
        gradient.addColorStop(0, "hsla(25, 100%, 50%, 0.4)")
        gradient.addColorStop(1, "hsla(25, 100%, 50%, 0)")
        ctx.fillStyle = gradient
        ctx.fill()
      }

      // Node circle
      ctx.beginPath()
      ctx.arc(node.x, node.y, radius, 0, Math.PI * 2)
      
      if (node.risk >= 80) {
        ctx.fillStyle = "hsl(0, 84%, 60%)"
      } else if (node.risk >= 60) {
        ctx.fillStyle = "hsl(38, 92%, 50%)"
      } else if (node.risk >= 40) {
        ctx.fillStyle = "hsl(200, 70%, 50%)"
      } else {
        ctx.fillStyle = "hsl(160, 60%, 45%)"
      }
      ctx.fill()

      // Selected node ring
      if (selectedNode?.id === node.id) {
        ctx.beginPath()
        ctx.arc(node.x, node.y, radius + 4, 0, Math.PI * 2)
        ctx.strokeStyle = "hsl(160, 60%, 45%)"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Labels
      if (showLabels && zoom >= 0.8) {
        ctx.fillStyle = "hsl(0, 0%, 70%)"
        ctx.font = "10px Inter, sans-serif"
        ctx.textAlign = "center"
        ctx.fillText(node.label, node.x, node.y + radius + 14)
      }
    })

    ctx.restore()
  }, [networkData, zoom, selectedNode, filterRisk, showLabels, linkType])

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) / zoom
    const y = (e.clientY - rect.top) / zoom

    // Find clicked node
    const clicked = networkData.nodes.find(node => {
      const dx = node.x - x
      const dy = node.y - y
      return Math.sqrt(dx * dx + dy * dy) < 15
    })

    setSelectedNode(clicked || null)
  }

  const stats = {
    totalNodes: networkData.nodes.length,
    totalLinks: networkData.links.length,
    highRisk: networkData.nodes.filter(n => n.risk >= 70).length,
    suspicious: networkData.links.filter(l => l.type === "suspicious").length,
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-1 flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Page Header */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Network Analysis</h1>
                <p className="text-sm text-muted-foreground">
                  Visualize transaction networks and detect suspicious patterns
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setNetworkData(generateNetworkData(60))}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Regenerate
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.totalNodes}</p>
                    <p className="text-xs text-muted-foreground">Total Nodes</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-2/10">
                    <Link2 className="h-5 w-5 text-chart-2" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.totalLinks}</p>
                    <p className="text-xs text-muted-foreground">Connections</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-destructive">{stats.highRisk}</p>
                    <p className="text-xs text-muted-foreground">High Risk Nodes</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-3/10">
                    <Eye className="h-5 w-5 text-chart-3" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-chart-3">{stats.suspicious}</p>
                    <p className="text-xs text-muted-foreground">Suspicious Links</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="grid gap-6 lg:grid-cols-4">
              {/* Graph Canvas */}
              <div className="lg:col-span-3">
                <Card className="border-border/50 bg-card/50 backdrop-blur overflow-hidden">
                  <CardHeader className="border-b border-border/50 pb-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Network Graph</CardTitle>
                        <CardDescription>Force-directed visualization of account relationships</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setIsPlaying(!isPlaying)}
                        >
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}
                        >
                          <ZoomOut className="h-4 w-4" />
                        </Button>
                        <span className="min-w-[4ch] text-center text-sm text-muted-foreground">
                          {Math.round(zoom * 100)}%
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setZoom(z => Math.min(2, z + 0.1))}
                        >
                          <ZoomIn className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setZoom(1)}
                        >
                          <Maximize2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <canvas
                      ref={canvasRef}
                      className="w-full cursor-crosshair"
                      style={{ height: "600px" }}
                      onClick={handleCanvasClick}
                    />
                  </CardContent>
                </Card>
              </div>

              {/* Controls & Details */}
              <div className="space-y-6">
                {/* Controls */}
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Settings2 className="h-4 w-4" />
                      Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <Label className="text-sm text-muted-foreground">
                        Minimum Risk Score: {filterRisk[0]}
                      </Label>
                      <Slider
                        value={filterRisk}
                        onValueChange={setFilterRisk}
                        max={100}
                        step={5}
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label className="text-sm text-muted-foreground">Link Type</Label>
                      <Select value={linkType} onValueChange={setLinkType}>
                        <SelectTrigger className="bg-secondary/50">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Links</SelectItem>
                          <SelectItem value="transfer">Transfers</SelectItem>
                          <SelectItem value="relationship">Relationships</SelectItem>
                          <SelectItem value="suspicious">Suspicious</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-sm text-muted-foreground">Show Labels</Label>
                      <Switch checked={showLabels} onCheckedChange={setShowLabels} />
                    </div>
                  </CardContent>
                </Card>

                {/* Node Details */}
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-base">Node Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedNode ? (
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-full",
                            selectedNode.risk >= 70 ? "bg-destructive/20" : "bg-primary/20"
                          )}>
                            <span className={cn(
                              "text-sm font-bold",
                              selectedNode.risk >= 70 ? "text-destructive" : "text-primary"
                            )}>
                              {selectedNode.risk}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium">{selectedNode.label}</p>
                            <p className="text-xs capitalize text-muted-foreground">{selectedNode.type}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Risk Score</p>
                            <p className={cn(
                              "font-bold",
                              selectedNode.risk >= 80 ? "text-destructive" :
                              selectedNode.risk >= 60 ? "text-chart-3" :
                              selectedNode.risk >= 40 ? "text-chart-2" : "text-chart-1"
                            )}>
                              {selectedNode.risk}/100
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Connections</p>
                            <p className="font-bold">{selectedNode.connections}</p>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1">
                            Investigate
                          </Button>
                          <Button variant="outline" size="sm">
                            Flag
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex h-[180px] items-center justify-center text-center">
                        <p className="text-sm text-muted-foreground">
                          Click on a node to view details
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Legend */}
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-base">Legend</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full bg-chart-1" />
                      <span className="text-sm text-muted-foreground">Low Risk (0-39)</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full bg-chart-2" />
                      <span className="text-sm text-muted-foreground">Medium Risk (40-59)</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full bg-chart-3" />
                      <span className="text-sm text-muted-foreground">High Risk (60-79)</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full bg-destructive" />
                      <span className="text-sm text-muted-foreground">Critical Risk (80+)</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
