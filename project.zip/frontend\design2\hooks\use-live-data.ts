"use client"

import { useEffect, useState, useCallback, useRef } from "react"

// Types
export interface LiveAccount {
  id: string
  name: string
  accountNumber: string
  balance: number
  transactionCount?: number
  kycStatus?: "VERIFIED" | "NOT_VERIFIED"
  cibilScore?: number
  pamrsScore: number
  riskLevel: "critical" | "high" | "medium" | "low"
  lastActivity: string
  flagged: boolean
  transactions: number
}

export interface LiveTransaction {
  id: string
  senderId: string
  senderName: string
  receiverId: string
  receiverName: string
  amount: number
  type: "incoming" | "outgoing" | "internal"
  status: "completed" | "pending" | "flagged" | "blocked"
  riskScore: number
  timestamp: Date
  description: string
}

export interface LiveAlert {
  id: string
  accountId: string
  type: string
  riskScore: number
  timestamp: Date
  description: string
  level: "critical" | "high" | "medium" | "low"
  action?: string
  reason?: string
}

export interface LiveMetrics {
  totalAccounts: number
  flaggedAccounts: number
  fundsAtRisk: number
  activeAlerts: number
  transactionsPerMinute: number
  blockedTransactions: number
}

export interface NetworkNode {
  id: string
  risk: "high" | "medium" | "low"
  pamrsScore: number
}

export interface NetworkLink {
  source: string
  target: string
  value: number
}

export interface LiveData {
  accounts: LiveAccount[]
  transactions: LiveTransaction[]
  alerts: LiveAlert[]
  metrics: LiveMetrics
  networkNodes: NetworkNode[]
  networkLinks: NetworkLink[]
  isConnected: boolean
  lastUpdate: Date | null
}

// Random data generators
const names = [
  "James Wilson", "Sarah Chen", "Michael Brown", "Emily Davis", "Robert Taylor",
  "Jennifer Martinez", "David Anderson", "Lisa Thompson", "William Garcia", "Jessica Lee",
  "Christopher White", "Amanda Harris", "Daniel Clark", "Michelle Lewis", "Matthew Robinson",
  "Ashley Walker", "Joshua Hall", "Stephanie Young", "Andrew King", "Nicole Wright"
]

const alertTypes = [
  "Unusual Transaction", "Geographic Anomaly", "Velocity Check", "Device Change",
  "Amount Threshold", "Pattern Deviation", "Time Anomaly", "Network Cluster",
  "Multiple Failed Logins", "Suspicious Recipient", "Round Amount Transfer", "New Payee Alert"
]

const descriptions = [
  "Multiple high-value transactions detected in rapid succession",
  "Login from unusual geographic location detected",
  "Transaction frequency exceeds normal pattern by 340%",
  "New device detected for sensitive operations",
  "Single transaction exceeds typical amount threshold",
  "Spending pattern differs from historical baseline",
  "Transaction at unusual time of day for this account",
  "Account connected to flagged network cluster",
  "Multiple failed authentication attempts detected",
  "Transfer to newly created recipient account",
  "Large round-number transfer flagged for review",
  "First-time payee with high-value transaction"
]

const transactionDescriptions = [
  "Wire Transfer", "ACH Payment", "Card Purchase", "Direct Deposit",
  "Bill Payment", "P2P Transfer", "ATM Withdrawal", "International Wire",
  "Merchant Payment", "Subscription", "Refund", "Cash Deposit"
]

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function randomChoice<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function generateAccountId(): string {
  return `ACC-${randomInt(1000, 9999)}`
}

function generateTransactionId(): string {
  return `TXN-${Date.now()}-${randomInt(100, 999)}`
}

function getRiskLevel(score: number): "critical" | "high" | "medium" | "low" {
  if (score >= 80) return "critical"
  if (score >= 60) return "high"
  if (score >= 40) return "medium"
  return "low"
}

function generateAccount(id?: string): LiveAccount {
  const pamrsScore = randomInt(15, 98)
  const isVerified = Math.random() > 0.35
  const cibil = isVerified ? randomInt(650, 900) : randomInt(300, 650)
  return {
    id: id || generateAccountId(),
    name: randomChoice(names),
    accountNumber: `****${randomInt(1000, 9999)}`,
    balance: randomInt(1000, 1_000_000),
    transactionCount: randomInt(5, 200),
    kycStatus: isVerified ? "VERIFIED" : "NOT_VERIFIED",
    cibilScore: cibil,
    pamrsScore,
    riskLevel: getRiskLevel(pamrsScore),
    lastActivity: `${randomInt(1, 59)} min ago`,
    flagged: pamrsScore >= 60,
    transactions: randomInt(5, 150),
  }
}

function generateTransaction(accounts: LiveAccount[]): LiveTransaction {
  const sender = randomChoice(accounts)
  const receiver = randomChoice(accounts.filter(a => a.id !== sender.id))
  const amount = randomInt(50, 75000)
  const riskScore = randomInt(10, 95)
  const statuses: ("completed" | "pending" | "flagged" | "blocked")[] = 
    riskScore >= 80 ? ["flagged", "blocked"] :
    riskScore >= 60 ? ["flagged", "pending", "completed"] :
    ["completed", "pending"]
  
  return {
    id: generateTransactionId(),
    senderId: sender.id,
    senderName: sender.name,
    receiverId: receiver?.id || generateAccountId(),
    receiverName: receiver?.name || randomChoice(names),
    amount,
    type: randomChoice(["incoming", "outgoing", "internal"]),
    status: randomChoice(statuses),
    riskScore,
    timestamp: new Date(),
    description: randomChoice(transactionDescriptions),
  }
}

function generateAlert(accounts: LiveAccount[]): LiveAlert {
  const account = randomChoice(accounts.filter(a => a.pamrsScore >= 40))
  const riskScore = randomInt(45, 98)
  return {
    id: `ALT-${Date.now()}-${randomInt(100, 999)}`,
    accountId: account?.id || generateAccountId(),
    type: randomChoice(alertTypes),
    riskScore,
    timestamp: new Date(),
    description: randomChoice(descriptions),
    level: getRiskLevel(riskScore),
    action: randomChoice(["Review Required", "Auto-blocked", "Pending Investigation", "Escalated"]),
    reason: `Risk score ${riskScore} exceeds threshold`,
  }
}

function generateNetworkData(accounts: LiveAccount[]): { nodes: NetworkNode[], links: NetworkLink[] } {
  const nodes: NetworkNode[] = accounts.slice(0, 15).map(acc => ({
    id: acc.id,
    risk: acc.pamrsScore >= 70 ? "high" : acc.pamrsScore >= 40 ? "medium" : "low",
    pamrsScore: acc.pamrsScore,
  }))

  const links: NetworkLink[] = []
  nodes.forEach((node, i) => {
    const numLinks = randomInt(1, 3)
    for (let j = 0; j < numLinks; j++) {
      const targetIdx = (i + j + 1) % nodes.length
      if (targetIdx !== i) {
        links.push({
          source: node.id,
          target: nodes[targetIdx].id,
          value: randomInt(1, 5),
        })
      }
    }
  })

  return { nodes, links }
}

export function useLiveData(updateInterval = 3000): LiveData {
  const [data, setData] = useState<LiveData>({
    accounts: [],
    transactions: [],
    alerts: [],
    metrics: {
      totalAccounts: 24521,
      flaggedAccounts: 147,
      fundsAtRisk: 2400000,
      activeAlerts: 38,
      transactionsPerMinute: 1247,
      blockedTransactions: 23,
    },
    networkNodes: [],
    networkLinks: [],
    isConnected: false,
    lastUpdate: null,
  })

  const accountsRef = useRef<LiveAccount[]>([])

  // Initialize data
  useEffect(() => {
    const initialAccounts = Array.from({ length: 20 }, () => generateAccount())
    accountsRef.current = initialAccounts
    
    const { nodes, links } = generateNetworkData(initialAccounts)
    const initialTransactions = Array.from({ length: 10 }, () => generateTransaction(initialAccounts))
    const initialAlerts = Array.from({ length: 7 }, () => generateAlert(initialAccounts))

    setData({
      accounts: initialAccounts,
      transactions: initialTransactions,
      alerts: initialAlerts.sort((a, b) => b.riskScore - a.riskScore),
      metrics: {
        totalAccounts: 24521 + randomInt(-50, 50),
        flaggedAccounts: 147 + randomInt(-10, 15),
        fundsAtRisk: 2400000 + randomInt(-200000, 300000),
        activeAlerts: 38 + randomInt(-5, 8),
        transactionsPerMinute: 1247 + randomInt(-100, 200),
        blockedTransactions: 23 + randomInt(-3, 5),
      },
      networkNodes: nodes,
      networkLinks: links,
      isConnected: true,
      lastUpdate: new Date(),
    })
  }, [])

  // Simulate real-time updates
  useEffect(() => {
    if (accountsRef.current.length === 0) return

    const interval = setInterval(() => {
      setData(prev => {
        const accounts = accountsRef.current
        
        // Generate new transaction
        const newTransaction = generateTransaction(accounts)
        const transactions = [newTransaction, ...prev.transactions].slice(0, 25)

        // Occasionally generate new alert (30% chance)
        let alerts = prev.alerts
        if (Math.random() > 0.7) {
          const newAlert = generateAlert(accounts)
          alerts = [newAlert, ...prev.alerts]
            .sort((a, b) => b.riskScore - a.riskScore)
            .slice(0, 15)
        }

        // Update some account PAMRS scores randomly
        const updatedAccounts = accounts.map(acc => {
          if (Math.random() > 0.85) {
            const newScore = Math.max(10, Math.min(98, acc.pamrsScore + randomInt(-8, 12)))
            return { ...acc, pamrsScore: newScore, riskLevel: getRiskLevel(newScore) }
          }
          return acc
        })
        accountsRef.current = updatedAccounts

        // Update network
        const { nodes, links } = generateNetworkData(updatedAccounts)

        // Update metrics with realistic fluctuations
        const metrics = {
          totalAccounts: prev.metrics.totalAccounts + randomInt(-2, 5),
          flaggedAccounts: Math.max(100, prev.metrics.flaggedAccounts + randomInt(-3, 4)),
          fundsAtRisk: Math.max(1000000, prev.metrics.fundsAtRisk + randomInt(-50000, 80000)),
          activeAlerts: Math.max(20, alerts.length + randomInt(10, 30)),
          transactionsPerMinute: Math.max(800, prev.metrics.transactionsPerMinute + randomInt(-50, 80)),
          blockedTransactions: Math.max(10, prev.metrics.blockedTransactions + randomInt(-2, 3)),
        }

        return {
          accounts: updatedAccounts,
          transactions,
          alerts,
          metrics,
          networkNodes: nodes,
          networkLinks: links,
          isConnected: true,
          lastUpdate: new Date(),
        }
      })
    }, updateInterval)

    return () => clearInterval(interval)
  }, [updateInterval])

  return data
}

export function formatCurrency(amount: number): string {
  if (amount >= 1000000) {
    return `$${(amount / 1000000).toFixed(1)}M`
  }
  if (amount >= 1000) {
    return `$${(amount / 1000).toFixed(1)}K`
  }
  return `$${amount.toLocaleString()}`
}

export function formatNumber(num: number): string {
  return num.toLocaleString()
}

export function getTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
  if (seconds < 60) return `${seconds}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  return `${hours}h ago`
}
