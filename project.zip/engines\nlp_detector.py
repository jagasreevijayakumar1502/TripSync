"""
NLP Fraud Detection Engine (Pure Python - no ML dependencies)
Detects coordinated mule networks through transaction remark analysis.
"""
from typing import List, Dict, Any
import math
import re


class NLPDetector:
    """NLP-based fraud detection using pure-Python TF-IDF."""

    def __init__(self):
        self.remark_history: List[str] = []
        self.suspicious_patterns = [
            r'for goods',
            r'rent payment',
            r'salary',
            r'business',
            r'personal',
            r'family',
            r'friend',
            r'cash',
            r'money transfer',
            r'payment',
        ]

    @staticmethod
    def preprocess_remark(remark: str) -> str:
        """Clean and normalize remark text."""
        if not remark:
            return ""
        text = str(remark).lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        return ' '.join(text.split())

    @staticmethod
    def cosine_similarity(vec_a: Dict[str, float], vec_b: Dict[str, float]) -> float:
        """Cosine similarity between two sparse vectors."""
        dot = sum(vec_a.get(k, 0.0) * vec_b.get(k, 0.0) for k in vec_a)
        norm_a = math.sqrt(sum(v*v for v in vec_a.values())) or 1.0
        norm_b = math.sqrt(sum(v*v for v in vec_b.values())) or 1.0
        return dot / (norm_a * norm_b)

    def build_tfidf_vectors(self, texts: List[str]) -> List[Dict[str, float]]:
        """Build TF-IDF vectors (pure Python)."""
        docs = [self.preprocess_remark(t) for t in texts]
        tokenized = [[w for w in doc.split() if w] for doc in docs]

        # TF
        tfs = []
        for tokens in tokenized:
            tf = {}
            total = max(len(tokens), 1)
            for w in tokens:
                tf[w] = tf.get(w, 0) + 1.0 / total
            tfs.append(tf)

        # IDF
        df = {}
        for tf in tfs:
            for w in tf:
                df[w] = df.get(w, 0) + 1
        n = len(tfs) or 1
        idf = {w: math.log(n / max(1, df_w)) + 1 for w, df_w in df.items()}

        # TF-IDF
        return [{w: tf_val * idf.get(w, 1.0) for w, tf_val in tf.items()} for tf in tfs]

    def detect_similar_transactions(self, remarks: List[str], threshold: float = 0.8) -> List[Dict[str, Any]]:
        """Find similar remarks using TF-IDF + cosine similarity."""
        if len(remarks) < 2:
            return []

        processed = [self.preprocess_remark(r) for r in remarks]
        valid = [(i, p) for i, p in enumerate(processed) if p]

        if len(valid) < 2:
            return []

        indices, texts = zip(*valid)
        texts = list(texts)
        vectors = self.build_tfidf_vectors(texts)

        suspicious = []
        for i in range(len(texts)):
            for j in range(i + 1, len(texts)):
                sim = self.cosine_similarity(vectors[i], vectors[j])
                if sim >= threshold:
                    suspicious.append({
                        "remark_1": remarks[indices[i]],
                        "remark_2": remarks[indices[j]],
                        "similarity": round(sim, 3),
                        "processed_1": texts[i],
                        "processed_2": texts[j],
                        "indices": [indices[i], indices[j]]
                    })

        return suspicious

    def detect_suspicious_patterns(self, remark: str) -> List[str]:
        """Find suspicious keywords in remark."""
        if not remark:
            return []
        processed = self.preprocess_remark(remark)
        return [p for p in self.suspicious_patterns if re.search(p, processed)]

    def analyze_transaction_batch(self, transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Batch analyze transactions for fraud."""
        remarks = [str(tx.get('remark') or tx.get('Remark') or tx.get('UPI_Remark') or '') 
                   for tx in transactions]
        self.remark_history.extend(remarks)

        similar = self.detect_similar_transactions(self.remark_history[-100:])
        
        pattern_alerts = []
        for idx, tx in enumerate(transactions):
            patterns = self.detect_suspicious_patterns(remarks[idx])
            if patterns:
                pattern_alerts.append({
                    'tx_idx': idx,
                    'remark': remarks[idx],
                    'patterns': patterns
                })

        return {
            'similar_pairs': similar,
            'pattern_hits': pattern_alerts,
            'analyzed': len(transactions),
            'history_size': len(self.remark_history)
        }

    def get_fraud_score(self, remark: str, context: List[str] = None) -> float:
        """Fraud risk score for a remark (0.0-1.0)."""
        if not remark:
            return 0.0
        
        score = 0.0
        patterns = self.detect_suspicious_patterns(remark)
        score += min(len(patterns) * 0.2, 0.6)
        
        if context:
            similar = self.detect_similar_transactions([remark] + context, threshold=0.7)
            count = sum(1 for p in similar if remark in [p['remark_1'], p['remark_2']])
            score += min(count * 0.1, 0.4)
        
        return min(score, 1.0)
