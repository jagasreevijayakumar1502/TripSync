"use client"

import { useState, useEffect } from "react"
import { 
  FileText,
  Download,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Eye,
  Trash2,
  MoreHorizontal,
  Plus,
  Filter,
  Search,
  FileBarChart,
  FileSpreadsheet,
  FilePieChart,
} from "lucide-react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

interface Report {
  id: string
  name: string
  type: "fraud" | "compliance" | "risk" | "audit"
  status: "completed" | "generating" | "failed" | "scheduled"
  createdAt: Date
  size: string
  format: "pdf" | "csv" | "xlsx"
  createdBy: string
}

const reportTypes = [
  { 
    id: "fraud", 
    name: "Fraud Detection Summary", 
    description: "Overview of detected fraud patterns and blocked transactions",
    icon: FileBarChart,
  },
  { 
    id: "compliance", 
    name: "Compliance Report", 
    description: "Regulatory compliance status and audit trail",
    icon: FileText,
  },
  { 
    id: "risk", 
    name: "Risk Assessment", 
    description: "Account risk scores and vulnerability analysis",
    icon: FilePieChart,
  },
  { 
    id: "audit", 
    name: "Audit Log Export", 
    description: "Complete system activity and user actions log",
    icon: FileSpreadsheet,
  },
]

const generateReports = (): Report[] => {
  const types: Report["type"][] = ["fraud", "compliance", "risk", "audit"]
  const statuses: Report["status"][] = ["completed", "completed", "completed", "generating", "failed", "scheduled"]
  const formats: Report["format"][] = ["pdf", "csv", "xlsx"]
  const users = ["John Smith", "Sarah Johnson", "Mike Chen", "Emily Davis", "System Auto"]
  
  return Array.from({ length: 25 }, (_, i) => ({
    id: `RPT-${String(i + 1).padStart(6, "0")}`,
    name: `${reportTypes[Math.floor(Math.random() * reportTypes.length)].name} - ${new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}`,
    type: types[Math.floor(Math.random() * types.length)],
    status: statuses[Math.floor(Math.random() * statuses.length)],
    createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
    size: `${(Math.random() * 10 + 0.5).toFixed(1)} MB`,
    format: formats[Math.floor(Math.random() * formats.length)],
    createdBy: users[Math.floor(Math.random() * users.length)],
  }))
}

const statusStyles = {
  completed: { badge: "bg-chart-1/10 text-chart-1 border-chart-1/30", icon: CheckCircle2 },
  generating: { badge: "bg-chart-2/10 text-chart-2 border-chart-2/30", icon: Loader2 },
  failed: { badge: "bg-destructive/10 text-destructive border-destructive/30", icon: XCircle },
  scheduled: { badge: "bg-primary/10 text-primary border-primary/30", icon: Clock },
}

const typeStyles = {
  fraud: "bg-destructive/10 text-destructive border-destructive/30",
  compliance: "bg-chart-2/10 text-chart-2 border-chart-2/30",
  risk: "bg-chart-3/10 text-chart-3 border-chart-3/30",
  audit: "bg-primary/10 text-primary border-primary/30",
}

export default function ReportsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [reports, setReports] = useState<Report[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedReportType, setSelectedReportType] = useState("")
  const [selectedFormat, setSelectedFormat] = useState("pdf")
  const [dateRange, setDateRange] = useState("30d")

  useEffect(() => {
    setReports(generateReports())
  }, [])

  const filteredReports = reports.filter(report => {
    const matchesSearch = report.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         report.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || report.type === typeFilter
    const matchesStatus = statusFilter === "all" || report.status === statusFilter
    return matchesSearch && matchesType && matchesStatus
  })

  const stats = {
    total: reports.length,
    completed: reports.filter(r => r.status === "completed").length,
    generating: reports.filter(r => r.status === "generating").length,
    scheduled: reports.filter(r => r.status === "scheduled").length,
  }

  const handleGenerateReport = () => {
    const newReport: Report = {
      id: `RPT-${String(reports.length + 1).padStart(6, "0")}`,
      name: `${reportTypes.find(t => t.id === selectedReportType)?.name} - ${new Date().toLocaleDateString()}`,
      type: selectedReportType as Report["type"],
      status: "generating",
      createdAt: new Date(),
      size: "0 MB",
      format: selectedFormat as Report["format"],
      createdBy: "Current User",
    }
    setReports([newReport, ...reports])
    setIsDialogOpen(false)
    
    // Simulate completion
    setTimeout(() => {
      setReports(prev => prev.map(r => 
        r.id === newReport.id 
          ? { ...r, status: "completed" as const, size: `${(Math.random() * 10 + 0.5).toFixed(1)} MB` }
          : r
      ))
    }, 3000)
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-1 flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Page Header */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Reports</h1>
                <p className="text-sm text-muted-foreground">
                  Generate and manage fraud detection reports
                </p>
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Generate Report
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Generate New Report</DialogTitle>
                    <DialogDescription>
                      Select the type of report and configure options
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-6 py-4">
                    <div className="space-y-3">
                      <Label>Report Type</Label>
                      <div className="grid gap-3">
                        {reportTypes.map((type) => {
                          const Icon = type.icon
                          return (
                            <div
                              key={type.id}
                              className={cn(
                                "flex cursor-pointer items-center gap-4 rounded-lg border p-4 transition-colors",
                                selectedReportType === type.id
                                  ? "border-primary bg-primary/5"
                                  : "border-border/50 hover:bg-secondary/50"
                              )}
                              onClick={() => setSelectedReportType(type.id)}
                            >
                              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                                <Icon className="h-5 w-5 text-primary" />
                              </div>
                              <div className="flex-1">
                                <p className="font-medium">{type.name}</p>
                                <p className="text-sm text-muted-foreground">{type.description}</p>
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Date Range</Label>
                        <Select value={dateRange} onValueChange={setDateRange}>
                          <SelectTrigger className="bg-secondary/50">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="7d">Last 7 days</SelectItem>
                            <SelectItem value="30d">Last 30 days</SelectItem>
                            <SelectItem value="90d">Last 90 days</SelectItem>
                            <SelectItem value="1y">Last year</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Format</Label>
                        <Select value={selectedFormat} onValueChange={setSelectedFormat}>
                          <SelectTrigger className="bg-secondary/50">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pdf">PDF</SelectItem>
                            <SelectItem value="csv">CSV</SelectItem>
                            <SelectItem value="xlsx">Excel</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleGenerateReport} disabled={!selectedReportType}>
                      Generate Report
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                    <FileText className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.total}</p>
                    <p className="text-xs text-muted-foreground">Total Reports</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-1/10">
                    <CheckCircle2 className="h-5 w-5 text-chart-1" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-chart-1">{stats.completed}</p>
                    <p className="text-xs text-muted-foreground">Completed</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-2/10">
                    <Loader2 className="h-5 w-5 text-chart-2" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-chart-2">{stats.generating}</p>
                    <p className="text-xs text-muted-foreground">Generating</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">{stats.scheduled}</p>
                    <p className="text-xs text-muted-foreground">Scheduled</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Reports Table */}
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader className="border-b border-border/50">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <CardTitle>Report History</CardTitle>
                    <CardDescription>View and download generated reports</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search reports..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-[200px] pl-9 bg-secondary/50"
                      />
                    </div>
                    <Select value={typeFilter} onValueChange={setTypeFilter}>
                      <SelectTrigger className="w-[130px] bg-secondary/50">
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="fraud">Fraud</SelectItem>
                        <SelectItem value="compliance">Compliance</SelectItem>
                        <SelectItem value="risk">Risk</SelectItem>
                        <SelectItem value="audit">Audit</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[130px] bg-secondary/50">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="generating">Generating</SelectItem>
                        <SelectItem value="scheduled">Scheduled</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border/50 hover:bg-transparent">
                      <TableHead className="text-muted-foreground">Report</TableHead>
                      <TableHead className="text-muted-foreground">Type</TableHead>
                      <TableHead className="text-muted-foreground">Status</TableHead>
                      <TableHead className="text-muted-foreground">Created</TableHead>
                      <TableHead className="text-muted-foreground">Created By</TableHead>
                      <TableHead className="text-muted-foreground">Size</TableHead>
                      <TableHead className="w-[100px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReports.map((report) => {
                      const StatusIcon = statusStyles[report.status].icon
                      return (
                        <TableRow 
                          key={report.id} 
                          className="border-border/50 transition-colors hover:bg-secondary/30"
                        >
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary">
                                <FileText className="h-4 w-4 text-muted-foreground" />
                              </div>
                              <div>
                                <p className="font-medium line-clamp-1">{report.name}</p>
                                <p className="text-xs text-muted-foreground">{report.id} · {report.format.toUpperCase()}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={cn("capitalize", typeStyles[report.type])}>
                              {report.type}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={cn("capitalize", statusStyles[report.status].badge)}>
                              <StatusIcon className={cn(
                                "mr-1 h-3 w-3",
                                report.status === "generating" && "animate-spin"
                              )} />
                              {report.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {report.createdAt.toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {report.createdBy}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {report.size}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              {report.status === "completed" && (
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <Download className="h-4 w-4" />
                                </Button>
                              )}
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    Preview
                                  </DropdownMenuItem>
                                  {report.status === "completed" && (
                                    <DropdownMenuItem>
                                      <Download className="mr-2 h-4 w-4" />
                                      Download
                                    </DropdownMenuItem>
                                  )}
                                  <DropdownMenuItem className="text-destructive">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
