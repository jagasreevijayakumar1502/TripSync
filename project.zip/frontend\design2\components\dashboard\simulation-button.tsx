"use client"

import { useState } from "react"
import { Play, Loader2, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"

export function SimulationButton() {
  const [isOpen, setIsOpen] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [config, setConfig] = useState({
    transactionCount: 100,
    fraudRate: 15,
    includeHighRisk: true,
    realTimeUpdates: true,
  })

  const handleRunSimulation = async () => {
    setIsRunning(true)
    setIsComplete(false)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 3000))

    setIsRunning(false)
    setIsComplete(true)

    // Reset after showing success
    setTimeout(() => {
      setIsOpen(false)
      setIsComplete(false)
    }, 2000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
          <Play className="h-4 w-4" />
          Run Stream Simulation
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Stream Simulation</DialogTitle>
          <DialogDescription>
            Configure and run a fraud detection simulation to test system
            capabilities.
          </DialogDescription>
        </DialogHeader>

        {isComplete ? (
          <div className="flex flex-col items-center justify-center py-8">
            <CheckCircle className="h-16 w-16 text-chart-1" />
            <h3 className="mt-4 text-lg font-semibold">Simulation Complete</h3>
            <p className="text-sm text-muted-foreground">
              {config.transactionCount} transactions processed
            </p>
          </div>
        ) : (
          <div className="space-y-6 py-4">
            {/* Transaction Count */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Transaction Count</Label>
                <span className="text-sm font-medium">{config.transactionCount}</span>
              </div>
              <Slider
                value={[config.transactionCount]}
                onValueChange={([value]) =>
                  setConfig({ ...config, transactionCount: value })
                }
                min={10}
                max={500}
                step={10}
                disabled={isRunning}
              />
            </div>

            {/* Fraud Rate */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Fraud Rate (%)</Label>
                <span className="text-sm font-medium">{config.fraudRate}%</span>
              </div>
              <Slider
                value={[config.fraudRate]}
                onValueChange={([value]) =>
                  setConfig({ ...config, fraudRate: value })
                }
                min={5}
                max={50}
                step={5}
                disabled={isRunning}
              />
            </div>

            {/* Toggles */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Include High Risk Scenarios</Label>
                  <p className="text-xs text-muted-foreground">
                    Generate complex fraud patterns
                  </p>
                </div>
                <Switch
                  checked={config.includeHighRisk}
                  onCheckedChange={(checked) =>
                    setConfig({ ...config, includeHighRisk: checked })
                  }
                  disabled={isRunning}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Real-time Updates</Label>
                  <p className="text-xs text-muted-foreground">
                    Push updates via WebSocket
                  </p>
                </div>
                <Switch
                  checked={config.realTimeUpdates}
                  onCheckedChange={(checked) =>
                    setConfig({ ...config, realTimeUpdates: checked })
                  }
                  disabled={isRunning}
                />
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          {!isComplete && (
            <>
              <Button
                variant="outline"
                onClick={() => setIsOpen(false)}
                disabled={isRunning}
              >
                Cancel
              </Button>
              <Button
                onClick={handleRunSimulation}
                disabled={isRunning}
                className="gap-2"
              >
                {isRunning ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Running...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    Start Simulation
                  </>
                )}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
