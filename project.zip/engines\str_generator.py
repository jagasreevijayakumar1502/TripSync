"""
STR (Suspicious Transaction Report) Generator
Creates structured reports for accounts with compliance score > 80.
"""
import uuid
from datetime import datetime


class STRGenerator:
    def __init__(self):
        self.reports = []

    def generate(self, evaluation_result, accounts_df, transactions_df):
        """Generate STR report from an evaluation result."""
        account_id = evaluation_result["account_id"]
        acct_info = accounts_df[accounts_df["Account_ID"] == account_id]

        if acct_info.empty:
            return None

        acct = acct_info.iloc[0]

        # Get account's transactions
        acct_txns = transactions_df[
            (transactions_df["Sender_Account_ID"] == account_id) |
            (transactions_df["Receiver_Account_ID"] == account_id)
        ]

        # Build transaction summary
        txn_summary = []
        for _, txn in acct_txns.head(20).iterrows():
            txn_summary.append({
                "txn_id": txn["Transaction_ID"],
                "sender": txn["Sender_Account_ID"],
                "receiver": txn["Receiver_Account_ID"],
                "amount": float(txn["Amount"]),
                "type": txn["Transaction_Type"],
                "timestamp": str(txn["Timestamp"]),
                "country": txn.get("Country", ""),
                "channel": txn.get("Channel", "")
            })

        # Determine primary triggered rule
        triggered_rules = []
        for engine, dets in evaluation_result["details"].items():
            for d in dets:
                triggered_rules.append(f"{engine}: {d.get('rule', 'Unknown')}")

        report = {
            "case_id": f"STR-{uuid.uuid4().hex[:8].upper()}",
            "generated_at": datetime.now().isoformat(),
            "account_details": {
                "account_id": account_id,
                "customer_id": str(acct.get("Customer_ID", "")),
                "account_type": str(acct.get("Account_Type", "")),
                "country": str(acct.get("Country", "")),
                "kyc_status": str(acct.get("KYC_Status", "")),
                "is_pep": bool(acct.get("Is_PEP", False)),
                "pep_category": str(acct.get("PEP_Category", "")),
                "declared_income": float(acct.get("Declared_Income", 0)),
                "risk_category": str(acct.get("Risk_Category", ""))
            },
            "risk_components": {
                "structuring_risk": evaluation_result["structuring_risk"],
                "velocity_risk": evaluation_result["velocity_risk"],
                "network_risk": evaluation_result["network_risk"],
                "pep_risk": evaluation_result["pep_risk"],
                "jurisdiction_risk": evaluation_result["jurisdiction_risk"],
                "kyc_risk": evaluation_result["kyc_risk"],
                "total_score": evaluation_result["compliance_risk_score"]
            },
            "triggered_rules": triggered_rules,
            "flags": evaluation_result["flags"],
            "transaction_summary": txn_summary,
            "total_transactions": len(acct_txns),
            "total_amount": float(acct_txns["Amount"].sum()),
            "recommendation": "Immediate investigation required. Account should be escalated to compliance officer.",
            "status": "Open"
        }

        self.reports.append(report)
        return report

    def generate_all(self, evaluation_results, accounts_df, transactions_df):
        """Generate STR reports for all accounts that trigger STR."""
        self.reports = []
        for result in evaluation_results:
            if result["decision"] == "Generate STR":
                self.generate(result, accounts_df, transactions_df)
        return self.reports

    def get_reports(self):
        return self.reports
