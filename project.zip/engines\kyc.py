"""
KYC & Profile Risk Engine
Detects incomplete KYC, new account risk, and income-transaction mismatch.
"""
import pandas as pd
from datetime import datetime


class KYCEngine:
    def __init__(self):
        self.new_account_days = 90
        self.income_mismatch_ratio = 3.0

    def evaluate(self, account_id, transactions_df, accounts_df):
        """
        Evaluate KYC / profile risk for a given account.
        Returns risk score [0-15] and details.
        """
        risk_score = 0
        details = []
        flags = []

        acct_info = accounts_df[accounts_df["Account_ID"] == account_id]
        if acct_info.empty:
            return {"score": 5, "details": [{"rule": "Unknown account"}], "flags": ["UNKNOWN ACCOUNT"]}

        acct = acct_info.iloc[0]
        kyc_status = acct.get("KYC_Status", "Pending")
        declared_income = acct.get("Declared_Income", 0)
        creation_date = acct.get("Account_Creation_Date", "")
        risk_category = acct.get("Risk_Category", "Low")

        # Rule 1: Incomplete KYC
        kyc_penalties = {
            "Pending": 8,
            "Partial": 5,
            "Expired": 6,
            "Complete": 0
        }
        kyc_penalty = kyc_penalties.get(kyc_status, 3)
        if kyc_penalty > 0:
            risk_score += kyc_penalty
            flags.append(f"KYC INCOMPLETE: Status = {kyc_status}")
            details.append({
                "rule": "Incomplete KYC",
                "kyc_status": kyc_status,
                "penalty": kyc_penalty
            })

        # Rule 2: New account risk
        if creation_date:
            try:
                created = pd.to_datetime(creation_date)
                age_days = (datetime.now() - created).days
                if age_days < self.new_account_days:
                    penalty = max(1, 5 - (age_days // 30))
                    risk_score += penalty
                    flags.append(f"NEW ACCOUNT: Created {age_days} days ago")
                    details.append({
                        "rule": "New account risk",
                        "age_days": age_days,
                        "penalty": penalty
                    })
            except Exception:
                pass

        # Rule 3: Income-transaction volume mismatch
        acct_txns = transactions_df[
            transactions_df["Sender_Account_ID"] == account_id
        ]
        if not acct_txns.empty and declared_income > 0:
            total_sent = acct_txns["Amount"].sum()
            # Annualize: assume data covers ~1 month
            monthly_volume = total_sent
            annual_estimate = monthly_volume * 12

            if annual_estimate > declared_income * self.income_mismatch_ratio:
                ratio = annual_estimate / declared_income
                penalty = min(7, int(ratio))
                risk_score += penalty
                flags.append(
                    f"INCOME MISMATCH: Estimated annual volume ₹{annual_estimate:,.0f} "
                    f"vs declared ₹{declared_income:,.0f} ({ratio:.1f}x)"
                )
                details.append({
                    "rule": "Income-transaction mismatch",
                    "estimated_annual": annual_estimate,
                    "declared_income": declared_income,
                    "ratio": round(ratio, 2),
                    "penalty": penalty
                })

        # Rule 4: High pre-assigned risk category
        if risk_category == "High":
            penalty = 3
            risk_score += penalty
            flags.append(f"HIGH RISK CATEGORY: Pre-assigned risk = High")
            details.append({
                "rule": "Pre-assigned high risk",
                "penalty": penalty
            })

        return {
            "score": min(risk_score, 15),
            "details": details,
            "flags": flags
        }
