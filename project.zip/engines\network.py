"""
Network Graph Engine (SENTINEL-G)
Intelligent graph engine with clustering, mastermind detection, and risk signals.
"""
import networkx as nx
from datetime import datetime


class GraphEngine:
    """
    Singleton Graph Intelligence Engine for AML/Fraud Detection.
    Only one instance exists across the entire application.
    """
    _instance = None

    def __new__(cls, max_hops=None):
        """Enforce singleton pattern: only one GraphEngine instance exists."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, max_hops=None):
        """Initialize GraphEngine only once (singleton pattern)."""
        if hasattr(self, '_initialized'):
            return  # Already initialized

        # max_hops parameter ignored for backward compatibility
        self.graph = nx.Graph()
        self._initialized = True
        self._built = False  # Track if graph has been built from data

    # -------------------------------
    # 1. ADD TRANSACTION EDGE
    # -------------------------------
    def add_transaction(self, sender, receiver, amount, device_id=None, timestamp=None):
        if not timestamp:
            timestamp = datetime.now()

        # Add nodes if not exist
        self.graph.add_node(sender)
        self.graph.add_node(receiver)

        # Add edge with metadata
        self.graph.add_edge(
            sender,
            receiver,
            amount=amount,
            device_id=device_id,
            timestamp=timestamp
        )

    # -------------------------------
    # 2. BUILD GRAPH FROM DATASET
    # -------------------------------
    def build_graph(self, transactions):
        """
        Build graph from transactions DataFrame or list of dicts.
        Supports multiple field name formats for compatibility.
        """
        # Clear existing graph
        self.graph = nx.Graph()

        # Handle DataFrame
        if hasattr(transactions, 'iterrows'):
            for _, tx in transactions.iterrows():
                sender = tx.get('Sender_Account_ID') or tx.get('sender')
                receiver = tx.get('Receiver_Account_ID') or tx.get('receiver')
                amount = tx.get('Amount') or tx.get('amount')
                device_id = tx.get('Device_ID') or tx.get('device_id')
                timestamp = tx.get('Timestamp') or tx.get('timestamp')

                if sender and receiver:
                    self.add_transaction(sender, receiver, amount, device_id, timestamp)
        # Handle list of dicts
        else:
            for tx in transactions:
                self.add_transaction(
                    tx.get("sender"),
                    tx.get("receiver"),
                    tx.get("amount"),
                    tx.get("device_id"),
                    tx.get("timestamp")
                )
        
        self._built = True  # Mark as built

    # -------------------------------
    # 3. CLUSTER DETECTION
    # -------------------------------
    def detect_clusters(self):
        # Snapshot graph to avoid mutation during iteration
        G = self.graph.copy(as_view=False)
        return list(nx.connected_components(G))

    # -------------------------------
    # 4. FLAG SUSPICIOUS CLUSTERS
    # -------------------------------
    def get_suspicious_clusters(self, min_size=5):
        clusters = self.detect_clusters()
        return [cluster for cluster in clusters if len(cluster) >= min_size]

    # -------------------------------
    # 5. MASTER NODE / HUB DETECTION
    # -------------------------------
    def get_hub_accounts(self, top_n=5):
        centrality = nx.degree_centrality(self.graph)
        sorted_nodes = sorted(centrality.items(), key=lambda x: x[1], reverse=True)
        return sorted_nodes[:top_n]

    # -------------------------------
    # 6. DEVICE-BASED LINK ANALYSIS
    # -------------------------------
    def detect_device_clusters(self):
        """Detect all device clusters, not just suspicious ones."""
        device_map = {}

        for u, v, data in self.graph.edges(data=True):
            # Handle both field name formats
            device = data.get("device_id") or data.get("Device_ID")
            if device:
                if device not in device_map:
                    device_map[device] = set()
                device_map[device].update([u, v])

        # Return all device clusters (PAMRS will determine risk levels)
        return device_map

    # -------------------------------
    # 7. TEMPORAL ANALYSIS (NEW 🔥)
    # -------------------------------
    def detect_burst_activity(self, minutes=30, threshold=5):
        """
        Detect accounts with high number of transactions in short time
        """
        activity = {}

        for u, v, data in self.graph.edges(data=True):
            ts = data.get("timestamp")
            if not ts:
                continue

            # Handle both datetime objects and strings
            if isinstance(ts, str):
                try:
                    from datetime import datetime
                    ts = datetime.fromisoformat(ts)
                except (ValueError, TypeError):
                    continue

            key = (u, ts.strftime('%Y-%m-%d %H:%M'))
            activity[key] = activity.get(key, 0) + 1

        suspicious = [k for k, count in activity.items() if count >= threshold]
        return suspicious

    # -------------------------------
    # 8. NETWORK RISK SCORE (IMPORTANT)
    # -------------------------------
    def calculate_network_risk(self, account):
        clusters = self.detect_clusters()
        for cluster in clusters:
            if account in cluster:
                size = len(cluster)
                return min(size / 10, 1.0)  # normalize risk

        return 0.0

    # -------------------------------
    # 9. DEBUG / VISUAL HELP
    # -------------------------------
    def get_graph_data(self):
        """
        Get graph data in D3.js format for frontend visualization.
        Returns nodes and edges with enriched metadata.
        """
        nodes = []
        edges = []
        
        # Add nodes
        for node in self.graph.nodes():
            degree = self.graph.degree(node)
            nodes.append({
                "id": str(node),
                "label": str(node),
                "degree": degree
            })
        
        # Add edges
        for u, v, data in self.graph.edges(data=True):
            edges.append({
                "source": str(u),
                "target": str(v),
                "amount": data.get("amount", 0),
                "weight": 1
            })
        
        return {
            "nodes": nodes,
            "edges": edges
        }

    def get_cycles(self):
        """
        Detect cycles (circular fund transfers) in the network.
        Returns list of cycles (each cycle is a list of account IDs).
        Note: Using a simplified algorithm to avoid NP-hard complexity.
        """
        # Instead of nx.simple_cycles which can be very slow,
        # we look for 3-node triangles which are common in circular transfers
        cycles = []
        
        try:
            # Find triangles (3-node cycles) using NetworkX
            G = self.graph.copy(as_view=False)
            triangles = list(nx.enumerate_all_cliques(G.to_undirected()))
            # Filter to get only triangles
            cycles = [list(c) for c in triangles if len(c) == 3]
        except:
            # If clique detection fails, return empty list
            pass
        
        return cycles

    def get_fan_in_accounts(self):
        """
        Get fan-in pattern: accounts receiving from multiple senders.
        Returns dict: {target_account: [list of senders]}
        """
        fan_in = {}
        
        # Build a directed graph for analysis
        directed_graph = nx.DiGraph(self.graph.copy())
        
        for node in directed_graph.nodes():
            predecessors = list(directed_graph.predecessors(node))
            if len(predecessors) >= 2:  # Has multiple senders
                fan_in[str(node)] = [str(p) for p in predecessors]
        
        return fan_in

    def get_graph_summary(self):
        return {
            "nodes": self.graph.number_of_nodes(),
            "edges": self.graph.number_of_edges(),
            "clusters": len(self.detect_clusters())
        }

    # -------------------------------
    # 10. EVALUATE METHOD (BACKWARD COMPATIBILITY)
    # -------------------------------
    def evaluate(self, account_id, transactions_df=None):
        """
        Evaluate network risk for an account (backward compatibility).
        Returns risk score and details for existing scorer.py integration.
        """
        if transactions_df is not None:
            self.build_graph(transactions_df)

        risk_score = self.calculate_network_risk(account_id) * 25  # Scale to 0-25 range
        details = []
        flags = []

        # Add cluster info
        clusters = self.detect_clusters()
        for cluster in clusters:
            if account_id in cluster:
                flags.append(f'CLUSTER_SIZE_{len(cluster)}')
                details.append({
                    'rule': 'Network cluster',
                    'cluster_size': len(cluster),
                    'penalty': risk_score
                })
                break

        return {
            'score': int(risk_score),
            'details': details,
            'flags': flags
        }


# ===========================================
# SINGLETON INSTANCE & BACKWARD COMPATIBILITY
# ===========================================

# Global singleton instance - import this wherever you need GraphEngine
graph_engine = GraphEngine()

# Backward compatibility alias (existing code uses NetworkEngine)
NetworkEngine = GraphEngine
