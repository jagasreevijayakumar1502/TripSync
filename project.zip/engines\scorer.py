"""
Compliance Risk Scorer
Aggregates all engine scores into a final compliance risk score and decision.
"""
import os
import hashlib
import pandas as pd
from engines.structuring import StructuringEngine
from engines.velocity import VelocityEngine
from engines.network import NetworkEngine
from engines.pep import PEPEngine
from engines.jurisdiction import JurisdictionEngine
from engines.kyc import KYCEngine

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


class ComplianceScorer:
    def __init__(self, threshold_reduction=0.0):
        self.structuring_engine = StructuringEngine(reduction_pct=threshold_reduction)
        self.velocity_engine = VelocityEngine()
        self.network_engine = NetworkEngine(max_hops=5)
        self.pep_engine = None
        self.jurisdiction_engine = JurisdictionEngine()
        self.kyc_engine = KYCEngine()
        self.threshold_reduction = threshold_reduction
        self._loaded = False
        self.accounts_df = None
        self.transactions_df = None
        self.pep_df = None

    @staticmethod
    def _generate_cibil(account_id: str) -> int:
        """
        Deterministically derive a pseudo CIBIL score (500-900) per account.
        Avoids mutating the source Excel while keeping scores stable across runs.
        """
        import hashlib
        base = int(hashlib.sha256(account_id.encode()).hexdigest(), 16)
        return 500 + (base % 401)

    def load_data(self):
        """Load all datasets and add transactions to graph engine individually."""
        self.accounts_df = pd.read_excel(os.path.join(DATA_DIR, "regshield_account_master.xlsx"))
        self.transactions_df = pd.read_excel(os.path.join(DATA_DIR, "regshield_transaction_log.xlsx"))
        self.pep_df = pd.read_excel(os.path.join(DATA_DIR, "regshield_pep_watchlist.xlsx"))

        # Ensure CIBIL score exists for every account (used by UI badges/alerts)
        if "CIBIL_Score" not in self.accounts_df.columns:
            self.accounts_df["CIBIL_Score"] = self.accounts_df["Account_ID"].apply(self._generate_cibil)
        else:
            # Fill any missing values deterministically
            self.accounts_df["CIBIL_Score"] = self.accounts_df.apply(
                lambda row: row["CIBIL_Score"]
                if pd.notnull(row["CIBIL_Score"])
                else self._generate_cibil(str(row.get("Account_ID", ""))),
                axis=1
            )

        self.pep_engine = PEPEngine(self.pep_df)

        # Add transactions individually to graph engine (with device_id)
        for _, tx in self.transactions_df.iterrows():
            sender = tx.get('Sender_Account_ID') or tx.get('sender')
            receiver = tx.get('Receiver_Account_ID') or tx.get('receiver')
            amount = tx.get('Amount') or tx.get('amount')
            device_id = tx.get('Device_ID') or tx.get('device_id')
            timestamp = tx.get('Timestamp') or tx.get('timestamp')

            if sender and receiver and amount:
                # Add to graph engine individually
                self.network_engine.add_transaction(sender, receiver, amount, device_id, timestamp)

        # Enrich accounts with deterministic financial/KYC/CIBIL data
        def _rand_from_hash(key: str, low: int, high: int):
            import hashlib
            base = int(hashlib.sha256(key.encode()).hexdigest(), 16)
            return low + (base % (high - low + 1))

        balances = []
        txn_counts = []
        last_acts = []
        cibil_scores = []
        kyc_statuses = []

        tx_times = pd.to_datetime(self.transactions_df.get("Timestamp", pd.Series([])), errors="coerce")

        for _, acct in self.accounts_df.iterrows():
            acct_id = str(acct.get("Account_ID"))
            acct_txns = self.transactions_df[(self.transactions_df["Sender_Account_ID"] == acct_id) |
                                             (self.transactions_df["Receiver_Account_ID"] == acct_id)]
            txn_count = len(acct_txns)
            if txn_count == 0:
                txn_count = _rand_from_hash(f"txn-{acct_id}", 1, 200)
            txn_counts.append(txn_count)

            # Balance: base + inflow - outflow, keep within 1k..1m
            base_bal = _rand_from_hash(f"bal-{acct_id}", 1000, 1_000_000)
            inflow = acct_txns[acct_txns["Receiver_Account_ID"] == acct_id]["Amount"].sum() if not acct_txns.empty else 0
            outflow = acct_txns[acct_txns["Sender_Account_ID"] == acct_id]["Amount"].sum() if not acct_txns.empty else 0
            bal = max(1000, min(1_500_000, int(base_bal + inflow - 0.6 * outflow)))
            balances.append(bal)

            # Last activity
            if not acct_txns.empty and "Timestamp" in acct_txns.columns:
                last_ts = pd.to_datetime(acct_txns["Timestamp"], errors="coerce").max()
                last_acts.append(str(last_ts) if pd.notnull(last_ts) else "just now")
            else:
                last_acts.append("just now")

            # KYC/CIBIL coupling
            kyc = str(acct.get("KYC_Status", "Pending"))
            if kyc.lower() in ["complete", "verified"]:
                kyc_statuses.append("VERIFIED")
                cibil_scores.append(_rand_from_hash(f"cibil-{acct_id}", 650, 900))
            else:
                kyc_statuses.append("NOT_VERIFIED")
                cibil_scores.append(_rand_from_hash(f"cibil-{acct_id}", 300, 650))

        self.accounts_df["Balance"] = balances
        self.accounts_df["Total_Transactions"] = txn_counts
        self.accounts_df["Last_Activity"] = last_acts
        self.accounts_df["KYC_Status"] = kyc_statuses
        self.accounts_df["CIBIL_Score"] = cibil_scores

        self._loaded = True

    def update_threshold(self, reduction_pct):
        """Apply adaptive threshold shift (Secret Reveal #1)."""
        self.threshold_reduction = reduction_pct
        self.structuring_engine.update_threshold(reduction_pct)

    def evaluate_account(self, account_id):
        """Evaluate a single account across all engines."""
        if not self._loaded:
            self.load_data()

        # Run all engines
        structuring = self.structuring_engine.evaluate(account_id, self.transactions_df)
        velocity = self.velocity_engine.evaluate(account_id, self.transactions_df, self.accounts_df)
        network = self.network_engine.evaluate(account_id)
        pep = self.pep_engine.evaluate(account_id, self.transactions_df, self.accounts_df)
        jurisdiction = self.jurisdiction_engine.evaluate(account_id, self.transactions_df, self.accounts_df)
        kyc = self.kyc_engine.evaluate(account_id, self.transactions_df, self.accounts_df)

        # Aggregate
        total_score = (
            structuring["score"] +
            velocity["score"] +
            network["score"] +
            pep["score"] +
            jurisdiction["score"] +
            kyc["score"]
        )

        # Decision
        if total_score > 80:
            decision = "Generate STR"
        elif total_score >= 50:
            decision = "Flag for Review"
        else:
            decision = "Clear"

        # Collect all flags
        all_flags = (
            structuring["flags"] +
            velocity["flags"] +
            network["flags"] +
            pep["flags"] +
            jurisdiction["flags"] +
            kyc["flags"]
        )

        return {
            "account_id": account_id,
            "structuring_risk": structuring["score"],
            "velocity_risk": velocity["score"],
            "network_risk": network["score"],
            "pep_risk": pep["score"],
            "jurisdiction_risk": jurisdiction["score"],
            "kyc_risk": kyc["score"],
            "compliance_risk_score": total_score,
            "decision": decision,
            "flags": all_flags,
            "details": {
                "structuring": structuring["details"],
                "velocity": velocity["details"],
                "network": network["details"],
                "pep": pep["details"],
                "jurisdiction": jurisdiction["details"],
                "kyc": kyc["details"]
            }
        }

    def evaluate_all(self):
        """Evaluate all accounts."""
        if not self._loaded:
            self.load_data()

        results = []
        for _, acct in self.accounts_df.iterrows():
            result = self.evaluate_account(acct["Account_ID"])
            results.append(result)

        return results

    def get_summary(self, results=None):
        """Get dashboard summary stats."""
        if results is None:
            results = self.evaluate_all()

        total = len(results)
        clear = sum(1 for r in results if r["decision"] == "Clear")
        flagged = sum(1 for r in results if r["decision"] == "Flag for Review")
        str_count = sum(1 for r in results if r["decision"] == "Generate STR")
        avg_score = sum(r["compliance_risk_score"] for r in results) / max(total, 1)

        return {
            "total_accounts": total,
            "clear": clear,
            "flagged": flagged,
            "str_generated": str_count,
            "avg_risk_score": round(avg_score, 2),
            "threshold_reduction": self.threshold_reduction,
            "effective_threshold": self.structuring_engine.effective_threshold,
            "total_transactions": len(self.transactions_df) if self.transactions_df is not None else 0
        }
