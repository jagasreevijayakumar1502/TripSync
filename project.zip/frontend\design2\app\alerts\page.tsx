"use client"

import { useState, useEffect } from "react"
import { 
  Search, 
  Filter, 
  Bell,
  BellOff,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  AlertCircle,
  Clock,
  Eye,
  Archive,
  Trash2,
  MoreHorizontal,
  RefreshCw,
} from "lucide-react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface Alert {
  id: string
  type: "critical" | "high" | "medium" | "low"
  title: string
  description: string
  accountId: string
  timestamp: Date
  status: "new" | "investigating" | "resolved" | "dismissed"
  category: string
  riskScore: number
}

const alertTypes = [
  "Unusual Transaction Pattern",
  "High-Value Transfer Detected",
  "Multiple Failed Login Attempts",
  "Geographic Anomaly",
  "Rapid Succession Transactions",
  "Account Takeover Attempt",
  "Suspicious IP Address",
  "Velocity Check Failed",
  "Device Fingerprint Mismatch",
  "Cross-Border Transfer Flag",
]

const generateAlerts = (): Alert[] => {
  const types: Alert["type"][] = ["critical", "high", "medium", "low"]
  const statuses: Alert["status"][] = ["new", "investigating", "resolved", "dismissed"]
  const categories = ["Transaction", "Authentication", "Account", "Network", "Compliance"]
  
  return Array.from({ length: 100 }, (_, i) => {
    const type = types[Math.floor(Math.random() * types.length)]
    return {
      id: `ALT-${String(i + 1).padStart(6, "0")}`,
      type,
      title: alertTypes[Math.floor(Math.random() * alertTypes.length)],
      description: `Automated detection flagged suspicious activity on account ending in ${Math.floor(Math.random() * 10000).toString().padStart(4, "0")}`,
      accountId: `ACC-${String(Math.floor(Math.random() * 100000)).padStart(6, "0")}`,
      timestamp: new Date(Date.now() - Math.random() * 48 * 60 * 60 * 1000),
      status: statuses[Math.floor(Math.random() * statuses.length)],
      category: categories[Math.floor(Math.random() * categories.length)],
      riskScore: type === "critical" ? 90 + Math.floor(Math.random() * 10) :
                 type === "high" ? 70 + Math.floor(Math.random() * 20) :
                 type === "medium" ? 40 + Math.floor(Math.random() * 30) :
                 10 + Math.floor(Math.random() * 30),
    }
  })
}

const typeStyles = {
  critical: { 
    badge: "bg-destructive/10 text-destructive border-destructive/30", 
    icon: XCircle,
    dot: "bg-destructive",
  },
  high: { 
    badge: "bg-chart-3/10 text-chart-3 border-chart-3/30", 
    icon: AlertTriangle,
    dot: "bg-chart-3",
  },
  medium: { 
    badge: "bg-chart-2/10 text-chart-2 border-chart-2/30", 
    icon: AlertCircle,
    dot: "bg-chart-2",
  },
  low: { 
    badge: "bg-chart-1/10 text-chart-1 border-chart-1/30", 
    icon: Bell,
    dot: "bg-chart-1",
  },
}

const statusStyles = {
  new: { badge: "bg-primary/10 text-primary border-primary/30", label: "New" },
  investigating: { badge: "bg-chart-2/10 text-chart-2 border-chart-2/30", label: "Investigating" },
  resolved: { badge: "bg-chart-1/10 text-chart-1 border-chart-1/30", label: "Resolved" },
  dismissed: { badge: "bg-muted text-muted-foreground border-muted", label: "Dismissed" },
}

function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000)
  if (seconds < 60) return `${seconds}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

export default function AlertsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null)
  const [activeTab, setActiveTab] = useState("all")
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    setAlerts(generateAlerts())
  }, [])

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      setAlerts(generateAlerts())
      setIsRefreshing(false)
    }, 1000)
  }

  const filteredAlerts = alerts.filter(alert => {
    const matchesSearch = alert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         alert.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         alert.accountId.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || alert.type === typeFilter
    const matchesTab = activeTab === "all" || 
                      (activeTab === "active" && (alert.status === "new" || alert.status === "investigating")) ||
                      (activeTab === "resolved" && alert.status === "resolved") ||
                      (activeTab === "dismissed" && alert.status === "dismissed")
    return matchesSearch && matchesType && matchesTab
  })

  const stats = {
    total: alerts.length,
    critical: alerts.filter(a => a.type === "critical" && a.status === "new").length,
    high: alerts.filter(a => a.type === "high" && a.status === "new").length,
    investigating: alerts.filter(a => a.status === "investigating").length,
    resolved: alerts.filter(a => a.status === "resolved").length,
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-1 flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Page Header */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Alert Center</h1>
                <p className="text-sm text-muted-foreground">
                  Real-time fraud detection alerts and incident management
                </p>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                >
                  <RefreshCw className={cn("mr-2 h-4 w-4", isRefreshing && "animate-spin")} />
                  Refresh
                </Button>
                <Button size="sm">
                  <BellOff className="mr-2 h-4 w-4" />
                  Mute All
                </Button>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-5">
              <Card className="border-border/50 bg-card/50 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Total Alerts
                  </CardTitle>
                  <Bell className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.total}</div>
                  <p className="text-xs text-muted-foreground">Last 48 hours</p>
                </CardContent>
              </Card>
              <Card className="border-destructive/30 bg-destructive/5 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-destructive">
                    Critical
                  </CardTitle>
                  <XCircle className="h-4 w-4 text-destructive" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-destructive">{stats.critical}</div>
                  <p className="text-xs text-destructive/70">Requires immediate action</p>
                </CardContent>
              </Card>
              <Card className="border-chart-3/30 bg-chart-3/5 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-chart-3">
                    High Priority
                  </CardTitle>
                  <AlertTriangle className="h-4 w-4 text-chart-3" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-chart-3">{stats.high}</div>
                  <p className="text-xs text-chart-3/70">Pending review</p>
                </CardContent>
              </Card>
              <Card className="border-chart-2/30 bg-chart-2/5 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-chart-2">
                    Investigating
                  </CardTitle>
                  <Clock className="h-4 w-4 text-chart-2" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-chart-2">{stats.investigating}</div>
                  <p className="text-xs text-chart-2/70">In progress</p>
                </CardContent>
              </Card>
              <Card className="border-chart-1/30 bg-chart-1/5 backdrop-blur">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-chart-1">
                    Resolved
                  </CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-chart-1" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-chart-1">{stats.resolved}</div>
                  <p className="text-xs text-chart-1/70">This week</p>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Alert List */}
              <div className="lg:col-span-2">
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="border-b border-border/50 pb-4">
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                      <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="bg-secondary/50">
                          <TabsTrigger value="all">All</TabsTrigger>
                          <TabsTrigger value="active">Active</TabsTrigger>
                          <TabsTrigger value="resolved">Resolved</TabsTrigger>
                          <TabsTrigger value="dismissed">Dismissed</TabsTrigger>
                        </TabsList>
                      </Tabs>
                      <div className="flex gap-2">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="Search alerts..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-[200px] pl-9 bg-secondary/50"
                          />
                        </div>
                        <Select value={typeFilter} onValueChange={setTypeFilter}>
                          <SelectTrigger className="w-[130px] bg-secondary/50">
                            <SelectValue placeholder="Priority" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Priority</SelectItem>
                            <SelectItem value="critical">Critical</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardHeader>
                  <ScrollArea className="h-[600px]">
                    <div className="divide-y divide-border/50">
                      {filteredAlerts.map((alert) => {
                        const typeStyle = typeStyles[alert.type]
                        const TypeIcon = typeStyle.icon
                        const statusStyle = statusStyles[alert.status]
                        return (
                          <div
                            key={alert.id}
                            className={cn(
                              "flex cursor-pointer items-start gap-4 p-4 transition-colors hover:bg-secondary/30",
                              selectedAlert?.id === alert.id && "bg-secondary/50"
                            )}
                            onClick={() => setSelectedAlert(alert)}
                          >
                            <div className={cn(
                              "mt-1 flex h-8 w-8 items-center justify-center rounded-full",
                              alert.type === "critical" && "bg-destructive/10",
                              alert.type === "high" && "bg-chart-3/10",
                              alert.type === "medium" && "bg-chart-2/10",
                              alert.type === "low" && "bg-chart-1/10",
                            )}>
                              <TypeIcon className={cn(
                                "h-4 w-4",
                                alert.type === "critical" && "text-destructive",
                                alert.type === "high" && "text-chart-3",
                                alert.type === "medium" && "text-chart-2",
                                alert.type === "low" && "text-chart-1",
                              )} />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="font-medium text-foreground">{alert.title}</p>
                                  <p className="mt-1 text-sm text-muted-foreground line-clamp-1">
                                    {alert.description}
                                  </p>
                                </div>
                                <div className="flex flex-shrink-0 items-center gap-2">
                                  <Badge variant="outline" className={cn("text-xs", statusStyle.badge)}>
                                    {statusStyle.label}
                                  </Badge>
                                </div>
                              </div>
                              <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                                <span className="font-mono">{alert.id}</span>
                                <span>|</span>
                                <span>{alert.category}</span>
                                <span>|</span>
                                <span>{formatTimeAgo(alert.timestamp)}</span>
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </ScrollArea>
                </Card>
              </div>

              {/* Alert Detail */}
              <div>
                <Card className="border-border/50 bg-card/50 backdrop-blur sticky top-6">
                  {selectedAlert ? (
                    <>
                      <CardHeader className="border-b border-border/50">
                        <div className="flex items-start justify-between">
                          <div>
                            <Badge variant="outline" className={cn("mb-2", typeStyles[selectedAlert.type].badge)}>
                              {selectedAlert.type.toUpperCase()}
                            </Badge>
                            <CardTitle className="text-lg">{selectedAlert.title}</CardTitle>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <CheckCircle2 className="mr-2 h-4 w-4" />
                                Mark Resolved
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Archive className="mr-2 h-4 w-4" />
                                Dismiss
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6 pt-6">
                        <div>
                          <h4 className="mb-2 text-sm font-medium text-muted-foreground">Description</h4>
                          <p className="text-sm text-foreground">{selectedAlert.description}</p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="mb-1 text-sm font-medium text-muted-foreground">Alert ID</h4>
                            <p className="font-mono text-sm">{selectedAlert.id}</p>
                          </div>
                          <div>
                            <h4 className="mb-1 text-sm font-medium text-muted-foreground">Account</h4>
                            <p className="font-mono text-sm">{selectedAlert.accountId}</p>
                          </div>
                          <div>
                            <h4 className="mb-1 text-sm font-medium text-muted-foreground">Category</h4>
                            <p className="text-sm">{selectedAlert.category}</p>
                          </div>
                          <div>
                            <h4 className="mb-1 text-sm font-medium text-muted-foreground">Status</h4>
                            <Badge variant="outline" className={cn("text-xs", statusStyles[selectedAlert.status].badge)}>
                              {statusStyles[selectedAlert.status].label}
                            </Badge>
                          </div>
                          <div>
                            <h4 className="mb-1 text-sm font-medium text-muted-foreground">Risk Score</h4>
                            <div className="flex items-center gap-2">
                              <span className={cn(
                                "font-mono font-bold",
                                selectedAlert.riskScore >= 80 ? "text-destructive" :
                                selectedAlert.riskScore >= 60 ? "text-chart-3" :
                                selectedAlert.riskScore >= 40 ? "text-chart-2" : "text-chart-1"
                              )}>
                                {selectedAlert.riskScore}
                              </span>
                              <span className="text-muted-foreground">/ 100</span>
                            </div>
                          </div>
                          <div>
                            <h4 className="mb-1 text-sm font-medium text-muted-foreground">Timestamp</h4>
                            <p className="text-sm">{selectedAlert.timestamp.toLocaleString()}</p>
                          </div>
                        </div>

                        <div className="flex gap-2 pt-4">
                          <Button className="flex-1" size="sm">
                            <Eye className="mr-2 h-4 w-4" />
                            Investigate
                          </Button>
                          <Button variant="outline" size="sm">
                            <CheckCircle2 className="mr-2 h-4 w-4" />
                            Resolve
                          </Button>
                        </div>
                      </CardContent>
                    </>
                  ) : (
                    <CardContent className="flex h-[400px] items-center justify-center">
                      <div className="text-center">
                        <Bell className="mx-auto h-12 w-12 text-muted-foreground/30" />
                        <p className="mt-4 text-sm text-muted-foreground">
                          Select an alert to view details
                        </p>
                      </div>
                    </CardContent>
                  )}
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
