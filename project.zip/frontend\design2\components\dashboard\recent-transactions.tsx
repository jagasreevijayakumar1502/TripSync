"use client"

import { useEffect, useRef, useState } from "react"
import {
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
  MoreHorizontal,
  ExternalLink,
  Filter,
  Wifi,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { type LiveTransaction, formatCurrency, getTimeAgo } from "@/hooks/use-live-data"

interface RecentTransactionsProps {
  transactions?: LiveTransaction[]
  isLive?: boolean
}

const statusStyles = {
  completed: {
    badge: "bg-chart-1/10 text-chart-1 border-chart-1/30",
    label: "Completed",
  },
  pending: {
    badge: "bg-chart-2/10 text-chart-2 border-chart-2/30",
    label: "Pending",
  },
  flagged: {
    badge: "bg-chart-3/10 text-chart-3 border-chart-3/30",
    label: "Flagged",
  },
  blocked: {
    badge: "bg-destructive/10 text-destructive border-destructive/30",
    label: "Blocked",
  },
}

const typeIcons = {
  incoming: ArrowDownLeft,
  outgoing: ArrowUpRight,
  internal: RefreshCw,
}

export function RecentTransactions({ transactions = [], isLive = false }: RecentTransactionsProps) {
  const [newTxIds, setNewTxIds] = useState<Set<string>>(new Set())
  const [filter, setFilter] = useState<string>("all")
  const prevTxRef = useRef<LiveTransaction[]>([])

  // Detect new transactions and trigger animation
  useEffect(() => {
    if (prevTxRef.current.length > 0) {
      const prevIds = new Set(prevTxRef.current.map(t => t.id))
      const newIds = transactions.filter(t => !prevIds.has(t.id)).map(t => t.id)
      
      if (newIds.length > 0) {
        setNewTxIds(new Set(newIds))
        const timer = setTimeout(() => setNewTxIds(new Set()), 1500)
        return () => clearTimeout(timer)
      }
    }
    prevTxRef.current = transactions
  }, [transactions])

  const filteredTransactions = filter === "all" 
    ? transactions 
    : transactions.filter(t => t.status === filter)

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <RefreshCw className="h-5 w-5 text-primary" />
            {isLive && (
              <span className="absolute -right-1 -top-1 flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex h-3 w-3 rounded-full bg-primary" />
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg">Recent Transactions</CardTitle>
              {isLive && (
                <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/30 text-xs">
                  <Wifi className="mr-1 h-3 w-3" />
                  LIVE
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              {transactions.length} transactions in the last hour
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <Filter className="h-4 w-4" />
                {filter === "all" ? "All" : statusStyles[filter as keyof typeof statusStyles]?.label}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setFilter("all")}>All</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("completed")}>Completed</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("pending")}>Pending</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("flagged")}>Flagged</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("blocked")}>Blocked</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="ghost" size="sm" className="gap-1 text-primary">
            View All
            <ExternalLink className="h-3.5 w-3.5" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px] px-6 pb-6">
          <div className="space-y-3">
            {filteredTransactions.length === 0 ? (
              <div className="flex h-32 items-center justify-center text-muted-foreground">
                No transactions to display
              </div>
            ) : (
              filteredTransactions.map((tx) => {
                const TypeIcon = typeIcons[tx.type]
                const statusStyle = statusStyles[tx.status]
                const isNew = newTxIds.has(tx.id)

                return (
                  <div
                    key={tx.id}
                    className={cn(
                      "group flex items-center justify-between gap-4 rounded-xl border border-border/50 bg-secondary/30 p-4 transition-all duration-300 hover:border-primary/30 hover:bg-secondary/50",
                      isNew && "animate-pulse ring-2 ring-primary/50"
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          "flex h-10 w-10 items-center justify-center rounded-full",
                          tx.type === "incoming"
                            ? "bg-chart-1/10 text-chart-1"
                            : tx.type === "outgoing"
                              ? "bg-chart-3/10 text-chart-3"
                              : "bg-primary/10 text-primary"
                        )}
                      >
                        <TypeIcon className="h-5 w-5" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{tx.description}</span>
                          {isNew && (
                            <Badge className="bg-primary text-primary-foreground text-xs">NEW</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{tx.senderName}</span>
                          <span className="text-xs">→</span>
                          <span>{tx.receiverName}</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>{tx.timestamp instanceof Date ? getTimeAgo(tx.timestamp) : tx.timestamp}</span>
                          <Badge variant="outline" className={statusStyle.badge}>
                            {statusStyle.label}
                          </Badge>
                          {tx.riskScore >= 60 && (
                            <span className={cn(
                              "font-medium",
                              tx.riskScore >= 80 ? "text-destructive" : "text-chart-3"
                            )}>
                              Risk: {tx.riskScore}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span
                        className={cn(
                          "text-lg font-bold",
                          tx.type === "incoming"
                            ? "text-chart-1"
                            : tx.type === "outgoing"
                              ? "text-foreground"
                              : "text-primary"
                        )}
                      >
                        {tx.type === "incoming" ? "+" : tx.type === "outgoing" ? "-" : ""}
                        {formatCurrency(tx.amount)}
                      </span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 opacity-0 transition-opacity group-hover:opacity-100"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Flag for Review</DropdownMenuItem>
                          <DropdownMenuItem>Block Transaction</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
