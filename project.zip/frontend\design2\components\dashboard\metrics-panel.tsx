"use client"

import { useEffect, useState } from "react"
import { TrendingUp, TrendingDown, Users, AlertTriangle, DollarSign, ShieldAlert, Activity, Ban } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { type LiveMetrics, formatCurrency, formatNumber } from "@/hooks/use-live-data"

interface MetricsPanelProps {
  metrics?: LiveMetrics
}

interface MetricConfig {
  id: string
  title: string
  icon: React.ElementType
  variant: "default" | "success" | "warning" | "danger"
  getValue: (m: LiveMetrics) => string
  getTrend: (m: LiveMetrics, prev: LiveMetrics | null) => { change: number; isUp: boolean }
  changeLabel: string
}

const metricConfigs: MetricConfig[] = [
  {
    id: "total-accounts",
    title: "Total Accounts",
    icon: Users,
    variant: "default",
    getValue: (m) => formatNumber(m.totalAccounts),
    getTrend: (m, prev) => ({
      change: prev ? Math.abs(((m.totalAccounts - prev.totalAccounts) / prev.totalAccounts) * 100) : 12.5,
      isUp: prev ? m.totalAccounts > prev.totalAccounts : true,
    }),
    changeLabel: "from last update",
  },
  {
    id: "flagged-accounts",
    title: "Flagged Accounts",
    icon: ShieldAlert,
    variant: "warning",
    getValue: (m) => formatNumber(m.flaggedAccounts),
    getTrend: (m, prev) => ({
      change: prev ? Math.abs(((m.flaggedAccounts - prev.flaggedAccounts) / prev.flaggedAccounts) * 100) : 8.2,
      isUp: prev ? m.flaggedAccounts > prev.flaggedAccounts : false,
    }),
    changeLabel: "from last hour",
  },
  {
    id: "funds-at-risk",
    title: "Funds at Risk",
    icon: DollarSign,
    variant: "danger",
    getValue: (m) => formatCurrency(m.fundsAtRisk),
    getTrend: (m, prev) => ({
      change: prev ? Math.abs(((m.fundsAtRisk - prev.fundsAtRisk) / prev.fundsAtRisk) * 100) : 23.1,
      isUp: prev ? m.fundsAtRisk > prev.fundsAtRisk : true,
    }),
    changeLabel: "from last hour",
  },
  {
    id: "active-alerts",
    title: "Active Alerts",
    icon: AlertTriangle,
    variant: "success",
    getValue: (m) => formatNumber(m.activeAlerts),
    getTrend: (m, prev) => ({
      change: prev ? Math.abs(((m.activeAlerts - prev.activeAlerts) / prev.activeAlerts) * 100) : 15.3,
      isUp: prev ? m.activeAlerts > prev.activeAlerts : false,
    }),
    changeLabel: "from last hour",
  },
  {
    id: "transactions-per-minute",
    title: "Transactions/Min",
    icon: Activity,
    variant: "default",
    getValue: (m) => formatNumber(m.transactionsPerMinute),
    getTrend: (m, prev) => ({
      change: prev ? Math.abs(((m.transactionsPerMinute - prev.transactionsPerMinute) / prev.transactionsPerMinute) * 100) : 5.8,
      isUp: prev ? m.transactionsPerMinute > prev.transactionsPerMinute : true,
    }),
    changeLabel: "real-time",
  },
  {
    id: "blocked-transactions",
    title: "Blocked Today",
    icon: Ban,
    variant: "success",
    getValue: (m) => formatNumber(m.blockedTransactions),
    getTrend: (m, prev) => ({
      change: prev ? Math.abs(((m.blockedTransactions - prev.blockedTransactions) / prev.blockedTransactions) * 100) : 3.2,
      isUp: prev ? m.blockedTransactions > prev.blockedTransactions : true,
    }),
    changeLabel: "threats stopped",
  },
]

const variantStyles = {
  default: {
    iconBg: "bg-primary/10",
    iconColor: "text-primary",
  },
  success: {
    iconBg: "bg-chart-1/10",
    iconColor: "text-chart-1",
  },
  warning: {
    iconBg: "bg-chart-3/10",
    iconColor: "text-chart-3",
  },
  danger: {
    iconBg: "bg-destructive/10",
    iconColor: "text-destructive",
  },
}

const defaultMetrics: LiveMetrics = {
  totalAccounts: 24521,
  flaggedAccounts: 147,
  fundsAtRisk: 2400000,
  activeAlerts: 38,
  transactionsPerMinute: 1247,
  blockedTransactions: 23,
}

export function MetricsPanel({ metrics = defaultMetrics }: MetricsPanelProps) {
  const [prevMetrics, setPrevMetrics] = useState<LiveMetrics | null>(null)
  const [animatingIds, setAnimatingIds] = useState<Set<string>>(new Set())

  useEffect(() => {
    if (prevMetrics) {
      const changed = new Set<string>()
      metricConfigs.forEach(config => {
        const prevVal = config.getValue(prevMetrics)
        const newVal = config.getValue(metrics)
        if (prevVal !== newVal) {
          changed.add(config.id)
        }
      })
      if (changed.size > 0) {
        setAnimatingIds(changed)
        const timer = setTimeout(() => setAnimatingIds(new Set()), 500)
        return () => clearTimeout(timer)
      }
    }
    setPrevMetrics(metrics)
  }, [metrics, prevMetrics])

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {metricConfigs.map((config) => {
        const Icon = config.icon
        const styles = variantStyles[config.variant]
        const trend = config.getTrend(metrics, prevMetrics)
        const TrendIcon = trend.isUp ? TrendingUp : TrendingDown
        
        // Determine if trend is positive based on metric type
        const isPositiveTrend =
          (config.variant === "danger" && !trend.isUp) ||
          (config.variant === "warning" && !trend.isUp) ||
          (config.variant === "success" && !trend.isUp) ||
          (config.variant === "default" && trend.isUp)

        const isAnimating = animatingIds.has(config.id)

        return (
          <Card
            key={config.id}
            className={cn(
              "group relative overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
              isAnimating && "ring-2 ring-primary/50"
            )}
          >
            <CardContent className="p-4 lg:p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1.5 flex-1 min-w-0">
                  <p className="text-xs font-medium text-muted-foreground truncate">
                    {config.title}
                  </p>
                  <p className={cn(
                    "text-2xl font-bold tracking-tight transition-all duration-300",
                    isAnimating && "scale-105 text-primary"
                  )}>
                    {config.getValue(metrics)}
                  </p>
                  <div className="flex items-center gap-1">
                    <TrendIcon
                      className={cn(
                        "h-3 w-3",
                        isPositiveTrend ? "text-chart-1" : "text-destructive"
                      )}
                    />
                    <span
                      className={cn(
                        "text-xs font-medium",
                        isPositiveTrend ? "text-chart-1" : "text-destructive"
                      )}
                    >
                      {trend.change.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-110",
                    styles.iconBg
                  )}
                >
                  <Icon className={cn("h-5 w-5", styles.iconColor)} />
                </div>
              </div>
              {/* Decorative gradient */}
              <div
                className={cn(
                  "absolute -bottom-1 -right-1 h-20 w-20 rounded-full opacity-0 blur-2xl transition-opacity duration-300 group-hover:opacity-50",
                  config.variant === "danger"
                    ? "bg-destructive"
                    : config.variant === "warning"
                      ? "bg-chart-3"
                      : config.variant === "success"
                        ? "bg-chart-1"
                        : "bg-primary"
                )}
              />
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
