"""
Immutable Compliance Ledger
Append-only hash-chain log with tamper detection.
Each entry includes previous_hash and current_hash (SHA-256).
"""
import hashlib
import json
import os
from datetime import datetime


class ComplianceLedger:
    def __init__(self, ledger_file=None):
        if ledger_file is None:
            ledger_file = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "data", "compliance_ledger.json"
            )
        self.ledger_file = ledger_file
        self.entries = []
        self._load()

    def _load(self):
        """Load existing ledger from file."""
        if os.path.exists(self.ledger_file):
            try:
                with open(self.ledger_file, 'r') as f:
                    self.entries = json.load(f)
            except (json.JSONDecodeError, IOError):
                self.entries = []
        else:
            self.entries = []

    def _save(self):
        """Persist ledger to file."""
        os.makedirs(os.path.dirname(self.ledger_file), exist_ok=True)
        with open(self.ledger_file, 'w') as f:
            json.dump(self.entries, f, indent=2, default=str)

    def _compute_hash(self, data_str):
        """Compute SHA-256 hash."""
        return hashlib.sha256(data_str.encode('utf-8')).hexdigest()

    def add_entry(self, evaluation_data):
        """
        Append an evaluation to the ledger with hash chaining.
        """
        prev_hash = self.entries[-1]["current_hash"] if self.entries else "GENESIS"

        entry_data = {
            "index": len(self.entries),
            "timestamp": datetime.now().isoformat(),
            "previous_hash": prev_hash,
            "data": evaluation_data
        }

        # Compute hash of entry content (without current_hash)
        content_str = json.dumps(entry_data, sort_keys=True, default=str)
        current_hash = self._compute_hash(content_str)

        entry_data["current_hash"] = current_hash

        self.entries.append(entry_data)
        self._save()

        return entry_data

    def add_batch(self, evaluation_results):
        """Add multiple evaluation results to the ledger."""
        for result in evaluation_results:
            self.add_entry({
                "account_id": result["account_id"],
                "compliance_risk_score": result["compliance_risk_score"],
                "decision": result["decision"],
                "flags": result["flags"],
                "structuring_risk": result["structuring_risk"],
                "velocity_risk": result["velocity_risk"],
                "network_risk": result["network_risk"],
                "pep_risk": result["pep_risk"],
                "jurisdiction_risk": result["jurisdiction_risk"],
                "kyc_risk": result["kyc_risk"]
            })

    def verify_integrity(self):
        """
        Verify the entire ledger chain integrity.
        Returns True if no tampering detected, False otherwise.
        """
        if not self.entries:
            return {"valid": True, "message": "Empty ledger", "tampered_indices": []}

        tampered = []

        for i, entry in enumerate(self.entries):
            # Check previous hash chain
            if i == 0:
                expected_prev = "GENESIS"
            else:
                expected_prev = self.entries[i - 1]["current_hash"]

            if entry["previous_hash"] != expected_prev:
                tampered.append({
                    "index": i,
                    "issue": "Previous hash mismatch",
                    "expected": expected_prev,
                    "found": entry["previous_hash"]
                })

            # Verify current hash
            stored_hash = entry["current_hash"]
            entry_copy = {k: v for k, v in entry.items() if k != "current_hash"}
            content_str = json.dumps(entry_copy, sort_keys=True, default=str)
            computed_hash = self._compute_hash(content_str)

            if stored_hash != computed_hash:
                tampered.append({
                    "index": i,
                    "issue": "Current hash mismatch (data tampered)",
                    "expected": computed_hash,
                    "found": stored_hash
                })

        return {
            "valid": len(tampered) == 0,
            "total_entries": len(self.entries),
            "tampered_indices": tampered,
            "message": "Ledger integrity verified ✓" if not tampered else f"TAMPER DETECTED at {len(tampered)} entries!"
        }

    def get_entries(self, limit=100, offset=0):
        """Get ledger entries with pagination."""
        return self.entries[offset:offset + limit]

    def clear(self):
        """Clear ledger (for re-evaluation)."""
        self.entries = []
        self._save()
